"""Train the single KNN model used by FraudGuard AI.

Run from the project root:

    python train_knn.py

Input features (all taken from data/creditcard.csv):
    Amount, MerchantID, TransactionType, Location
    + hour / day / month / day-of-week derived from TransactionDate

Writes:
    models/preprocessor.joblib
    models/knn.joblib
    reports/model_comparison.csv   (only the KNN row is replaced)

Run it again whenever the dataset changes, or if the app reports that the
model could not be loaded (this happens when scikit-learn on your PC is a
different version from the one that saved the files).
"""

from __future__ import annotations

import sys
from pathlib import Path

import joblib
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.metrics import (
    accuracy_score,
    average_precision_score,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
)
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import OneHotEncoder, StandardScaler

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from app.config import (  # noqa: E402
    BASELINE_COMPARISON_CSV,
    DATA_PATH,
    DEFAULT_THRESHOLD,
    FEATURE_COLUMNS,
    MODEL_REGISTRY,
    PREPROCESSOR_PATH,
    SCALED_COLUMNS,
)

CATEGORICAL_COLUMNS = ["TransactionType", "Location"]


def load_data() -> pd.DataFrame:
    df = pd.read_csv(DATA_PATH)

    dates = pd.to_datetime(df["TransactionDate"], errors="coerce")
    df["TransactionHour"] = dates.dt.hour
    df["TransactionDay"] = dates.dt.day
    df["TransactionMonth"] = dates.dt.month
    df["TransactionDayOfWeek"] = dates.dt.dayofweek

    df["TransactionType"] = df["TransactionType"].astype(str).str.strip().str.lower()
    df["Location"] = df["Location"].astype(str).str.strip()

    return df.dropna(subset=FEATURE_COLUMNS + ["IsFraud"])


def main() -> None:
    spec = MODEL_REGISTRY["knn"]
    df = load_data()

    X = df[FEATURE_COLUMNS]
    y = df["IsFraud"].astype(int)

    # Same split as the app uses for its dataset samples (80 / 20, stratified).
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    preprocessor = ColumnTransformer(
        [
            ("num", StandardScaler(), SCALED_COLUMNS),
            (
                "cat",
                OneHotEncoder(handle_unknown="ignore", sparse_output=False),
                CATEGORICAL_COLUMNS,
            ),
        ],
        remainder="drop",
        verbose_feature_names_out=True,
    )

    # The preprocessor is fitted on the training data only (no leakage).
    X_train_p = preprocessor.fit_transform(X_train)
    X_test_p = preprocessor.transform(X_test)

    model = KNeighborsClassifier(
        n_neighbors=5, weights="distance", n_jobs=-1
    )
    model.fit(X_train_p, y_train)

    proba = model.predict_proba(X_test_p)[:, list(model.classes_).index(1)]
    pred = (proba >= DEFAULT_THRESHOLD).astype(int)

    tn, fp, fn, tp = confusion_matrix(y_test, pred, labels=[0, 1]).ravel()

    row = {
        "Model": spec.report_name,
        "Precision": precision_score(y_test, pred, zero_division=0),
        "Recall": recall_score(y_test, pred, zero_division=0),
        "F1-Score": f1_score(y_test, pred, zero_division=0),
        "PR-AUC": average_precision_score(y_test, proba),
        "ROC-AUC": roc_auc_score(y_test, proba),
        "Accuracy": accuracy_score(y_test, pred),
        "TN": int(tn),
        "FP": int(fp),
        "FN": int(fn),
        "TP": int(tp),
    }

    spec.file.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(preprocessor, PREPROCESSOR_PATH, compress=3)
    joblib.dump(model, spec.file, compress=3)

    # Replace only the KNN row of the baseline report.
    report_path = Path(BASELINE_COMPARISON_CSV)
    new_row = pd.DataFrame([row])

    if report_path.exists():
        report = pd.read_csv(report_path)
        report = report[report["Model"] != spec.report_name]
        report = pd.concat([report, new_row], ignore_index=True)
    else:
        report = new_row

    report.to_csv(report_path, index=False)

    print("Features used :", ", ".join(FEATURE_COLUMNS))
    print(f"Train rows    : {len(X_train):,}   Test rows: {len(X_test):,}")
    print(
        f"Precision {row['Precision']:.4f}  Recall {row['Recall']:.4f}  "
        f"F1 {row['F1-Score']:.4f}  PR-AUC {row['PR-AUC']:.4f}  "
        f"ROC-AUC {row['ROC-AUC']:.4f}"
    )
    print(f"Confusion matrix  TN={tn} FP={fp} FN={fn} TP={tp}")
    print(f"Saved: {PREPROCESSOR_PATH}")
    print(f"Saved: {spec.file}")


if __name__ == "__main__":
    main()
