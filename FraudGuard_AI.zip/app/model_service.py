import math
from dataclasses import dataclass, field
from datetime import datetime
from typing import Mapping

# -------------------------------------------------------------------
# scikit-learn compatibility fix
# -------------------------------------------------------------------
# The preprocessor was saved with a scikit-learn version that used
# _RemainderColsList. Newer versions may not expose it publicly.
# Define it before joblib loads the saved ColumnTransformer.
try:
    from sklearn.compose import _column_transformer as _ct_mod

    if not hasattr(_ct_mod, "_RemainderColsList"):

        class _RemainderColsList(list):
            pass

        _ct_mod._RemainderColsList = _RemainderColsList

except Exception:
    pass


import joblib
import numpy as np
import pandas as pd
import streamlit as st

from app import data_service
from app.config import (
    DEFAULT_THRESHOLD,
    FEATURE_COLUMNS,
    MODEL_REGISTRY,
    SUSPICIOUS_FRACTION,
)
from app.i18n import tr


class ModelServiceError(Exception):
    """Raised when a model or prediction operation fails."""
    pass


@dataclass(frozen=True)
class PredictionResult:
    probability: float
    label: str
    risk_level: str
    threshold: float
    model_name: str
    timestamp: datetime
    reasons: list[str] = field(default_factory=list)


@st.cache_resource(show_spinner=False)
def _load_artifact(path_str: str, mtime: float):
    return joblib.load(path_str)


def _load(path):
    if not path.exists():
        raise ModelServiceError(
            f"Required file '{path.name}' was not found."
        )

    try:
        return _load_artifact(
            str(path),
            path.stat().st_mtime,
        )

    except Exception as exc:
        raise ModelServiceError(
            f"Could not load '{path.name}': "
            f"{type(exc).__name__}: {exc}"
        ) from exc


def available_models():
    """Return all configured models whose files exist."""

    return [
        spec
        for spec in MODEL_REGISTRY.values()
        if spec.file.exists()
    ]


def load_preprocessor():
    """
    Load the preprocessing pipeline created during training.
    """

    preprocessor_path = (
        MODEL_REGISTRY[next(iter(MODEL_REGISTRY))]
        .file.parent
        / "preprocessor.joblib"
    )

    return _load(preprocessor_path)


def load_model(spec):
    """Load the selected trained model."""

    return _load(spec.file)


def decision_threshold(spec):
    """
    Return the selected decision threshold.

    If a model has a report-based threshold configured, use it
    when available. Otherwise use DEFAULT_THRESHOLD.
    """

    if spec.threshold_from_report:

        selected = data_service.train_selected_threshold()

        if selected is not None:
            return float(selected)

    return float(DEFAULT_THRESHOLD)


def default_model_key():
    """
    Select the model with the highest reported PR-AUC.

    If the comparison report is unavailable, use the first
    available configured model.
    """

    specs = available_models()

    if not specs:
        return None

    table = data_service.comparison_table()

    if table is not None:

        best_key = None
        best_value = -1.0

        for spec in specs:

            if spec.report_name in table.index:

                if "PR-AUC" in table.columns:

                    try:
                        value = float(
                            table.loc[
                                spec.report_name,
                                "PR-AUC",
                            ]
                        )

                    except (TypeError, ValueError):
                        continue

                    if value > best_value:
                        best_key = spec.key
                        best_value = value

        if best_key is not None:
            return best_key

    return specs[0].key


def build_feature_frame(values: Mapping[str, object]):
    """
    Build one transaction row using the NEW dataset fields.

    User inputs:
        Amount
        MerchantID
        TransactionType
        Location
        TransactionDate (optional - the current date/time is used if missing)

    Automatically generated:
        TransactionHour
        TransactionDay
        TransactionMonth
        TransactionDayOfWeek

    V1-V28 are NOT used.
    """

    required = [
        "Amount",
        "TransactionType",
        "Location",
    ]

    missing = [
        column
        for column in required
        if column not in values
    ]

    if missing:
        raise ModelServiceError(
            f"Missing transaction fields: {missing}"
        )

    # -----------------------------
    # Amount
    # -----------------------------

    try:
        amount = float(values["Amount"])

    except (TypeError, ValueError):
        raise ModelServiceError(
            "Amount must be a number."
        ) from None

    if not math.isfinite(amount):
        raise ModelServiceError(
            "Amount must be a finite number."
        )

    if amount < 0:
        raise ModelServiceError(
            "Amount cannot be negative."
        )

    # -----------------------------
    # Transaction Type
    # -----------------------------

    transaction_type = str(
        values["TransactionType"]
    ).strip().lower()

    if transaction_type not in {
        "purchase",
        "refund",
    }:
        raise ModelServiceError(
            "TransactionType must be either "
            "'purchase' or 'refund'."
        )

    # -----------------------------
    # MerchantID
    # -----------------------------

    try:
        merchant_raw = float(values["MerchantID"])
    except (KeyError, TypeError, ValueError) as exc:
        raise ModelServiceError(
            "MerchantID must be a whole number."
        ) from exc

    if (
        not math.isfinite(merchant_raw)
        or merchant_raw != int(merchant_raw)
        or merchant_raw < 1
    ):
        raise ModelServiceError(
            "MerchantID must be a whole number of 1 or more."
        )

    merchant_id = int(merchant_raw)

    # -----------------------------
    # Location
    # -----------------------------

    location = str(
        values["Location"]
    ).strip()

    if not location:
        raise ModelServiceError(
            "Location cannot be empty."
        )

    # -----------------------------
    # Transaction date / time
    # -----------------------------

    now = values.get("TransactionDate") if hasattr(values, "get") else None

    if now is None or (isinstance(now, str) and not now.strip()):
        now = datetime.now()
    elif isinstance(now, str):
        try:
            now = pd.to_datetime(now).to_pydatetime()
        except (ValueError, TypeError) as exc:
            raise ModelServiceError(
                "TransactionDate is not a valid date."
            ) from exc
    elif not isinstance(now, datetime):
        # a plain date -> midnight of that day
        now = datetime(now.year, now.month, now.day)

    frame = pd.DataFrame(
        [
            {
                "Amount": amount,
                "MerchantID": merchant_id,
                "TransactionType": transaction_type,
                "Location": location,
                "TransactionHour": now.hour,
                "TransactionDay": now.day,
                "TransactionMonth": now.month,
                "TransactionDayOfWeek": now.weekday(),
            }
        ]
    )

    return frame


def preprocess(frame, preprocessor):
    """
    Apply the SAME preprocessing pipeline used during training.
    """

    expected_columns = [
        "Amount",
        "MerchantID",
        "TransactionType",
        "Location",
        "TransactionHour",
        "TransactionDay",
        "TransactionMonth",
        "TransactionDayOfWeek",
    ]

    if list(frame.columns) != expected_columns:
        raise ModelServiceError(
            "Feature columns do not match the new training pipeline."
        )

    try:
        processed = preprocessor.transform(frame)

    except Exception as exc:
        raise ModelServiceError(
            f"Preprocessing error: "
            f"{type(exc).__name__}: {exc}"
        ) from exc

    return processed


def classify(probability, threshold):
    """
    Convert fraud probability into a user-friendly risk result.
    """

    if probability >= threshold:
        return "FRAUD", "HIGH"

    if probability >= threshold * SUSPICIOUS_FRACTION:
        return "SUSPICIOUS", "MEDIUM"

    return "NORMAL", "LOW"


def predict(spec, values):
    """
    Predict one transaction using the selected trained model.
    """

    # Build the new dataset-compatible feature row.
    frame = build_feature_frame(values)

    # Load saved preprocessing pipeline.
    preprocessor = load_preprocessor()

    # Load selected trained model.
    model = load_model(spec)

    try:

        # Apply the exact training preprocessing.
        features = preprocess(
            frame,
            preprocessor,
        )

        # Generate probability.
        proba = model.predict_proba(features)

        classes = list(
            getattr(
                model,
                "classes_",
                [0, 1],
            )
        )

        if 1 not in classes:
            raise ModelServiceError(
                "The loaded model does not contain the fraud class."
            )

        fraud_index = classes.index(1)

        probability = float(
            proba[
                0,
                fraud_index,
            ]
        )

    except ModelServiceError:
        raise

    except Exception as exc:
        raise ModelServiceError(
            f"Prediction error: "
            f"{type(exc).__name__}: {exc}"
        ) from exc

    if not (0.0 <= probability <= 1.0):
        raise ModelServiceError(
            "The model returned an invalid probability."
        )

    # Get decision threshold.
    threshold = decision_threshold(spec)

    # Convert probability to label/risk.
    label, risk = classify(
        probability,
        threshold,
    )

    # Plain-language reasons (never allowed to break a prediction).
    try:
        reasons = _explain(values, spec, label)
    except Exception:
        reasons = []

    return PredictionResult(
        probability=probability,
        label=label,
        risk_level=risk,
        threshold=threshold,
        model_name=spec.report_name,
        timestamp=datetime.now().astimezone(),
        reasons=reasons,
    )


# --------------------------------------------------------------------------
# Plain-language explanation ("why was this flagged?")
# --------------------------------------------------------------------------
#
# This is NOT a real model explanation. It shows how different the
# transaction is from the NORMAL transactions of the dataset, so the reasons
# are "unusual patterns", not a proven cause of fraud.

_MAX_REASONS = 3

# Used when a category value never appears among the normal transactions.
_UNSEEN_SCORE = 3.0


def _importance_by_feature(spec) -> dict[str, float] | None:
    """Share of the model's importance per raw input feature (sums to 1).

    Uses feature_importances_ (tree models) or abs(coef_) (linear models).
    One-hot columns are added back to their raw feature. Returns None when
    the model exposes neither (for example KNN).
    """

    try:
        model = load_model(spec)

        importance = getattr(model, "feature_importances_", None)

        if importance is None:
            coefficients = getattr(model, "coef_", None)

            if coefficients is None:
                return None

            importance = np.abs(np.ravel(coefficients))

        names = list(load_preprocessor().get_feature_names_out())

        if len(names) != len(importance):
            return None

        totals: dict[str, float] = {}

        for name, value in zip(names, importance):
            raw = name.split("__", 1)[-1]

            for column in FEATURE_COLUMNS:
                if raw == column or raw.startswith(column + "_"):
                    totals[column] = totals.get(column, 0.0) + float(value)
                    break

        grand_total = sum(totals.values())

        if grand_total <= 0:
            return None

        return {k: v / grand_total for k, v in totals.items()}

    except Exception:
        return None


def _level_text(z_abs: float, lang) -> str:
    if z_abs >= 3:
        return tr("level_far", lang)
    if z_abs >= 2:
        return tr("level_well", lang)
    if z_abs >= 1:
        return tr("level_some", lang)
    return tr("level_slight", lang)


def _explain(values, spec, label, lang=None) -> list[str]:
    """Build the reason list for an already classified transaction."""

    if label == "NORMAL":
        return [tr("no_unusual", lang)]

    profile = data_service.normal_profile()

    if not profile:
        return [tr("reasons_unavailable", lang)]

    row = build_feature_frame(values).iloc[0]

    importance = _importance_by_feature(spec)

    # candidates: (score, message)
    candidates: list[tuple[float, str]] = []

    def weight(column: str) -> float:
        # 1.0 = an average feature; more important features count more.
        if not importance or column not in importance:
            return 1.0
        return importance[column] * len(FEATURE_COLUMNS)

    # ---- Amount ---------------------------------------------------------
    amount = float(row["Amount"])
    stats = profile["amount"]
    mean, std = stats["mean"], stats["std"]

    if std > 0 and mean > 0:
        z = (amount - mean) / std
        ratio = amount / mean

        if ratio >= 1.2:
            text = tr("rs_amount_high", lang, ratio=ratio, avg=mean)
        elif ratio <= 0.8:
            text = tr("rs_amount_low", lang, pct=ratio * 100, avg=mean)
        else:
            text = tr(
                "rs_numeric", lang,
                label=f"{tr('feat_Amount', lang)} ({amount:,.2f})",
                level=_level_text(abs(z), lang), z=z,
            )

        candidates.append((abs(z) * weight("Amount"), text))

    # ---- time features (derived from the analysis time) ------------------
    weekdays = tr("weekdays", lang).split(",")

    shown = {
        "TransactionHour": lambda v: f"{int(v):02d}:00",
        "TransactionDay": lambda v: str(int(v)),
        "TransactionMonth": lambda v: str(int(v)),
        "TransactionDayOfWeek": lambda v: weekdays[int(v) % len(weekdays)],
    }

    for column, fmt in shown.items():
        if column not in profile["numeric"]:
            continue

        mean_c, std_c = profile["numeric"][column]

        if std_c <= 0:
            continue

        value = float(row[column])
        z = (value - mean_c) / std_c

        text = tr(
            "rs_numeric", lang,
            label=f"{tr('feat_' + column, lang)} ({fmt(value)})",
            level=_level_text(abs(z), lang), z=z,
        )

        candidates.append((abs(z) * weight(column), text))

    # ---- categorical features --------------------------------------------
    for column in ["TransactionType", "Location"]:
        shares = profile["categorical"].get(column, {})

        if not shares:
            continue

        value = str(row[column]).strip()
        share = shares.get(value.lower())
        label_text = tr("feat_" + column, lang)

        if share is None:
            text = tr("rs_unseen", lang, label=label_text, value=value)
            score = _UNSEEN_SCORE
        else:
            # how much rarer than an evenly spread value (0 = not unusual)
            expected = 1.0 / len(shares)
            score = max(0.0, (expected - share) / expected) * 3
            text = tr("rs_rare", lang, label=label_text, value=value,
                      pct=share * 100)

        candidates.append((score * weight(column), text))

    candidates.sort(key=lambda item: item[0], reverse=True)

    return [text for _, text in candidates[:_MAX_REASONS]]


def explain(values, spec, label=None, lang=None) -> list[str]:
    """Return the top 3 plain-language "unusual pattern" reasons.

    For a NORMAL transaction the single message "No unusual patterns found"
    is returned. If `label` is not given the transaction is classified first.
    """

    if label is None:
        label = predict(spec, values).label

    return _explain(values, spec, label, lang)
