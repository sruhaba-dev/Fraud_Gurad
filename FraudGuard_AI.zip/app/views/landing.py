"""Public landing page (shown before sign-in). UI only - no business logic."""

from __future__ import annotations

import streamlit as st

from app.ui_components import brand_html, icon, render, theme_button


def open_auth(view: str) -> None:
    """Button callback: leave the landing page and open the login / sign-up screen."""
    st.session_state["auth_view"] = view


# Shield + credit card illustration (pure SVG, no external files)
ART_SVG = """
<svg class="art" viewBox="0 0 640 420" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Shield protecting a credit card">
  <defs>
    <radialGradient id="fgGlow" cx="50%" cy="55%" r="55%">
      <stop offset="0" stop-color="#6366F1" stop-opacity=".55"/><stop offset="1" stop-color="#6366F1" stop-opacity="0"/>
    </radialGradient>
    <linearGradient id="fgCard" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="#26357A"/><stop offset="1" stop-color="#0F1638"/>
    </linearGradient>
    <linearGradient id="fgShield" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="#A5B4FC"/><stop offset="1" stop-color="#3B82F6"/>
    </linearGradient>
  </defs>
  <ellipse cx="320" cy="220" rx="300" ry="190" fill="url(#fgGlow)"/>
  <ellipse cx="300" cy="335" rx="235" ry="46" fill="none" stroke="#6366F1" stroke-opacity=".55" stroke-width="2"/>
  <ellipse cx="300" cy="335" rx="185" ry="34" fill="none" stroke="#38BDF8" stroke-opacity=".5" stroke-width="1.5"/>
  <ellipse cx="300" cy="335" rx="130" ry="23" fill="#6366F1" fill-opacity=".18" stroke="#818CF8" stroke-opacity=".6"/>
  <g transform="rotate(-13 200 225)">
    <rect x="40" y="120" width="310" height="196" rx="20" fill="url(#fgCard)" stroke="#818CF8" stroke-opacity=".8" stroke-width="1.5"/>
    <rect x="68" y="158" width="46" height="35" rx="7" fill="#CBD5E1" fill-opacity=".85"/>
    <path d="M68 175h46M91 158v35" stroke="#64748B" stroke-width="1.2"/>
    <text x="68" y="252" fill="#C7D2FE" font-size="21" font-family="ui-monospace, Menlo, monospace" letter-spacing="3">4532 7489 3521 8842</text>
    <text x="68" y="288" fill="#94A3B8" font-size="11" font-family="Inter, sans-serif" letter-spacing="2">CARDHOLDER</text>
  </g>
  <g transform="translate(232 86)">
    <path d="M100 0 L186 32 V118 C186 178 142 214 100 234 C58 214 14 178 14 118 V32 Z"
          fill="#0B1130" fill-opacity=".55" stroke="url(#fgShield)" stroke-width="5"/>
    <path d="M100 16 L172 42 V116 C172 166 136 198 100 216 C64 198 28 166 28 116 V42 Z" fill="url(#fgShield)" fill-opacity=".38"/>
    <path d="M62 116 L92 146 L142 86" fill="none" stroke="#FFFFFF" stroke-width="13" stroke-linecap="round" stroke-linejoin="round"/>
  </g>
</svg>
"""

FEATURES = [
    ("brain", "AI Detection", "ML models detect fraud patterns and anomalies."),
    ("zap", "Real-Time Analysis", "Analyze transactions in real-time for faster decisions."),
    ("shield-check", "Secure Detection", "Identify suspicious activity and prevent fraud."),
    ("chart", "Smart Analytics", "Clear fraud insights and easy-to-understand reports."),
]

STEPS = [
    ("card", "Transaction", "Transaction enters system."),
    ("database", "Data Processing", "Clean & prepare the data."),
    ("sliders", "Feature Analysis", "Analyze important patterns/features."),
    ("cpu", "ML Model", "Predict fraud risk."),
    ("alert", "Fraud Risk", "Fraud / Legitimate"),
]

NAV = [("home", "Home"), ("features", "Features"), ("how", "How It Works"),
       ("about", "About"), ("support", "Support")]


def _risk_panel() -> str:
    # ring: 8.7% arc (purple) on top of a teal ring, r=34 -> circumference ~213.6
    return f"""
    <div class="fg-l-risk">
      <div class="h">Fraud Risk <em>Sample</em></div>
      <div class="ring">
        <svg viewBox="0 0 84 84" width="84" height="84">
          <circle cx="42" cy="42" r="34" fill="none" stroke="#22D3EE" stroke-width="7" stroke-opacity=".9"/>
          <circle cx="42" cy="42" r="34" fill="none" stroke="#8B5CF6" stroke-width="7" stroke-linecap="round"
                  stroke-dasharray="18.6 213.6" transform="rotate(-90 42 42)"/>
        </svg>
        <div class="v">8.7%<small>Low Risk</small></div>
      </div>
      <div class="row"><span><i style="background:#22D3EE"></i>Normal</span><b>92.3%</b></div>
      <div class="row"><span><i style="background:#8B5CF6"></i>Suspicious</span><b>7.7%</b></div>
    </div>"""


def render_landing() -> None:
    # ------------------------------------------------------------ top bar
    brand, links, toggle, login, signup = st.columns([1.5, 3.7, 1.35, 0.85, 1.0],
                                                     vertical_alignment="center")
    with brand:
        render(brand_html())
    with links:
        render('<div class="fg-nav-links">' + "".join(
            f'<a href="#{key}" target="_self" class="{"on" if key == "home" else ""}">{label}</a>'
            for key, label in NAV) + "</div>")
    with toggle:
        theme_button("theme_button_landing")
    with login:
        st.button("Login", key="landing_login", on_click=open_auth, args=("login",), width="stretch")
    with signup:
        st.button("Sign Up", key="landing_signup", type="primary", on_click=open_auth,
                  args=("signup",), width="stretch")
    render('<div id="home" class="fg-divider-line"></div>')

    # --------------------------------------------------------------- hero
    left, right = st.columns([1.05, 1], gap="large", vertical_alignment="center")
    with left:
        render("""
        <span class="fg-l-pill">AI-POWERED FRAUD DETECTION</span>
        <div class="fg-l-h1">Detect Fraud.<br><span class="g">Protect Every Transaction.</span></div>
        <div class="fg-l-lead">Intelligent machine learning helps identify suspicious credit card
        transactions and assess fraud risk.</div>""")
        b1, b2, _ = st.columns([1, 1.35, 0.5], vertical_alignment="center")
        b1.button("Get Started", key="landing_start", type="primary", icon=":material/arrow_forward:",
                  on_click=open_auth, args=("signup",), width="stretch")
        with b2:
            render('<a class="fg-l-btn" href="#how" target="_self">Explore How It Works</a>')
        render(f"""
        <div class="fg-l-trust">
          <span><i class="ck">{icon("check", 13)}</i>AI-Powered</span>
          <span><i class="ck">{icon("check", 13)}</i>Real-Time Analysis</span>
          <span><i class="ck">{icon("check", 13)}</i>Secure &amp; Reliable</span>
        </div>""")
    with right:
        render(f'<div class="fg-l-visual">{ART_SVG}{_risk_panel()}</div>')

    # ------------------------------------------------------ why FraudGuard
    cards = "".join(
        f'<div class="fg-l-feat"><div class="ic">{icon(ic, 22)}</div>'
        f'<div class="t">{title}</div><div class="d">{text}</div></div>'
        for ic, title, text in FEATURES)
    render(f'<div id="features"></div><div class="fg-l-title">Why <span class="g">FraudGuard?</span></div>'
           f'<div class="fg-l-grid">{cards}</div>')

    # --------------------------------------------------------- how it works
    parts = []
    for i, (ic, title, text) in enumerate(STEPS, start=1):
        cls = "fg-l-step risk" if i == len(STEPS) else "fg-l-step"
        parts.append(f'<div class="{cls}"><div class="n">{i}</div><div class="ic">{icon(ic, 20)}</div>'
                     f'<div class="t">{title}</div><div class="d">{text}</div></div>')
        if i < len(STEPS):
            parts.append(f'<div class="fg-l-arrow">{icon("arrow-right", 18)}</div>')
    render(f'<div id="how"></div><div class="fg-l-title">How It <span class="g">Works</span></div>'
           f'<div class="fg-l-steps">{"".join(parts)}</div>')

    # ---------------------------------------------------------------- about
    render('<div id="about"></div><div style="height:2rem"></div>')
    about_l, about_r = st.columns([1.3, 1], gap="large", vertical_alignment="center")
    with about_l:
        render("""
        <div class="fg-l-about"><h3>About <span>FraudGuard</span></h3>
        <p>FraudGuard is an AI-powered credit card fraud detection system designed to analyze
        transactions and identify potentially fraudulent activity using machine learning.</p></div>""")
        st.button("Learn More About FraudGuard", key="landing_learn", icon=":material/arrow_forward:",
                  on_click=open_auth, args=("login",))
    with about_r:
        render(f'<div class="fg-l-visual small">{ART_SVG}</div>')

    # ------------------------------------------------------------------ CTA
    with st.container(key="cta_banner"):
        text_col, btn_col = st.columns([3, 1], vertical_alignment="center")
        with text_col:
            render('<div class="cta-t">Ready to Get Started?</div>'
                   '<div class="cta-s">Start analyzing transactions with FraudGuard.</div>')
        with btn_col:
            st.button("Get Started", key="cta_start", icon=":material/arrow_forward:",
                      on_click=open_auth, args=("signup",), width="stretch")

    # --------------------------------------------------------------- footer
    render('<div id="support"></div>')
    render(f"""
    <div class="fg-l-footer">
      {brand_html("AI-Powered Fraud Detection")}
      <div class="fg-nav-links">{"".join(f'<a href="#{k}" target="_self">{label}</a>' for k, label in NAV)}</div>
      <div class="copy">&copy; 2026 FraudGuard</div>
    </div>""")
