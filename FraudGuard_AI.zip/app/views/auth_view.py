"""Login / sign-up screen (shown before the user is authenticated)."""

from __future__ import annotations

import streamlit as st

from app import auth
from app.config import MIN_PASSWORD_LENGTH
from app.ui_components import icon, notice, render, theme_button
from app.views.landing import open_auth


# Shield with a fingerprint-style emblem (pure SVG)
_SHIELD_SVG = """
<svg viewBox="0 0 340 300" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Shield">
  <defs>
    <linearGradient id="fgAuthShield" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="#C4B5FD"/><stop offset="1" stop-color="#60A5FA"/>
    </linearGradient>
  </defs>
  <ellipse cx="170" cy="250" rx="130" ry="26" fill="none" stroke="#A5B4FC" stroke-opacity=".55" stroke-width="1.5"/>
  <ellipse cx="170" cy="250" rx="92" ry="17" fill="#818CF8" fill-opacity=".22" stroke="#C7D2FE" stroke-opacity=".6"/>
  <path d="M170 24 L252 56 V136 C252 194 214 228 170 246 C126 228 88 194 88 136 V56 Z"
        fill="#0B1130" fill-opacity=".5" stroke="url(#fgAuthShield)" stroke-width="5"/>
  <path d="M170 40 L238 66 V134 C238 184 206 214 170 230 C134 214 102 184 102 134 V66 Z" fill="url(#fgAuthShield)" fill-opacity=".22"/>
  <g fill="none" stroke="#E0E7FF" stroke-width="4" stroke-linecap="round">
    <path d="M136 132c0-20 15-34 34-34s34 14 34 34"/>
    <path d="M148 178c-4-12-6-24-6-40 0-16 12-28 28-28s28 12 28 28c0 12-2 22-6 34"/>
    <path d="M158 190c-4-14-6-30-6-52 0-10 8-18 18-18s18 8 18 18c0 16-1 28-4 42"/>
    <path d="M170 136c0 24 2 40 6 54"/>
  </g>
</svg>
"""


def render_auth() -> None:
    view = st.session_state.get("auth_view", "login")
    signup_first = view == "signup"

    back_col, _, toggle_col = st.columns([1.4, 5, 1.3], vertical_alignment="center")
    with back_col:
        st.button("Back to home", key="auth_back", icon=":material/arrow_back:",
                  on_click=open_auth, args=("landing",))
    with toggle_col:
        theme_button("theme_button_auth")

    hero_col, form_col = st.columns([1.15, 1], gap="large")

    with hero_col:
        render(f"""
        <div class="fg-hero fg-auth-hero">
          <div class="brand"><div class="logo">{icon("shield", 24)}</div>
            <div><div class="wm">FraudGuard</div><div class="wm-s">AI-Powered Fraud Detection</div></div></div>
          <div class="fg-auth-h">Secure Every <span class="g">Transaction.</span></div>
          <p>Machine-learning risk scoring for credit card transactions, built for
          highly imbalanced fraud data.</p>
          <div class="fg-auth-art">
            {_SHIELD_SVG}
            <div class="fg-chip-float a">{icon("activity", 18)}<div><b>AI Analysis</b><small>Instant scoring</small></div></div>
            <div class="fg-chip-float b">{icon("target", 18)}<div><b>Risk Detection</b><small>Probability based</small></div></div>
            <div class="fg-chip-float c">{icon("lock", 18)}<div><b>Data Protection</b><small>Hashed passwords</small></div></div>
            <div class="fg-chip-float d">{icon("shield-check", 18)}<div><b>Private History</b><small>Per-user records</small></div></div>
          </div>
          <div class="features">
            <div class="feature"><span class="dot">{icon("target", 16)}</span>Imbalance-aware models, judged by PR-AUC, precision and recall</div>
            <div class="feature"><span class="dot">{icon("zap", 16)}</span>Instant fraud probability with a clear risk level</div>
            <div class="feature"><span class="dot">{icon("lock", 16)}</span>Private, per-user prediction history</div>
            <div class="feature"><span class="dot">{icon("bar", 16)}</span>Transparent model comparison and analytics</div>
          </div>
        </div>""")

    with form_col:
        if signup_first:
            render('<div class="fg-auth-title">Create Account</div>'
                   '<div class="fg-auth-sub">Sign up to start using FraudGuard.</div>')
        else:
            render('<div class="fg-auth-title">Welcome Back &#128075;</div>'
                   '<div class="fg-auth-sub">Sign in to continue to FraudGuard.</div>')

        # The requested tab is listed first so it opens by default.
        labels = ["Create Account", "Sign In"] if signup_first else ["Sign In", "Create Account"]
        tabs = dict(zip(labels, st.tabs(labels)))
        tab_login, tab_signup = tabs["Sign In"], tabs["Create Account"]

        with tab_login:
            with st.form("login_form"):
                email = st.text_input("Email Address", placeholder="Enter your email", key="login_email")
                password = st.text_input("Password", type="password", placeholder="Enter your password",
                                         key="login_password")
                submitted = st.form_submit_button("Sign In", type="primary", width="stretch",
                                                  icon=":material/arrow_forward:")
            if submitted:
                user, error = auth.authenticate(email, password)
                if user:
                    auth.login_session(user)
                    st.rerun()
                notice("danger", error)
            render('<div class="fg-or">OR</div>')
            st.button("Don't have an account? Sign Up", key="auth_switch", width="stretch",
                      on_click=open_auth, args=("signup",))

        with tab_signup:
            with st.form("signup_form"):
                full_name = st.text_input("Full name", placeholder="Jane Doe", key="signup_name")
                new_email = st.text_input("Email", placeholder="you@example.com", key="signup_email")
                new_password = st.text_input(
                    "Password", type="password", key="signup_password",
                    help=f"At least {MIN_PASSWORD_LENGTH} characters, with a letter and a number.")
                confirm = st.text_input("Confirm password", type="password", key="signup_confirm")
                created = st.form_submit_button("Create Account", type="primary", width="stretch",
                                                icon=":material/arrow_forward:")
            if created:
                ok, messages = auth.register_user(full_name, new_email, new_password, confirm)
                if ok:
                    notice("ok", messages[0])
                else:
                    notice("danger", messages)
