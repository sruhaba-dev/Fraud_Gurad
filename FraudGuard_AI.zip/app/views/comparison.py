"""Model Comparison page."""

from __future__ import annotations

import numpy as np
import plotly.graph_objects as go
import streamlit as st

from app import data_service
from app.config import FIGURES_DIR
from app.theme import current_theme, palette, plotly_layout, series_colors
from app.ui_components import (
    card,
    empty_state,
    html_table,
    kpi_card,
    kpi_row,
    notice,
    page_header,
    section,
    show_plotly,
)
from app.views.common import short_model_name


METRIC_CHOICES = [
    "Precision",
    "Recall",
    "F1-Score",
    "PR-AUC",
    "ROC-AUC",
    "Accuracy",
]


def render_comparison() -> None:
    page_header(
        "Model Comparison",
        "Comparison of the trained fraud detection models on the held-out test set.",
        "layers",
    )

    table = data_service.comparison_table()

    if table is None or table.empty:
        empty_state(
            "Comparison report not found",
            "Run the model evaluation and model improvement phases first.",
            "layers",
        )
        return

    p = palette()
    colors = dict(zip(table.index, series_colors()))

    # ---------------------------------------------------------------
    # Summary cards
    # ---------------------------------------------------------------
    def best(metric: str) -> tuple[str, str]:
        if metric not in table.columns:
            return "-", "-"

        name = table[metric].idxmax()
        return (
            f"{table[metric].max():.4f}",
            short_model_name(name),
        )

    cards = []

    for metric, icon_name, tone in [
        ("PR-AUC", "trending", "ok"),
        ("Precision", "target", "accent"),
        ("Recall", "search", "warn"),
        ("F1-Score", "zap", "accent"),
    ]:
        value, name = best(metric)

        cards.append(
            kpi_card(
                f"Highest {metric}",
                value,
                name,
                icon_name,
                tone,
            )
        )

    kpi_row(cards)

    # ---------------------------------------------------------------
    # Model information
    # ---------------------------------------------------------------
    section("Models included")

    card(
        "Baseline models",
        "Random Forest (Baseline) and K-Nearest Neighbors (KNN) "
        "are the two baseline models trained on the new dataset."
    )

    # ---------------------------------------------------------------
    # Explanation
    # ---------------------------------------------------------------
    acc_min = table["Accuracy"].min()
    acc_max = table["Accuracy"].max()
    f1_min = table["F1-Score"].min()
    f1_max = table["F1-Score"].max()

    section("How to read this comparison")

    e1, e2, e3 = st.columns(3, gap="medium")

    with e1:
        card(
            "Accuracy is not enough",
            f"Accuracy ranges from {acc_min:.2%} to {acc_max:.2%}, "
            f"while F1-Score ranges from {f1_min:.2f} to {f1_max:.2f}. "
            "Because fraud cases are rare, accuracy alone can be misleading.",
        )

    with e2:
        card(
            "Precision / Recall",
            "Precision measures how many flagged transactions are actually "
            "fraud. Recall measures how many real fraud cases are detected.",
        )

    with e3:
        card(
            "Why PR-AUC",
            "PR-AUC summarizes the precision-recall relationship across "
            "different thresholds and is useful for highly imbalanced data.",
        )

    # ---------------------------------------------------------------
    # Metric comparison
    # ---------------------------------------------------------------
    section("Metric comparison")

    chosen = st.multiselect(
        "Metrics",
        METRIC_CHOICES,
        default=[
            "Precision",
            "Recall",
            "F1-Score",
            "PR-AUC",
        ],
        key="cmp_metrics",
    )

    if chosen:
        figure = go.Figure()

        for name in table.index:
            figure.add_bar(
                x=chosen,
                y=[table.loc[name, metric] for metric in chosen],
                name=short_model_name(name),
                marker_color=colors.get(name),
                text=[
                    f"{table.loc[name, metric]:.3f}"
                    for metric in chosen
                ],
                textposition="outside",
                textfont=dict(size=10),
                hovertemplate=(
                    "%{x}: %{y:.4f}<extra>"
                    + short_model_name(name)
                    + "</extra>"
                ),
            )

        layout = plotly_layout(height=420)
        layout["barmode"] = "group"
        layout["yaxis"]["range"] = [0, 1.12]
        layout["title"]["text"] = "Model metric comparison"
        layout["legend"].update(
            orientation="h",
            y=-0.15,
        )

        figure.update_layout(**layout)

        show_plotly(
            figure,
            "cmp_bars",
        )

    else:
        notice(
            "info",
            "Select at least one metric to display the chart.",
        )

    # ---------------------------------------------------------------
    # Error comparison
    # ---------------------------------------------------------------
    left, right = st.columns(
        [1, 1],
        gap="large",
    )

    with left:
        figure = go.Figure()

        labels = [
            short_model_name(model)
            for model in table.index
        ]

        figure.add_bar(
            x=labels,
            y=table["FP"],
            name="False positives",
            marker_color=p["warn"],
            text=table["FP"],
            textposition="outside",
        )

        figure.add_bar(
            x=labels,
            y=table["FN"],
            name="False negatives",
            marker_color=p["danger"],
            text=table["FN"],
            textposition="outside",
        )

        layout = plotly_layout(height=380)
        layout["barmode"] = "group"
        layout["title"]["text"] = "Prediction errors"

        layout["legend"].update(
            orientation="h",
            y=-0.3,
        )

        max_error = max(
            table["FP"].max(),
            table["FN"].max(),
        )

        layout["yaxis"]["range"] = [
            0,
            float(max_error) * 1.18 + 1,
        ]

        figure.update_layout(**layout)

        show_plotly(
            figure,
            "cmp_errors",
        )

    # ---------------------------------------------------------------
    # Confusion matrix
    # ---------------------------------------------------------------
    with right:
        selected = st.selectbox(
            "Confusion matrix for",
            list(table.index),
            key="cmp_cm_model",
            format_func=short_model_name,
        )

        row = table.loc[selected]

        z = np.array(
            [
                [row["TN"], row["FP"]],
                [row["FN"], row["TP"]],
            ],
            dtype=float,
        )

        row_sums = z.sum(axis=1, keepdims=True)
        row_sums[row_sums == 0] = 1

        share = z / row_sums

        figure = go.Figure(
            go.Heatmap(
                z=share,
                x=[
                    "Predicted Normal",
                    "Predicted Fraud",
                ],
                y=[
                    "Actual Normal",
                    "Actual Fraud",
                ],
                zmin=0,
                zmax=1,
                showscale=False,
                colorscale=[
                    [0, p["surface2"]],
                    [1, p["accent"]],
                ],
                hoverinfo="skip",
            )
        )

        dark = current_theme() == "dark"

        for i, actual in enumerate(
            ["Actual Normal", "Actual Fraud"]
        ):
            for j, predicted in enumerate(
                ["Predicted Normal", "Predicted Fraud"]
            ):
                strong = share[i, j] > 0.5

                figure.add_annotation(
                    x=predicted,
                    y=actual,
                    showarrow=False,
                    align="center",
                    text=(
                        f"<b>{int(z[i, j]):,}</b>"
                        f"<br>({share[i, j]:.2%})"
                    ),
                    font=dict(
                        size=14,
                        color=(
                            "#0A0F1F"
                            if dark
                            else "#FFFFFF"
                        )
                        if strong
                        else p["text"],
                    ),
                )

        layout = plotly_layout(height=320)
        layout["yaxis"]["autorange"] = "reversed"
        layout["title"]["text"] = (
            "Confusion matrix"
        )

        figure.update_layout(**layout)

        show_plotly(
            figure,
            "cmp_cm",
        )

    # ---------------------------------------------------------------
    # Full comparison table
    # ---------------------------------------------------------------
    section(
        "Full comparison table",
        "Metrics reported for each trained model.",
    )

    ordered = table.sort_values(
        ["PR-AUC", "F1-Score"],
        ascending=False,
    )

    rows = []

    for name, row in ordered.iterrows():
        rows.append(
            [
                name,
                *[
                    f"{row[metric]:.4f}"
                    for metric in [
                        "Precision",
                        "Recall",
                        "F1-Score",
                        "PR-AUC",
                        "ROC-AUC",
                        "Accuracy",
                    ]
                ],
                f"{int(row['FP']):,}",
                f"{int(row['FN']):,}",
            ]
        )

    html_table(
        [
            "Model",
            "Precision",
            "Recall",
            "F1-Score",
            "PR-AUC",
            "ROC-AUC",
            "Accuracy",
            "FP",
            "FN",
        ],
        rows,
        numeric=tuple(range(1, 9)),
    )

    st.caption(
        "Metrics are calculated on the held-out test set. "
        "The baseline models use their default decision threshold, "
        "while tuned models use the threshold defined by the "
        "model-improvement report."
    )

    # ---------------------------------------------------------------
    # Precision-Recall curve
    # ---------------------------------------------------------------
    curves = FIGURES_DIR / "07_precision_recall_curves.png"

    if curves.exists():
        with st.expander(
            "Precision-Recall curves"
        ):
            st.image(str(curves))