"""Main dashboard: KPIs, quick actions, recent predictions, model snapshot."""

from __future__ import annotations

import plotly.graph_objects as go
import streamlit as st

from app import data_service, database
from app.config import APP_NAME, APP_TAGLINE
from app.i18n import tr
from app.theme import palette, plotly_layout
from app.ui_components import (
    esc, empty_state, go_to, html_table, kpi_card, kpi_row, notice, page_header,
    render, row_tone, section, show_plotly, status_badge, verdict_cell,
)
from app.views.common import short_model_name


def render_dashboard(user: dict) -> None:
    page_header(APP_NAME, APP_TAGLINE, "shield")
    first_name = user["full_name"].split()[0]
    render(f'<div class="fg-card"><h4>Welcome back, {esc(first_name)}</h4>'
           '<p>Analyze a transaction, review your history, or compare the trained models.</p></div>')

    # ---- flagged transactions that still wait for a review
    try:
        unreviewed = database.count_unreviewed(user["id"])
    except database.DatabaseError:
        unreviewed = 0
    if unreviewed > 0:
        alert_col, button_col = st.columns([4, 1.5], vertical_alignment="center")
        with alert_col:
            notice("danger", tr("dash_alert", n=unreviewed))
        button_col.button(tr("dash_open_history"), key="dash_open_history",
                          on_click=go_to, args=("history",), width="stretch")

    bundle = data_service.dataset_bundle()
    comparison = data_service.comparison_table()

    # ---- KPI cards (all values come from the dataset / report files)
    section("Overview")
    if bundle:
        total, fraud, rate = f"{bundle['n_total']:,}", f"{bundle['n_fraud']:,}", f"{bundle['fraud_rate_pct']:.4f}%"
    else:
        total = fraud = rate = "-"
    if comparison is not None:
        best_model = comparison["PR-AUC"].idxmax()
        best_value, best_sub = f"{comparison['PR-AUC'].max():.4f}", short_model_name(best_model)
    else:
        best_value, best_sub = "-", "reports not found"
    kpi_row([
        kpi_card("Total transactions", total, "Credit card dataset", "database", "accent"),
        kpi_card("Fraud cases", fraud, "Confirmed in the dataset", "alert", "danger"),
        kpi_card("Fraud rate", rate, "Highly imbalanced", "target", "warn"),
        kpi_card("Best PR-AUC", best_value, best_sub, "trending", "ok"),
    ])
    if bundle is None:
        notice("warn", "Dataset not found at data/creditcard.csv - dataset KPIs are unavailable.")

    # ---- quick actions
    section("Quick actions")
    a, b, c = st.columns(3)
    a.button("Detect transaction", icon=":material/manage_search:", type="primary",
             key="qa_detect", on_click=go_to, args=("detect",), width="stretch")
    b.button("View analytics", icon=":material/analytics:", key="qa_analytics",
             on_click=go_to, args=("analytics",), width="stretch")
    c.button("Compare models", icon=":material/compare_arrows:", key="qa_models",
             on_click=go_to, args=("models",), width="stretch")

    # ---- recent predictions + model snapshot
    left, right = st.columns([1.7, 1], gap="large")
    with left:
        section("Recent predictions", "Your five most recent analyses")
        try:
            recent = database.get_predictions(user["id"], limit=5)
        except database.DatabaseError as exc:
            notice("danger", str(exc))
            recent = None
        if recent is None:
            pass
        elif recent.empty:
            empty_state("No predictions yet",
                        "Analyze your first transaction and it will appear here.", "search")
        else:
            rows = [[f"TX-{r.id:05d}", f"{r.amount:,.2f}", verdict_cell(r.prediction),
                     f"{r.probability * 100:.1f}%", r.created_at.strftime("%d %b %Y, %H:%M")]
                    for r in recent.itertuples()]
            html_table([tr("col_transaction"), tr("col_amount"), tr("col_verdict"),
                        "Probability", tr("col_datetime")],
                       rows, numeric=(1, 3),
                       row_tones=[row_tone(r.prediction) for r in recent.itertuples()])
    with right:
        section("Model snapshot", "PR-AUC on the held-out test set")
        if comparison is None:
            empty_state("No report found", "Run the model-improvement phase to generate it.", "bar")
        else:
            ordered = comparison["PR-AUC"].sort_values()
            p = palette()
            figure = go.Figure(go.Bar(
                x=ordered.values, y=[short_model_name(m) for m in ordered.index],
                orientation="h", text=[f"{v:.3f}" for v in ordered.values], textposition="outside",
                marker_color=[p["accent"] if m == ordered.index[-1] else p["border"] for m in ordered.index],
                hovertemplate="%{y}: %{x:.4f}<extra></extra>",
            ))
            layout = plotly_layout(height=290)
            layout["xaxis"]["range"] = [0, max(1.0, float(ordered.max()) * 1.15)]
            layout["margin"] = dict(l=10, r=40, t=10, b=10)
            layout["yaxis"]["automargin"] = True
            figure.update_layout(**layout)
            show_plotly(figure, "dash_leaderboard")
