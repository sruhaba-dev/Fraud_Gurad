"""Prediction History page (only the signed-in user's own records)."""

from __future__ import annotations

from datetime import datetime, timedelta

import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from app import database
from app.config import NOTE_MAX_LENGTH, REVIEW_STATUSES
from app.i18n import tr
from app.theme import palette, plotly_layout
from app.ui_components import (
    action_cell, empty_state, esc, html_table, kpi_card, kpi_row,
    notice, page_header, prob_bar_cell, reasons_block, render, review_badge,
    row_tone, section, show_plotly, status_badge, verdict_banner, verdict_cell,
    verdict_word,
)

QUICK_KEYS = ["all", "needs_review", "fraud", "suspicious", "safe"]
SORT_KEYS = ["newest", "risk", "amount"]
FLAGGED = ("FRAUD", "SUSPICIOUS")

# (review status saved in the database, text key of the radio option)
REVIEW_CHOICES = [
    ("CONFIRMED_FRAUD", "choice_confirm"),
    ("FALSE_ALARM", "choice_false"),
    ("APPROVED", "choice_approve"),
    ("PENDING", "choice_pending"),
]
_REVIEW_TEXT_KEY = {
    "PENDING": "review_pending",
    "CONFIRMED_FRAUD": "review_confirmed",
    "FALSE_ALARM": "review_false",
    "APPROVED": "review_approved",
}


# ------------------------------------------------------------ pure helpers
def needs_review_mask(frame: pd.DataFrame) -> pd.Series:
    """FRAUD or SUSPICIOUS rows whose review status is still PENDING."""
    return frame["prediction"].isin(FLAGGED) & (frame["review_status"] == "PENDING")


def apply_quick_filter(frame: pd.DataFrame, quick: str) -> pd.DataFrame:
    """All | Needs review | Fraud only | Suspicious only | Safe."""
    if quick == "needs_review":
        return frame[needs_review_mask(frame)]
    if quick == "fraud":
        return frame[frame["prediction"] == "FRAUD"]
    if quick == "suspicious":
        return frame[frame["prediction"] == "SUSPICIOUS"]
    if quick == "safe":
        return frame[frame["prediction"] == "NORMAL"]
    return frame


def apply_sort(frame: pd.DataFrame, sort_key: str) -> pd.DataFrame:
    """Newest first (default) | Highest risk first | Highest amount first."""
    if sort_key == "risk":
        return frame.sort_values("probability", ascending=False, kind="stable")
    if sort_key == "amount":
        return frame.sort_values("amount", ascending=False, kind="stable")
    return frame.sort_values(["created_at", "id"], ascending=False, kind="stable")


def fraud_amount_blocked(frame: pd.DataFrame) -> float:
    """Total amount of FRAUD rows that are not marked as a false alarm."""
    mask = (frame["prediction"] == "FRAUD") & (frame["review_status"] != "FALSE_ALARM")
    return float(frame.loc[mask, "amount"].sum())


def flagged_per_day(frame: pd.DataFrame, days: int = 7) -> pd.DataFrame:
    """Number of flagged (FRAUD / SUSPICIOUS) rows for each of the last `days` days."""
    today = datetime.now().astimezone().date()
    day_list = [today - timedelta(days=i) for i in range(days - 1, -1, -1)]
    flagged = frame[frame["prediction"].isin(FLAGGED)]
    counts = flagged["created_at"].dt.date.value_counts() if not flagged.empty else {}
    return pd.DataFrame({
        "day": day_list,
        "count": [int(counts.get(d, 0)) for d in day_list],
    })


def _csv_safe(value: str) -> str:
    """Stop spreadsheet programs from running text that starts like a formula."""
    text = str(value)
    return "'" + text if text[:1] in ("=", "+", "-", "@") else text


_CSV_VERDICT = {"FRAUD": "Fraud", "SUSPICIOUS": "Suspicious", "NORMAL": "Safe"}
_CSV_ACTION = {"FRAUD": "Block", "SUSPICIOUS": "Verify", "NORMAL": "OK"}


def export_frame(view: pd.DataFrame) -> pd.DataFrame:
    """CSV content: the old columns plus verdict, action, reasons, review status, note."""
    export = view.assign(
        created_at=view["created_at"].dt.strftime("%Y-%m-%d %H:%M:%S"),
        probability=(view["probability"] * 100).round(2),
    ).rename(columns={"created_at": "date_time", "probability": "fraud_probability_pct"})
    export["verdict"] = view["prediction"].map(_CSV_VERDICT)
    export["action"] = view["prediction"].map(_CSV_ACTION)
    export["reasons"] = view["reasons"].map(lambda items: "; ".join(items))
    export["note"] = view["note"].map(_csv_safe)
    columns = ["date_time", "amount", "prediction", "verdict", "action",
               "fraud_probability_pct", "risk_level", "model_name", "threshold",
               "reasons", "review_status", "note"]
    return export[columns]


# --------------------------------------------------------------- callbacks
def _show_needs_review() -> None:
    st.session_state["history_quick"] = "needs_review"


# -------------------------------------------------------------------- page
def render_history(user: dict) -> None:
    page_header("Prediction History", "Every transaction you analyzed, newest first.", "list")

    if st.session_state.pop("history_cleared", False):
        notice("ok", "Your prediction history was deleted.")

    if st.session_state.pop("history_review_saved", False):
        notice("ok", tr("review_saved"))

    # The "confirm_clear" checkbox can only be reset to its default value
    # *before* it is instantiated below. Doing it here (start of the run,
    # right after a successful clear) avoids StreamlitWidgetAlreadyInstantiatedError.
    if st.session_state.pop("reset_confirm_clear", False):
        st.session_state["confirm_clear"] = False

    try:
        history = database.get_predictions(user["id"])
        unreviewed = database.count_unreviewed(user["id"])
    except database.DatabaseError as exc:
        notice("danger", str(exc))
        return

    if history.empty:
        empty_state("No predictions yet",
                    "Use the Fraud Detection page to analyze a transaction. "
                    "Your results will be listed here.", "list")
        return

    # ---- alert: flagged transactions that nobody has reviewed yet
    if unreviewed > 0:
        alert_col, button_col = st.columns([4, 1.3], vertical_alignment="center")
        with alert_col:
            notice("danger", tr("hist_alert", n=unreviewed))
        button_col.button(tr("hist_show_only"), key="hist_show_needs_review",
                          on_click=_show_needs_review, width="stretch")

    # ---- KPI cards
    kpi_row([
        kpi_card("Total analyses", f"{len(history):,}", "", "activity", "accent"),
        kpi_card("Predicted fraud", f"{(history['prediction'] == 'FRAUD').sum():,}", "", "alert", "danger"),
        kpi_card("Suspicious", f"{(history['prediction'] == 'SUSPICIOUS').sum():,}", "", "clock", "warn"),
        kpi_card("Normal", f"{(history['prediction'] == 'NORMAL').sum():,}", "", "check", "ok"),
    ])
    fraud_count = int((history["prediction"] == "FRAUD").sum())
    kpi_row([
        kpi_card(tr("kpi_needs_review"), f"{int(needs_review_mask(history).sum()):,}",
                 tr("kpi_needs_review_sub"), "clock", "warn"),
        kpi_card(tr("kpi_blocked"), f"{fraud_amount_blocked(history):,.2f}",
                 tr("kpi_blocked_sub"), "dollar", "danger"),
        kpi_card(tr("kpi_rate"), f"{fraud_count / len(history) * 100:.1f}%",
                 tr("kpi_rate_sub"), "target", "accent"),
    ])

    # ---- filters
    section("Filters")
    st.radio(tr("quick_filter"), QUICK_KEYS, horizontal=True, key="history_quick",
             format_func=lambda k: tr(f"quick_{k}"))
    f1, f2, f3 = st.columns([2.2, 2, 1])
    choice = f1.radio("Prediction", ["All", "Normal", "Suspicious", "Fraud"], horizontal=True,
                      key="history_filter")
    query = f2.text_input("Search", placeholder="Search by model, amount, date or ID...",
                          key="history_search")
    page_size = f3.selectbox("Rows", [25, 50, 100], key="history_rows")

    g1, g2 = st.columns([2.2, 1.6])
    statuses = g1.multiselect(tr("review_filter"), list(REVIEW_STATUSES),
                              format_func=lambda k: tr(_REVIEW_TEXT_KEY[k]),
                              key="history_review_filter")
    sort_key = g2.selectbox(tr("sort_label"), SORT_KEYS, key="history_sort",
                            format_func=lambda k: tr(f"sort_{k}"))

    with st.expander(tr("more_filters")):
        d1, d2, a1, a2 = st.columns(4)
        date_from = d1.date_input(tr("date_from"), value=None, key="history_date_from")
        date_to = d2.date_input(tr("date_to"), value=None, key="history_date_to")
        amount_min = a1.number_input(tr("amount_min"), min_value=0.0, value=0.0, step=100.0,
                                     key="history_amount_min")
        amount_max = a2.number_input(tr("amount_max"), min_value=0.0, value=0.0, step=100.0,
                                     key="history_amount_max")

    view = apply_quick_filter(history, st.session_state.get("history_quick", "all"))
    if choice != "All":
        view = view[view["prediction"] == choice.upper()]
    if statuses:
        view = view[view["review_status"].isin(statuses)]
    if date_from:
        view = view[view["created_at"].dt.date >= date_from]
    if date_to:
        view = view[view["created_at"].dt.date <= date_to]
    if amount_min > 0:
        view = view[view["amount"] >= amount_min]
    if amount_max > 0:
        view = view[view["amount"] <= amount_max]
    if query.strip():
        needle = query.strip().lower()
        haystack = (view["model_name"].str.lower() + " " + view["amount"].map("{:,.2f}".format)
                    + " " + view["created_at"].dt.strftime("%d %b %Y %H:%M").str.lower()
                    + " tx-" + view["id"].map("{:05d}".format))
        view = view[haystack.str.contains(needle, regex=False)]
    view = apply_sort(view, sort_key)

    if view.empty:
        empty_state("No matching predictions", "Try a different filter or search term.", "search")
        shown = view
    else:
        shown = view.head(page_size)
        rows = [[f"TX-{r.id:05d}", verdict_cell(r.prediction), action_cell(r.prediction),
                 r.created_at.strftime("%d %b %Y, %H:%M:%S"), f"{r.amount:,.2f}",
                 prob_bar_cell(r.probability), status_badge(r.risk_level),
                 review_badge(r.review_status), esc(r.model_name)]
                for r in shown.itertuples()]
        html_table(
            [tr("col_id"), tr("col_verdict"), tr("col_action"), tr("col_datetime"),
             tr("col_amount"), tr("col_probability"), tr("col_risk"), tr("col_review"),
             tr("col_model")],
            rows, numeric=(4, 5),
            row_tones=[row_tone(r.prediction) for r in shown.itertuples()],
        )
        st.caption(tr("showing", shown=len(shown), total=len(view)))

        st.download_button(tr("download_csv"), export_frame(view).to_csv(index=False),
                           file_name="prediction_history.csv", mime="text/csv",
                           icon=":material/download:")

    _render_review_section(user, shown)

    with st.expander(tr("chart_expander")):
        days = flagged_per_day(history)
        p = palette()
        figure = go.Figure(go.Bar(
            x=[d.strftime("%d %b") for d in days["day"]], y=days["count"],
            name=tr("chart_series"), marker_color=p["danger"],
            hovertemplate="%{x}: %{y}<extra></extra>",
        ))
        layout = plotly_layout(height=220)
        layout["title"] = {"text": tr("chart_title"), "font": {"size": 13}}
        layout["yaxis"]["dtick"] = 1
        layout["margin"] = dict(l=10, r=10, t=40, b=10)
        figure.update_layout(**layout)
        show_plotly(figure, "history_flagged_chart")

    with st.expander("Danger zone"):
        st.caption("Permanently deletes only YOUR prediction history. This cannot be undone.")
        confirm = st.checkbox("I understand, delete my history", key="confirm_clear")
        if st.button("Delete my prediction history", disabled=not confirm, key="clear_history"):
            try:
                database.clear_predictions(user["id"])
            except database.DatabaseError as exc:
                notice("danger", str(exc))
            else:
                st.session_state["history_cleared"] = True
                st.session_state["reset_confirm_clear"] = True
                st.session_state.pop("last_result", None)
                st.rerun()


def _render_review_section(user: dict, shown: pd.DataFrame) -> None:
    """Pick one shown transaction, see why it was flagged and save a review."""
    section(tr("review_section"), tr("review_section_sub"))

    if shown.empty:
        notice("info", tr("review_no_rows"))
        return

    # flagged transactions first (the current order is kept inside each group)
    candidates = shown.assign(_not_flagged=(~shown["prediction"].isin(FLAGGED)).astype(int))
    candidates = candidates.sort_values("_not_flagged", kind="stable")
    labels = {
        int(r.id): f"TX-{r.id:05d} · {verdict_word(r.prediction)} · {r.amount:,.2f}"
        for r in candidates.itertuples()
    }

    picked = st.selectbox(tr("review_pick"), list(labels), key="review_pick",
                          format_func=lambda i: labels[i])
    row = candidates[candidates["id"] == picked].iloc[0]

    render(verdict_banner(row["prediction"]))
    render(f'<div class="fg-meta"><span>{esc(tr("prob_label"))}: '
           f'<b>{row["probability"] * 100:.1f}%</b></span>'
           f'<span>{esc(tr("col_review"))}: {review_badge(row["review_status"])}</span></div>')
    if row["reasons"]:
        render(reasons_block(row["reasons"]))
    else:
        notice("info", tr("review_no_reasons"))

    order = [status for status, _ in REVIEW_CHOICES]
    current = row["review_status"] if row["review_status"] in order else "PENDING"
    text_for = dict(REVIEW_CHOICES)
    decision = st.radio(tr("review_decision"), order, index=order.index(current),
                        format_func=lambda s: tr(text_for[s]), horizontal=True,
                        key=f"review_choice_{picked}")
    note = st.text_input(tr("review_note"), value=row["note"], max_chars=NOTE_MAX_LENGTH,
                         key=f"review_note_{picked}")

    if st.button(tr("review_save"), type="primary", key="review_save",
                 icon=":material/save:"):
        try:
            saved = database.update_review(user["id"], int(picked), decision, note)
        except database.DatabaseError as exc:
            notice("danger", str(exc))
            return
        if saved:
            st.session_state["history_review_saved"] = True
            st.rerun()
        else:
            notice("danger", tr("review_failed"))
