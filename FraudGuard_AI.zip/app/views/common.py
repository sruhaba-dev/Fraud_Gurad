"""Small helpers shared by several views."""

from __future__ import annotations


_SHORT_NAMES = {
    "Random Forest — Baseline": "RF Baseline",
    "K-Nearest Neighbors — KNN": "KNN",
    "Random Forest — Tuned": "RF Tuned",
    "KNN — Tuned": "KNN Tuned",
}


def short_model_name(report_name: str) -> str:
    """Compact label for charts."""
    return _SHORT_NAMES.get(report_name, report_name)