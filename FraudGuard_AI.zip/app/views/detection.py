"""Fraud Detection page for the current transaction dataset."""

from __future__ import annotations

from datetime import datetime

import pandas as pd
import streamlit as st

from app import data_service, database, model_service
from app.config import FEATURE_COLUMNS, SUSPICIOUS_FRACTION
from app.ui_components import (
    empty_state,
    esc,
    gauge_figure,
    html_table,
    kpi_card,
    notice,
    page_header,
    render,
    result_card,
    result_panel,
    show_plotly,
    toast_for,
)


MERCHANT_MIN = 1
MERCHANT_MAX = 1000  # MerchantID range found in the dataset


def _defaults() -> dict:
    now = datetime.now().replace(second=0, microsecond=0)

    return {
        "Amount": 100.0,
        "TransactionType": "purchase",
        "MerchantID": 100,
        "Location": "New York",
        "TransactionDate": now.date(),
        "TransactionTime": now.time(),
    }


def _input_key(column: str) -> str:
    return f"in_{column}"


def _reset_form() -> None:
    for column, value in _defaults().items():
        st.session_state[_input_key(column)] = value
    st.session_state.pop("sample_ref", None)
    st.session_state.pop("dataset_check", None)


def _load_sample(kind: str) -> None:
    """Fill the form with a real transaction from the held-out test set."""
    bundle = data_service.dataset_bundle()
    pool = bundle["samples"][kind] if bundle else None

    if pool is None or pool.empty:
        return

    row = pool.sample(1).iloc[0]

    when = pd.to_datetime(row["TransactionDate"]).to_pydatetime().replace(
        second=0, microsecond=0
    )

    st.session_state[_input_key("Amount")] = float(row["Amount"])
    st.session_state[_input_key("TransactionType")] = str(row["TransactionType"])
    st.session_state[_input_key("MerchantID")] = int(row["MerchantID"])
    st.session_state[_input_key("Location")] = str(row["Location"])
    st.session_state[_input_key("TransactionDate")] = when.date()
    st.session_state[_input_key("TransactionTime")] = when.time()

    st.session_state["sample_ref"] = {
        "label": "Fraud" if kind == "fraud" else "Normal",
        "values": {
            "Amount": float(row["Amount"]),
            "TransactionType": str(row["TransactionType"]),
            "MerchantID": int(row["MerchantID"]),
            "Location": str(row["Location"]),
            "TransactionDate": when,
        },
    }


def _analyze(user: dict, spec) -> None:
    """Validate -> predict -> save to history."""
    values = {
        "Amount": st.session_state[_input_key("Amount")],
        "TransactionType": st.session_state[_input_key("TransactionType")],
        "MerchantID": st.session_state[_input_key("MerchantID")],
        "Location": st.session_state[_input_key("Location")],
        "TransactionDate": datetime.combine(
            st.session_state[_input_key("TransactionDate")],
            st.session_state[_input_key("TransactionTime")],
        ),
    }

    try:
        result = model_service.predict(spec, values)
    except model_service.ModelServiceError as exc:
        st.session_state["last_error"] = str(exc)
        st.session_state.pop("last_result", None)
        return

    saved = True

    try:
        database.add_prediction(
            user["id"],
            values["Amount"],
            result.label,
            result.probability,
            result.risk_level,
            result.model_name,
            result.threshold,
            reasons=result.reasons,
        )
    except database.DatabaseError:
        saved = False

    reference = st.session_state.get("sample_ref")
    dataset_label = None

    if reference:
        same_amount = abs(
            values["Amount"] - reference["values"]["Amount"]
        ) < 1e-9

        same_type = (
            values["TransactionType"]
            == reference["values"]["TransactionType"]
        )

        same_location = (
            values["Location"]
            == reference["values"]["Location"]
        )

        same_merchant = (
            int(values["MerchantID"])
            == reference["values"]["MerchantID"]
        )

        same_date = (
            values["TransactionDate"].replace(second=0, microsecond=0)
            == reference["values"]["TransactionDate"]
        )

        if (
            same_amount
            and same_type
            and same_location
            and same_merchant
            and same_date
        ):
            dataset_label = reference["label"]

    st.session_state["last_result"] = {
        "result": result,
        "saved": saved,
        "dataset_label": dataset_label,
        # show the toast only once for this analysis
        "announce": True,
    }

    st.session_state.pop("last_error", None)


def _check_dataset() -> None:
    """Look the entered transaction up in the dataset and store the answer."""

    values = {
        "Amount": st.session_state[_input_key("Amount")],
        "TransactionType": st.session_state[_input_key("TransactionType")],
        "MerchantID": st.session_state[_input_key("MerchantID")],
        "Location": st.session_state[_input_key("Location")],
    }

    result = data_service.find_in_dataset(values)

    if result is not None:
        result["entered"] = values

    st.session_state["dataset_check"] = result or {"unavailable": True}


_CHECK_TONE = {
    "FRAUD": "danger",
    "NOT FRAUD": "ok",
    "MIXED": "warn",
    "SUSPICIOUS": "warn",
    "NOT FOUND": "info",
}


def _record_text(record: dict) -> str:
    verdict = "fraud" if record["IsFraud"] == 1 else "normal"
    return (
        f"ID {record['TransactionID']} on "
        f"{str(record['TransactionDate'])[:16]} ({verdict})"
    )


def _check_reasons(check: dict) -> list[str]:
    """Plain-language reasons for the dataset status."""

    status = check["status"]
    entered = check["entered"]
    merchant = int(entered["MerchantID"])
    reasons: list[str] = []

    if status in ("FRAUD", "NOT FRAUD", "MIXED"):
        reasons.append(
            f"The same Amount, Merchant ID, Transaction Type and Location "
            f"appear {check['n']} time(s) in the dataset: "
            f"{check['n_fraud']} marked fraud and "
            f"{check['n'] - check['n_fraud']} marked normal."
        )
        reasons.append(
            "Records: "
            + "; ".join(_record_text(r) for r in check["records"])
            + "."
        )

    if status == "SUSPICIOUS":
        reasons.append(
            "No record with this exact Amount, Merchant ID, Transaction Type "
            "and Location exists in the dataset."
        )

        if check["merchant_amount_fraud"] > 0:
            reasons.append(
                f"Merchant {merchant} has a FRAUD record with the same "
                f"Amount ({check['merchant_amount_fraud']} found)."
            )

    if status == "NOT FOUND":
        reasons.append(
            "No record with this exact Amount, Merchant ID, Transaction Type "
            "and Location exists in the dataset."
        )
        reasons.append(
            f"Merchant {merchant} has no fraud record in the dataset "
            f"({check['merchant_total']} record(s) in total)."
        )
        reasons.append(
            "The dataset cannot say anything about this transaction. "
            "Press Analyze transaction to get the model's estimate."
        )

    # extra context for every status except NOT FOUND (already explained)
    if status != "NOT FOUND" and check["merchant_fraud"] > 0:
        reasons.append(
            f"Merchant {merchant}: {check['merchant_fraud']} fraud record(s) "
            f"out of {check['merchant_total']} in the dataset "
            f"({'; '.join(_record_text(r) for r in check['merchant_fraud_records'])})."
        )

    return reasons


def _show_dataset_check(check: dict) -> None:
    """Show the status, the reasons and a field-by-field comparison."""

    if check.get("unavailable"):
        notice(
            "warn",
            "The dataset could not be read, so nothing could be checked.",
        )
        return

    status = check["status"]

    notice(
        _CHECK_TONE[status],
        [f"Dataset check: {status}"] + _check_reasons(check),
    )

    reference = check.get("reference")

    if not reference:
        return

    entered = check["entered"]

    pairs = [
        ("Amount", f"{float(entered['Amount']):,.2f}",
         f"{float(reference['Amount']):,.2f}",
         abs(float(entered["Amount"]) - float(reference["Amount"])) < 0.005),
        ("Merchant ID", str(int(entered["MerchantID"])),
         str(int(reference["MerchantID"])),
         int(entered["MerchantID"]) == int(reference["MerchantID"])),
        ("Transaction Type", str(entered["TransactionType"]),
         str(reference["TransactionType"]),
         str(entered["TransactionType"]).lower()
         == str(reference["TransactionType"]).lower()),
        ("Location", str(entered["Location"]),
         str(reference["Location"]),
         str(entered["Location"]) == str(reference["Location"])),
    ]

    st.caption(
        "Comparison with dataset record "
        f"ID {reference['TransactionID']} "
        f"({'fraud' if reference['IsFraud'] == 1 else 'normal'})"
    )

    html_table(
        ["Field", "You entered", "Dataset record", "Match"],
        [
            [esc(name), esc(mine), esc(theirs), "✔" if ok else "✘"]
            for name, mine, theirs, ok in pairs
        ],
        row_tones=["ok" if ok else "danger" for *_, ok in pairs],
    )


def render_detection(user: dict) -> None:
    page_header(
        "Fraud Detection",
        "Analyze a transaction using the trained machine learning model.",
        "search",
    )

    specs = {
        s.key: s
        for s in model_service.available_models()
    }

    if not specs:
        notice(
            "danger",
            "The KNN model file was not found in the models folder. "
            "Run train_knn.py first.",
        )
        return

    # Only one model is used: KNN (no model selector).
    spec = next(iter(specs.values()))
    st.session_state["model_key"] = spec.key

    for column, value in _defaults().items():
        st.session_state.setdefault(
            _input_key(column),
            value,
        )

    top_mid, top_right = st.columns(
        2,
        vertical_alignment="bottom",
        gap="medium",
    )

    threshold = model_service.decision_threshold(spec)

    with top_mid:
        render(
            kpi_card(
                "Decision threshold",
                f"{threshold:.2f}",
                "Fraud if probability ≥",
                "target",
                "accent",
            )
        )

    with top_right:
        render(
            kpi_card(
                "Review band",
                f"{threshold * SUSPICIOUS_FRACTION:.2f}",
                "Suspicious if probability ≥",
                "alert",
                "warn",
            )
        )

    st.caption(spec.description)

    reset_col, _ = st.columns([0.8, 4.2])

    reset_col.button(
        "Reset",
        icon=":material/restart_alt:",
        key="reset_form",
        on_click=_reset_form,
        width="stretch",
    )

    form_col, result_col = st.columns(
        [1.55, 1],
        gap="large",
    )

    # ---------------------------------------------------------------
    # Input form
    # ---------------------------------------------------------------
    with form_col:
        with st.form("detect_form"):

            render(
                '<div class="fg-section" style="margin-top:0">'
                "<h3>Transaction information</h3>"
                "<p>Enter the basic transaction details.</p>"
                "</div>"
            )

            amount_col, type_col = st.columns(2)

            with amount_col:
                st.number_input(
                    "Amount",
                    key=_input_key("Amount"),
                    min_value=0.0,
                    step=1.0,
                    format="%.2f",
                    help="Transaction amount.",
                )

            with type_col:
                st.radio(
                    "Transaction Type",
                    ["purchase", "refund"],
                    key=_input_key("TransactionType"),
                    horizontal=True,
                    help="Type of transaction.",
                )

            merchant_col, location_col = st.columns(2)

            with merchant_col:
                st.number_input(
                    "Merchant ID",
                    key=_input_key("MerchantID"),
                    min_value=MERCHANT_MIN,
                    max_value=MERCHANT_MAX,
                    step=1,
                    help=(
                        f"Merchant number "
                        f"({MERCHANT_MIN}-{MERCHANT_MAX} in the dataset)."
                    ),
                )

            with location_col:
                st.selectbox(
                    "Location",
                    data_service.location_options(),
                    key=_input_key("Location"),
                    help="Transaction location.",
                )

            date_col, time_col = st.columns(2)

            with date_col:
                st.date_input(
                    "Transaction date",
                    key=_input_key("TransactionDate"),
                    format="YYYY-MM-DD",
                    help="Date of the transaction.",
                )

            with time_col:
                st.time_input(
                    "Transaction time",
                    key=_input_key("TransactionTime"),
                    step=60,
                    help="Time of the transaction.",
                )

            render(
                '<div class="fg-explain" '
                'style="margin:.2rem 0 .8rem 0">'
                "The model derives hour, day, month and day-of-week "
                "from the date and time above."
                "</div>"
            )

            submitted = st.form_submit_button(
                "Analyze transaction",
                icon=":material/search:",
                type="primary",
                width="stretch",
            )

            checked = st.form_submit_button(
                "Check in dataset",
                icon=":material/fact_check:",
                width="stretch",
                help=(
                    "Looks for the same Amount, Merchant ID, Transaction Type "
                    "and Location in the dataset and tells you if it was fraud."
                ),
            )

        if submitted:
            st.session_state.pop("dataset_check", None)
            with st.spinner("Analyzing transaction..."):
                _analyze(user, spec)

        if checked:
            _check_dataset()

    # ---------------------------------------------------------------
    # Result
    # ---------------------------------------------------------------
    with result_col:

        if error := st.session_state.get("last_error"):
            notice("danger", error)

        if dataset_check := st.session_state.get("dataset_check"):
            _show_dataset_check(dataset_check)

        outcome = st.session_state.get("last_result")

        if not outcome:
            empty_state(
                "No analysis yet",
                "Enter the transaction details and press "
                "Analyze transaction to see the fraud probability.",
                "shield",
            )

        else:
            result = outcome["result"]

            # Reading order: banner -> action -> reasons -> probability + gauge -> meta
            result_panel(
                result,
                outcome["dataset_label"],
                gauge_key="detect_gauge",
            )

            if outcome.pop("announce", False):
                toast_for(result.label)

            if outcome["saved"]:
                notice(
                    "info",
                    "Saved to your prediction history.",
                )
            else:
                notice(
                    "warn",
                    "The result could not be saved to your history.",
                )