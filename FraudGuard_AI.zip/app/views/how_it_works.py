"""How It Works: fraud detection prediction flow and project pipeline."""

from __future__ import annotations

from app import data_service, model_service
from app.config import DEFAULT_THRESHOLD, FEATURE_COLUMNS, SUSPICIOUS_FRACTION
from app.ui_components import esc, page_header, render, section


FLOW = [
    (
        "Transaction input",
        "Enter the amount, merchant ID, transaction type, location, date and time.",
    ),
    (
        "Feature engineering",
        "Transaction date information is converted into hour, day, month and day-of-week features.",
    ),
    (
        "Data preprocessing",
        "Numerical features are scaled and categorical features are encoded using the saved training preprocessor.",
    ),
    (
        "Machine learning model",
        "The trained KNN model analyzes the processed transaction.",
    ),
    (
        "Fraud probability",
        "The model produces a probability indicating how likely the transaction is to be fraudulent.",
    ),
    (
        "Risk classification",
        "The probability is compared with the configured decision threshold.",
    ),
    (
        "Final prediction",
        "The transaction is classified as Normal, Suspicious or Fraud and the result is saved to history.",
    ),
]


def _phases(dataset_size: str) -> list[tuple[str, str]]:
    return [
        (
            "Dataset",
            f"The new credit card fraud dataset contains {dataset_size} transactions "
            "with transaction amount, transaction date, merchant, transaction type, "
            "location and fraud labels.",
        ),
        (
            "Feature engineering",
            "TransactionID is not used for prediction. MerchantID is used as a "
            "numeric feature. "
            "TransactionDate is converted into hour, day, month and day-of-week features.",
        ),
        (
            "Preprocessing",
            "Numerical features are standardized and categorical features such as "
            "TransactionType and Location are one-hot encoded. The preprocessor is "
            "fitted on the training data only to prevent data leakage.",
        ),
        (
            "Baseline model training",
            "A K-Nearest Neighbors (KNN) model is trained. The training split "
            "uses stratification to preserve the fraud-to-normal class ratio.",
        ),
        (
            "Model evaluation",
            "The models are evaluated on the untouched test set using Precision, "
            "Recall, F1-Score, PR-AUC, ROC-AUC, Accuracy and the confusion matrix.",
        ),
        (
            "Model improvement",
            "Random Forest and KNN are tuned using cross-validation on the training "
            "data. Tuned models are saved separately from the baseline models.",
        ),
        (
            "Prediction",
            "The application loads the saved preprocessor and trained model files. "
            "When a transaction is analyzed, the model predicts its fraud probability "
            "without retraining the model.",
        ),
    ]


def render_how_it_works() -> None:
    page_header(
        "How It Works",
        "From transaction details to an AI-powered fraud risk decision.",
        "cpu",
    )

    # -------------------------------------------------------------
    # Prediction pipeline
    # -------------------------------------------------------------
    section("Prediction pipeline")

    parts = []

    for i, (title, text) in enumerate(FLOW, start=1):
        parts.append(
            f'<div class="fg-step">'
            f'<div class="n">{i}</div>'
            f'<div class="t">{esc(title)}</div>'
            f'<div class="d">{esc(text)}</div>'
            f"</div>"
        )

        if i < len(FLOW):
            parts.append(
                '<div class="fg-arrow">&rsaquo;</div>'
            )

    render(
        f'<div class="fg-flow">{"".join(parts)}</div>'
    )

    # -------------------------------------------------------------
    # Risk classification
    # -------------------------------------------------------------
    key = model_service.default_model_key()

    threshold = DEFAULT_THRESHOLD

    if key:
        from app.config import MODEL_REGISTRY

        threshold = model_service.decision_threshold(
            MODEL_REGISTRY[key]
        )

    lower = threshold * SUSPICIOUS_FRACTION

    section(
        "Risk classification",
        "How the fraud probability is converted into a risk level.",
    )

    render(
        f"""
        <div class="fg-card">
          <div class="fg-band">
            <div style="width:{lower * 100:.1f}%;background:var(--ok)"></div>
            <div style="width:{(threshold - lower) * 100:.1f}%;background:var(--warn)"></div>
            <div style="width:{(1 - threshold) * 100:.1f}%;background:var(--danger)"></div>
          </div>

          <p>
            <span class="fg-badge ok">NORMAL / LOW</span>
            below {lower:.2f}
            &nbsp;&nbsp;

            <span class="fg-badge warn">SUSPICIOUS / MEDIUM</span>
            {lower:.2f} to {threshold:.2f}
            &nbsp;&nbsp;

            <span class="fg-badge danger">FRAUD / HIGH</span>
            {threshold:.2f} and above
          </p>

          <p style="margin-top:.6rem">
            The decision threshold determines when a transaction is classified
            as fraud. A lower threshold can flag more transactions for review,
            while a higher threshold can reduce false alarms. The suspicious
            range acts as a review zone below the fraud threshold.
          </p>

          <p style="margin-top:.6rem">
            These predictions are statistical model estimates and should be
            treated as risk indicators rather than proof of fraud.
          </p>
        </div>
        """
    )

    # -------------------------------------------------------------
    # Project phases
    # -------------------------------------------------------------
    bundle = data_service.dataset_bundle()

    size = (
        f"{bundle['n_total']:,}"
        if bundle
        else "100,000"
    )

    section("The project pipeline")

    items = "".join(
        f'<div class="fg-tl-item" data-n="{i}">'
        f'<div class="fg-card">'
        f"<h4>{esc(title)}</h4>"
        f"<p>{esc(text)}</p>"
        f"</div>"
        f"</div>"
        for i, (title, text) in enumerate(
            _phases(size),
            start=1,
        )
    )

    render(
        f'<div class="fg-timeline">{items}</div>'
    )

    # -------------------------------------------------------------
    # Features used by the application
    # -------------------------------------------------------------
    section("Features used by the model")

    feature_text = ", ".join(
        str(feature)
        for feature in FEATURE_COLUMNS
    )

    render(
        f"""
        <div class="fg-card">
          <p>
            <strong>Model input features:</strong>
            {esc(feature_text)}
          </p>

          <p style="margin-top:.6rem">
            The original V1-V28 PCA features from the previous dataset
            are not used in this version of FraudGuard.
          </p>
        </div>
        """
    )