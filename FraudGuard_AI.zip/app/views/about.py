"""About page."""

from __future__ import annotations

from app import data_service
from app.config import APP_NAME, APP_TAGLINE
from app.ui_components import (
    card,
    esc,
    kpi_card,
    kpi_row,
    notice,
    page_header,
    render,
    section,
)

TECHNOLOGIES = [
    "Python",
    "Pandas",
    "NumPy",
    "Scikit-learn",
    "Random Forest",
    "K-Nearest Neighbors",
    "Streamlit",
    "Plotly",
    "SQLite",
]


def render_about() -> None:
    page_header("About", f"{APP_NAME} - {APP_TAGLINE}", "info")

    card(
        "Project",
        "Credit Card Fraud Detection System is a university machine-learning project. "
        "It covers the complete workflow: exploratory analysis, feature engineering, "
        "preprocessing, baseline model training, evaluation with imbalance-aware metrics, "
        "model improvement, and this web application for interactive fraud prediction.",
    )

    section("Technology")
    render("".join(f'<span class="fg-chip">{esc(t)}</span>' for t in TECHNOLOGIES))

    section("Dataset")
    bundle = data_service.dataset_bundle()

    if bundle:
        kpi_row([
            kpi_card(
                "Dataset",
                "Credit Card Fraud Detection",
                "100,000 transaction records",
                "database",
                "accent",
            ),
            kpi_card(
                "Transactions",
                f"{bundle['n_total']:,}",
                "",
                "activity",
                "accent",
            ),
            kpi_card(
                "Fraud cases",
                f"{bundle['n_fraud']:,}",
                f"{bundle['fraud_rate_pct']:.4f}% of all",
                "alert",
                "danger",
            ),
        ])
    else:
        notice(
            "warn",
            "The dataset file was not found, so dataset facts cannot be displayed.",
        )

    section("Models")
    card(
        "Baseline and improved models",
        "The system uses Random Forest and K-Nearest Neighbors (KNN) as baseline models. "
        "Tuned versions are also evaluated using the same preprocessing pipeline. "
        "The original V1-V28 feature set is not used in this project.",
    )

    section("Important note")
    card(
        "Educational use only",
        "This application demonstrates machine-learning concepts. Predictions are statistical "
        "estimates and must not be used to make real financial or security decisions.",
    )