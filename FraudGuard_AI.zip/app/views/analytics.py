"""Analytics page: interactive charts built from the new fraud dataset."""

from __future__ import annotations

import plotly.graph_objects as go
import streamlit as st

from app import data_service
from app.theme import palette, plotly_layout
from app.ui_components import (
    card,
    empty_state,
    html_table,
    kpi_card,
    kpi_row,
    notice,
    page_header,
    section,
    show_plotly,
)


def render_analytics() -> None:
    page_header(
        "Analytics",
        "Exploratory analysis of the new credit card transaction dataset.",
        "bar",
    )

    bundle = data_service.dataset_bundle()

    if bundle is None:
        empty_state(
            "Dataset not available",
            "data/creditcard.csv could not be read, so the analytics cannot be built.",
            "database",
        )
        return

    p = palette()

    # -------------------------------------------------------------
    # KPI OVERVIEW
    # -------------------------------------------------------------
    kpi_row(
        [
            kpi_card(
                "Total transactions",
                f"{bundle['n_total']:,}",
                "",
                "database",
                "accent",
            ),
            kpi_card(
                "Normal transactions",
                f"{bundle['n_normal']:,}",
                "",
                "check",
                "ok",
            ),
            kpi_card(
                "Fraud transactions",
                f"{bundle['n_fraud']:,}",
                "",
                "alert",
                "danger",
            ),
            kpi_card(
                "Fraud rate",
                f"{bundle['fraud_rate_pct']:.4f}%",
                "",
                "target",
                "warn",
            ),
        ]
    )

    tab_class, tab_amount, tab_type, tab_location, tab_time, tab_corr = st.tabs(
        [
            "Class Balance",
            "Transaction Amount",
            "Transaction Type",
            "Location",
            "Transaction Time",
            "Correlation",
        ]
    )

    # =============================================================
    # CLASS BALANCE
    # =============================================================
    with tab_class:
        left, right = st.columns([1.3, 1], gap="large")

        with left:
            figure = go.Figure(
                go.Bar(
                    x=["Normal", "Fraud"],
                    y=[
                        bundle["n_normal"],
                        bundle["n_fraud"],
                    ],
                    marker_color=[
                        p["accent"],
                        p["danger"],
                    ],
                    text=[
                        f"{bundle['n_normal']:,}",
                        f"{bundle['n_fraud']:,}",
                    ],
                    textposition="outside",
                    hovertemplate="%{x}: %{y:,}<extra></extra>",
                )
            )

            layout = plotly_layout(height=360)
            layout["title"]["text"] = "Transactions by class"
            layout["yaxis"]["range"] = [
                0,
                bundle["n_normal"] * 1.12,
            ]

            figure.update_layout(**layout)

            show_plotly(
                figure,
                "an_class_bar",
            )

        with right:
            ratio = bundle["n_normal"] / max(
                bundle["n_fraud"],
                1,
            )

            normal_share = (
                bundle["n_normal"]
                / bundle["n_total"]
                * 100
            )

            card(
                "Extreme class imbalance",
                f"Only {bundle['fraud_rate_pct']:.4f}% "
                f"of transactions are fraudulent — roughly "
                f"1 fraud for every {ratio:,.0f} normal transactions.",
            )

            st.write("")

            card(
                "Why accuracy is misleading",
                f"A model that labels every transaction as "
                f"'Normal' would achieve about "
                f"{normal_share:.2f}% accuracy while detecting "
                "zero fraud cases. This is why the project also "
                "uses Precision, Recall, F1-Score and PR-AUC.",
            )

    # =============================================================
    # TRANSACTION AMOUNT
    # =============================================================
    with tab_amount:
        overall = bundle["amount_overall"]

        kpi_row(
            [
                kpi_card(
                    "Minimum",
                    f"{overall['min']:,.2f}",
                    "",
                    "activity",
                    "accent",
                ),
                kpi_card(
                    "Median",
                    f"{overall['median']:,.2f}",
                    "",
                    "activity",
                    "accent",
                ),
                kpi_card(
                    "Mean",
                    f"{overall['mean']:,.2f}",
                    "",
                    "activity",
                    "accent",
                ),
                kpi_card(
                    "Maximum",
                    f"{overall['max']:,.2f}",
                    "",
                    "activity",
                    "accent",
                ),
            ]
        )

        edges = bundle["amount_edges"]
        centers = [
            (edges[i] + edges[i + 1]) / 2
            for i in range(len(edges) - 1)
        ]

        figure = go.Figure()

        figure.add_bar(
            x=centers,
            y=bundle["amount_normal_pct"],
            name="Normal",
            marker_color=p["accent"],
            opacity=0.62,
            hovertemplate=(
                "Normal: %{y:.2f}% of class"
                "<extra></extra>"
            ),
        )

        figure.add_bar(
            x=centers,
            y=bundle["amount_fraud_pct"],
            name="Fraud",
            marker_color=p["danger"],
            opacity=0.62,
            hovertemplate=(
                "Fraud: %{y:.2f}% of class"
                "<extra></extra>"
            ),
        )

        layout = plotly_layout(height=380)
        layout["barmode"] = "overlay"
        layout["title"]["text"] = (
            "Transaction amount distribution by class"
        )
        layout["xaxis"]["title"] = "Transaction Amount"
        layout["yaxis"]["title"] = "% of class"
        layout["legend"].update(
            orientation="h",
            y=-0.15,
        )

        figure.update_layout(**layout)

        show_plotly(
            figure,
            "an_amount_hist",
        )

        section("Amount statistics by class")

        stats = bundle["amount_stats"]

        rows = []

        for name, row in stats.iterrows():
            rows.append(
                [
                    name,
                    f"{row['count']:,.0f}",
                    f"{row['mean']:,.2f}",
                    f"{row['median']:,.2f}",
                    f"{row['std']:,.2f}",
                    f"{row['min']:,.2f}",
                    f"{row['max']:,.2f}",
                ]
            )

        html_table(
            [
                "Class",
                "Count",
                "Mean",
                "Median",
                "Std",
                "Min",
                "Max",
            ],
            rows,
            numeric=(1, 2, 3, 4, 5, 6),
        )

    # =============================================================
    # TRANSACTION TYPE
    # =============================================================
    with tab_type:
        type_data = bundle["transaction_type"]

        if type_data is None or type_data.empty:
            empty_state(
                "Transaction type data unavailable",
                "No transaction type analysis is available.",
                "database",
            )
        else:
            left, right = st.columns(
                [1.2, 1],
                gap="large",
            )

            with left:
                figure = go.Figure()

                figure.add_bar(
                    x=type_data.index.astype(str),
                    y=type_data["total"],
                    name="Total",
                    marker_color=p["accent"],
                    text=type_data["total"],
                    textposition="outside",
                )

                layout = plotly_layout(height=360)
                layout["title"]["text"] = (
                    "Transactions by transaction type"
                )
                layout["xaxis"]["title"] = "Transaction Type"
                layout["yaxis"]["title"] = "Transactions"

                figure.update_layout(**layout)

                show_plotly(
                    figure,
                    "an_type_total",
                )

            with right:
                figure = go.Figure()

                figure.add_bar(
                    x=type_data.index.astype(str),
                    y=type_data["fraud_rate_pct"],
                    marker_color=p["danger"],
                    text=[
                        f"{value:.3f}%"
                        for value in type_data["fraud_rate_pct"]
                    ],
                    textposition="outside",
                    hovertemplate=(
                        "%{x}: %{y:.3f}% fraud rate"
                        "<extra></extra>"
                    ),
                )

                layout = plotly_layout(height=360)
                layout["title"]["text"] = (
                    "Fraud rate by transaction type"
                )
                layout["xaxis"]["title"] = "Transaction Type"
                layout["yaxis"]["title"] = "Fraud Rate (%)"

                figure.update_layout(**layout)

                show_plotly(
                    figure,
                    "an_type_fraud_rate",
                )

            section("Transaction type statistics")

            rows = []

            for name, row in type_data.iterrows():
                rows.append(
                    [
                        str(name),
                        f"{int(row['total']):,}",
                        f"{int(row['fraud']):,}",
                        f"{row['fraud_rate_pct']:.4f}%",
                    ]
                )

            html_table(
                [
                    "Transaction Type",
                    "Total",
                    "Fraud",
                    "Fraud Rate",
                ],
                rows,
                numeric=(1, 2),
            )

    # =============================================================
    # LOCATION
    # =============================================================
    with tab_location:
        location_data = bundle["location"]

        if location_data is None or location_data.empty:
            empty_state(
                "Location data unavailable",
                "No location analysis is available.",
                "database",
            )
        else:
            figure = go.Figure()

            ordered = location_data.sort_values(
                "fraud_rate_pct"
            )

            figure.add_bar(
                x=ordered["fraud_rate_pct"],
                y=ordered.index.astype(str),
                orientation="h",
                marker_color=p["danger"],
                text=[
                    f"{value:.3f}%"
                    for value in ordered["fraud_rate_pct"]
                ],
                textposition="outside",
                hovertemplate=(
                    "%{y}: %{x:.3f}% fraud rate"
                    "<extra></extra>"
                ),
            )

            layout = plotly_layout(height=450)
            layout["title"]["text"] = (
                "Fraud rate by location"
            )
            layout["xaxis"]["title"] = "Fraud Rate (%)"
            layout["yaxis"]["title"] = "Location"

            figure.update_layout(**layout)

            show_plotly(
                figure,
                "an_location_fraud_rate",
            )

            section("Location statistics")

            rows = []

            for name, row in location_data.iterrows():
                rows.append(
                    [
                        str(name),
                        f"{int(row['total']):,}",
                        f"{int(row['fraud']):,}",
                        f"{row['fraud_rate_pct']:.4f}%",
                    ]
                )

            html_table(
                [
                    "Location",
                    "Total",
                    "Fraud",
                    "Fraud Rate",
                ],
                rows,
                numeric=(1, 2),
            )

    # =============================================================
    # TRANSACTION TIME
    # =============================================================
    with tab_time:
        hourly = bundle["hourly"]

        if hourly is None or hourly.empty:
            empty_state(
                "Time data unavailable",
                "Transaction date information could not be analyzed.",
                "schedule",
            )
        else:
            notice(
                "info",
                "Transaction time is extracted from the "
                "TransactionDate field of the new dataset.",
            )

            left, right = st.columns(
                2,
                gap="large",
            )

            with left:
                figure = go.Figure(
                    go.Bar(
                        x=hourly.index,
                        y=hourly["total"],
                        marker_color=p["accent"],
                        hovertemplate=(
                            "Hour %{x}: %{y:,} transactions"
                            "<extra></extra>"
                        ),
                    )
                )

                layout = plotly_layout(height=340)
                layout["title"]["text"] = (
                    "Transactions by hour of day"
                )
                layout["xaxis"]["title"] = "Hour"
                layout["yaxis"]["title"] = "Transactions"

                figure.update_layout(**layout)

                show_plotly(
                    figure,
                    "an_time_total",
                )

            with right:
                figure = go.Figure(
                    go.Bar(
                        x=hourly.index,
                        y=hourly["fraud_rate_pct"],
                        marker_color=p["danger"],
                        customdata=hourly["fraud"],
                        hovertemplate=(
                            "Hour %{x}: %{y:.3f}% "
                            "(%{customdata} frauds)"
                            "<extra></extra>"
                        ),
                    )
                )

                layout = plotly_layout(height=340)
                layout["title"]["text"] = (
                    "Fraud rate by hour of day"
                )
                layout["xaxis"]["title"] = "Hour"
                layout["yaxis"]["title"] = "Fraud Rate (%)"

                figure.update_layout(**layout)

                show_plotly(
                    figure,
                    "an_time_rate",
                )

            st.caption(
                "Hours with very few transactions can show "
                "a high fraud rate due to the small sample size."
            )

    # =============================================================
    # CORRELATION
    # =============================================================
    with tab_corr:
        corr = bundle["corr"]

        if corr is None or corr.empty:
            empty_state(
                "Correlation data unavailable",
                "No numeric correlation data is available.",
                "analytics",
            )
        else:
            numeric_corr = corr.copy()

            # Only show numeric columns that exist in the new dataset.
            if "IsFraud" in numeric_corr.columns:
                target_column = "IsFraud"
            else:
                target_column = numeric_corr.columns[-1]

            with_target = (
                numeric_corr[target_column]
                .drop(target_column, errors="ignore")
                .sort_values(
                    key=lambda values: values.abs(),
                    ascending=False,
                )
            )

            left, right = st.columns(
                [1, 1.15],
                gap="large",
            )

            with left:
                ordered = with_target.head(10).sort_values()

                figure = go.Figure(
                    go.Bar(
                        x=ordered.values,
                        y=ordered.index.astype(str),
                        orientation="h",
                        marker_color=[
                            p["danger"] if value > 0 else p["accent"]
                            for value in ordered.values
                        ],
                        hovertemplate=(
                            "%{y}: %{x:.3f}"
                            "<extra></extra>"
                        ),
                    )
                )

                layout = plotly_layout(height=440)
                layout["title"]["text"] = (
                    f"Numeric features by correlation with {target_column}"
                )

                figure.update_layout(**layout)

                show_plotly(
                    figure,
                    "an_corr_bar",
                )

            with right:
                names = [
                    target_column,
                    *list(with_target.head(10).index),
                ]

                names = list(
                    dict.fromkeys(
                        str(name)
                        for name in names
                        if name in numeric_corr.index
                    )
                )

                sub = numeric_corr.loc[
                    names,
                    names,
                ]

                figure = go.Figure(
                    go.Heatmap(
                        z=sub.values,
                        x=names,
                        y=names,
                        zmin=-1,
                        zmax=1,
                        colorscale="RdBu_r",
                        text=sub.round(2).values,
                        texttemplate="%{text}",
                        textfont={"size": 9},
                        hovertemplate=(
                            "%{y} vs %{x}: %{z:.3f}"
                            "<extra></extra>"
                        ),
                        colorbar=dict(
                            tickfont=dict(
                                color=p["muted"]
                            )
                        ),
                    )
                )

                layout = plotly_layout(height=440)
                layout["title"]["text"] = (
                    "Correlation heatmap"
                )
                layout["yaxis"]["autorange"] = "reversed"

                figure.update_layout(**layout)

                show_plotly(
                    figure,
                    "an_corr_heat",
                )

            st.caption(
                "Correlation analysis uses the numeric fields "
                "available in the new dataset. Categorical fields "
                "such as TransactionType and Location are analyzed "
                "separately."
            )