"""Tiny helper that reads user-facing strings from config.UI_TEXT.

The selected language is stored in ``st.session_state["lang"]`` (set by the
sidebar language selector). Missing keys fall back to English.
"""

from __future__ import annotations

from app.config import DEFAULT_LANGUAGE, UI_TEXT


def current_language() -> str:
    """Language code chosen in the sidebar (default: English)."""
    try:
        import streamlit as st

        lang = st.session_state.get("lang", DEFAULT_LANGUAGE)
    except Exception:  # no Streamlit session (e.g. plain unit tests)
        lang = DEFAULT_LANGUAGE
    return lang if lang in UI_TEXT else DEFAULT_LANGUAGE


def tr(key: str, lang: str | None = None, **values) -> str:
    """Return the text for `key`, formatted with `values`."""
    code = lang if lang in UI_TEXT else current_language()
    text = UI_TEXT[code].get(key)
    if text is None:
        text = UI_TEXT[DEFAULT_LANGUAGE].get(key, key)
    return text.format(**values) if values else text
