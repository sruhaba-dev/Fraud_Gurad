"""Light/Dark theme system.

The whole UI is driven by CSS variables. `inject_theme()` writes the variables
for the selected theme plus rules that restyle Streamlit's own widgets (sidebar,
inputs, buttons, tabs, expanders...) so the switch affects the entire app.
Plotly charts receive matching colours through `plotly_layout()`.
"""

from __future__ import annotations

import streamlit as st

PALETTES: dict[str, dict[str, str]] = {
    "light": {
        "bg": "#F3F5FA", "surface": "#FFFFFF", "surface2": "#F6F8FC", "border": "#E2E7F1",
        "text": "#0F172A", "muted": "#5B6478", "accent": "#4F46E5", "accent2": "#7C3AED",
        "accent_soft": "rgba(79,70,229,0.10)", "sidebar": "#FFFFFF", "input": "#FFFFFF",
        "ok": "#059669", "ok_soft": "rgba(5,150,105,0.12)",
        "warn": "#D97706", "warn_soft": "rgba(217,119,6,0.14)",
        "danger": "#DC2626", "danger_soft": "rgba(220,38,38,0.11)",
        "shadow": "0 1px 2px rgba(16,24,40,0.05), 0 10px 28px rgba(16,24,40,0.07)",
        "hero": "linear-gradient(135deg, #4F46E5 0%, #7C3AED 55%, #0EA5E9 120%)",
        "card": "#FFFFFF", "grad": "linear-gradient(135deg, #4F46E5 0%, #7C3AED 100%)",
        "grad_text": "linear-gradient(90deg, #4F46E5 0%, #7C3AED 100%)",
        "bg_glow": "radial-gradient(900px 420px at 92% -8%, rgba(99,102,241,0.13), transparent 60%)",
        "panel": "#FFFFFF", "panel_text": "#0F172A", "visual": "linear-gradient(150deg, #312E81 0%, #1E1B4B 60%, #0F172A 100%)",
        "glass": "rgba(255,255,255,0.16)", "glass_border": "rgba(255,255,255,0.28)",
    },
    "dark": {
        "bg": "#0A0F1F", "surface": "#121A30", "surface2": "#182240", "border": "#27335A",
        "text": "#E8ECF6", "muted": "#9AA6C3", "accent": "#8B97FF", "accent2": "#A78BFA",
        "accent_soft": "rgba(139,151,255,0.14)", "sidebar": "#0D1427", "input": "#0E1630",
        "ok": "#34D399", "ok_soft": "rgba(52,211,153,0.14)",
        "warn": "#FBBF24", "warn_soft": "rgba(251,191,36,0.15)",
        "danger": "#F87171", "danger_soft": "rgba(248,113,113,0.15)",
        "shadow": "0 1px 2px rgba(0,0,0,0.45), 0 12px 32px rgba(0,0,0,0.40)",
        "hero": "linear-gradient(160deg, #141D42 0%, #0C1230 55%, #0A0F1F 100%)",
        "card": "linear-gradient(160deg, #16203F 0%, #111830 100%)", "grad": "linear-gradient(135deg, #5B5BEF 0%, #7C4DEB 100%)",
        "grad_text": "linear-gradient(90deg, #8B97FF 0%, #B08CFF 100%)",
        "bg_glow": "radial-gradient(900px 480px at 92% -8%, rgba(99,102,241,0.24), transparent 60%)",
        "panel": "#0E1630", "panel_text": "#E8ECF6", "visual": "linear-gradient(150deg, #141D42 0%, #0C1230 60%, #080C1C 100%)",
        "glass": "rgba(139,151,255,0.10)", "glass_border": "rgba(139,151,255,0.28)",
    },
}


def current_theme() -> str:
    return st.session_state.get("theme", "light")


def palette() -> dict[str, str]:
    return PALETTES[current_theme()]


def toggle_theme() -> None:
    st.session_state["theme"] = "dark" if current_theme() == "light" else "light"


def plotly_layout(height: int = 340) -> dict:
    """Layout options that make Plotly charts follow the active theme."""
    p = palette()
    return dict(
        height=height,
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        font=dict(family="Inter, Segoe UI, system-ui, sans-serif", color=p["text"], size=12),
        margin=dict(l=10, r=10, t=40, b=10),
        legend=dict(font=dict(color=p["muted"]), bgcolor="rgba(0,0,0,0)"),
        xaxis=dict(automargin=True, gridcolor=p["border"], zerolinecolor=p["border"], linecolor=p["border"],
                   tickfont=dict(color=p["muted"]), title_font=dict(color=p["muted"])),
        yaxis=dict(automargin=True, gridcolor=p["border"], zerolinecolor=p["border"], linecolor=p["border"],
                   tickfont=dict(color=p["muted"]), title_font=dict(color=p["muted"])),
        hoverlabel=dict(bgcolor=p["surface"], font=dict(color=p["text"]),
                        bordercolor=p["border"]),
        title=dict(font=dict(size=15, color=p["text"]), x=0.0, xanchor="left"),
    )


def series_colors() -> list[str]:
    """Consistent categorical colours for model comparisons."""
    p = palette()
    return [p["accent"], "#0EA5E9", p["ok"], p["warn"], "#EC4899"]


def inject_theme() -> None:
    """Write the CSS for the active theme."""
    p = palette()
    variables = "\n".join(f"--{k.replace('_', '-')}: {v};" for k, v in p.items())
    css = f"""
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
:root {{ {variables} --radius: 16px; --radius-sm: 10px; color-scheme: {current_theme()}; }}
html {{ scroll-behavior: smooth; }}

/* ---------- base ---------- */
html, body, .stApp, [data-testid="stAppViewContainer"], [data-testid="stMain"] {{
  font-family: 'Inter', 'Segoe UI', system-ui, -apple-system, sans-serif !important;
}}
.stApp, [data-testid="stAppViewContainer"], [data-testid="stMain"] {{
  background: var(--bg-glow), var(--bg) !important; color: var(--text) !important;
}}
[data-testid="stMain"] {{ scroll-behavior: smooth; }}
[data-testid="stHeader"] {{ background: transparent !important; }}
[data-testid="stToolbar"], [data-testid="stDecoration"], #MainMenu, footer {{ display: none !important; visibility: hidden; }}
.block-container {{ padding-top: 1.6rem !important; padding-bottom: 3rem !important; max-width: 1280px; }}
[data-testid="stMarkdownContainer"], [data-testid="stMarkdownContainer"] p,
[data-testid="stMarkdownContainer"] li, [data-testid="stCaptionContainer"],
[data-testid="stWidgetLabel"] p, label, .stApp h1, .stApp h2, .stApp h3, .stApp h4 {{ color: var(--text) !important; }}
[data-testid="stCaptionContainer"], [data-testid="stWidgetLabel"] p {{ color: var(--muted) !important; }}
hr {{ border-color: var(--border) !important; }}

/* ---------- sidebar ---------- */
[data-testid="stSidebar"] {{ background: var(--sidebar) !important; border-right: 1px solid var(--border); }}
[data-testid="stSidebar"] [data-testid="stSidebarContent"] {{ padding-top: 0.5rem; }}
[data-testid="stSidebar"] .stButton button {{
  justify-content: flex-start; text-align: left; border: 0 !important; box-shadow: none !important;
  background: transparent !important; color: var(--muted) !important; border-radius: 12px !important;
  padding: 0.55rem 0.8rem; font-weight: 500; transition: background .15s, color .15s;
}}
[data-testid="stSidebar"] .stButton button > div, [data-testid="stSidebar"] .stButton button > div > span {{ justify-content: flex-start !important; width: 100%; }}
[data-testid="stSidebar"] .stButton button p {{ color: inherit !important; font-weight: 500; text-align: left; }}
[data-testid="stSidebar"] .stButton button:hover {{ background: var(--accent-soft) !important; color: var(--text) !important; }}
[data-testid="stSidebar"] .stButton button[kind="primary"],
[data-testid="stSidebar"] .stButton button[data-testid="stBaseButton-primary"] {{
  background: var(--grad) !important; color: #FFFFFF !important;
  box-shadow: 0 8px 20px rgba(79,70,229,0.32) !important;
}}
[data-testid="stSidebar"] .stButton button[kind="primary"] p,
[data-testid="stSidebar"] .stButton button[data-testid="stBaseButton-primary"] p {{ font-weight: 700; }}

/* ---------- buttons (main area) ---------- */
[data-testid="stMain"] .stButton button, [data-testid="stMain"] .stFormSubmitButton button,
[data-testid="stMain"] .stDownloadButton button {{
  border-radius: 12px !important; font-weight: 600; padding: 0.6rem 1.1rem;
  border: 1px solid var(--border) !important; background: var(--surface) !important;
  color: var(--text) !important; box-shadow: var(--shadow); transition: transform .12s, border-color .12s;
}}
[data-testid="stMain"] .stButton button p, [data-testid="stMain"] .stFormSubmitButton button p,
[data-testid="stMain"] .stDownloadButton button p {{ color: inherit !important; font-weight: 600; }}
[data-testid="stMain"] .stButton button:hover, [data-testid="stMain"] .stFormSubmitButton button:hover,
[data-testid="stMain"] .stDownloadButton button:hover {{ border-color: var(--accent) !important; transform: translateY(-1px); }}
[data-testid="stMain"] button[data-testid="stBaseButton-primary"], [data-testid="stMain"] button[data-testid="stBaseButton-primaryFormSubmit"],
[data-testid="stMain"] button[kind="primary"], [data-testid="stMain"] button[kind="primaryFormSubmit"] {{
  background: linear-gradient(135deg, #4F46E5 0%, #7C3AED 100%) !important;
  color: #FFFFFF !important; border: 0 !important; box-shadow: 0 8px 20px rgba(79,70,229,0.28);
}}
[data-testid="stMain"] button[data-testid="stBaseButton-primary"] p, [data-testid="stMain"] button[data-testid="stBaseButton-primaryFormSubmit"] p,
[data-testid="stMain"] button[kind="primary"] p, [data-testid="stMain"] button[kind="primaryFormSubmit"] p {{ color: #FFFFFF !important; }}

/* ---------- inputs ---------- */
[data-baseweb="input"], [data-baseweb="base-input"], [data-baseweb="textarea"],
[data-testid="stTextInputRootElement"], [data-testid="stNumberInputContainer"], [data-testid="stTextAreaRootElement"] {{
  background: var(--input) !important; border-color: var(--border) !important; border-radius: var(--radius-sm) !important;
}}
[data-baseweb="input"], [data-testid="stTextInputRootElement"], [data-testid="stNumberInputContainer"], [data-testid="stTextAreaRootElement"] {{ border: 1px solid var(--border) !important; }}
[data-baseweb="input"] [data-baseweb="base-input"], [data-testid="stTextInputRootElement"] [data-baseweb="base-input"],
[data-testid="stNumberInputContainer"] [data-baseweb="input"], [data-testid="stNumberInputContainer"] [data-baseweb="base-input"] {{ border: 0 !important; }}
[data-baseweb="input"]:focus-within, [data-testid="stTextInputRootElement"]:focus-within, [data-testid="stNumberInputContainer"]:focus-within {{
  border-color: var(--accent) !important; box-shadow: 0 0 0 3px var(--accent-soft) !important; }}
input, textarea {{ background: transparent !important; color: var(--text) !important; -webkit-text-fill-color: var(--text) !important; }}
input::placeholder {{ color: var(--muted) !important; -webkit-text-fill-color: var(--muted) !important; }}
[data-testid="stNumberInput"] button {{ background: var(--surface2) !important; color: var(--muted) !important; border-color: var(--border) !important; }}
[data-testid="stTextInput"] button svg {{ fill: var(--muted); }}
[data-testid="stSelectbox"] > div > div, [data-testid="stMultiSelect"] > div > div {{
  background: var(--input) !important; border: 1px solid var(--border) !important; border-radius: var(--radius-sm) !important; color: var(--text) !important; }}
[data-testid="stSelectbox"] > div > div:focus-within, [data-testid="stMultiSelect"] > div > div:focus-within {{ border-color: var(--accent) !important; box-shadow: 0 0 0 3px var(--accent-soft) !important; }}
[data-testid="stSelectbox"] input, [data-testid="stMultiSelect"] input {{ color: var(--text) !important; -webkit-text-fill-color: var(--text) !important; }}
[data-testid="stSelectbox"] > div > div svg, [data-testid="stMultiSelect"] > div > div svg {{ fill: var(--muted) !important; color: var(--muted) !important; }}
[data-testid="stSelectbox"] [data-baseweb="select"] > div {{ background: var(--input) !important; border: 1px solid var(--border) !important; border-radius: var(--radius-sm) !important; color: var(--text) !important; }}
[data-baseweb="select"] * {{ color: var(--text) !important; }}
[data-baseweb="select"] svg {{ fill: var(--muted) !important; }}
/* dropdown list (opens in a portal outside the app, so it is styled explicitly
   for BOTH themes: every layer is transparent and only the outer box is filled) */
[data-baseweb="popover"] *:not(svg):not(path),
[data-testid="stSelectboxVirtualDropdown"] *:not(svg):not(path),
ul[role="listbox"] *:not(svg):not(path), div[role="listbox"] *:not(svg):not(path) {{
  background-color: transparent !important; color: var(--text) !important;
  -webkit-text-fill-color: var(--text) !important; opacity: 1 !important;
}}
[data-baseweb="popover"], [data-baseweb="popover"] > div, [data-baseweb="menu"],
[data-testid="stSelectboxVirtualDropdown"], ul[role="listbox"], div[role="listbox"] {{
  background: var(--surface) !important; background-color: var(--surface) !important;
  color: var(--text) !important; border-radius: 12px !important;
}}
[data-baseweb="popover"] > div {{ border: 1px solid var(--border) !important; box-shadow: var(--shadow) !important; }}
[data-baseweb="popover"] li:hover, [data-baseweb="popover"] [role="option"]:hover,
[data-baseweb="popover"] [role="option"][aria-selected="true"],
[data-testid="stSelectboxVirtualDropdown"] [role="option"]:hover,
[data-testid="stSelectboxVirtualDropdown"] [role="option"][aria-selected="true"] {{
  background-color: var(--accent-soft) !important; }}
[data-testid="stTooltipContent"], [data-baseweb="tooltip"] > div {{ background: var(--surface2) !important; color: var(--text) !important; border: 1px solid var(--border); }}
[data-testid="stTooltipContent"] * {{ color: var(--text) !important; }}
[data-testid="stCheckbox"] span, [data-testid="stRadio"] label span, [data-testid="stToggle"] span {{ color: var(--text) !important; }}

[data-testid="stRadio"] [data-baseweb="radio"] > div:first-child {{ background: var(--input) !important; border: 2px solid var(--border) !important; }}
[data-testid="stRadio"] [data-baseweb="radio"] input:checked + div, [data-testid="stRadio"] [data-baseweb="radio"] [aria-checked="true"] > div:first-child {{ background: var(--accent) !important; border-color: var(--accent) !important; }}
[data-testid="stTabs"] {{ margin-top: 1rem; }}
/* ---------- tabs / expander / form ---------- */
[data-baseweb="tab-list"] {{ background: transparent !important; gap: 4px; border-bottom: 1px solid var(--border); }}
button[data-baseweb="tab"] {{ background: transparent !important; color: var(--muted) !important; font-weight: 600; }}
button[data-baseweb="tab"] p {{ color: inherit !important; }}
button[data-baseweb="tab"][aria-selected="true"], button[data-baseweb="tab"][aria-selected="true"] p, button[data-baseweb="tab"][aria-selected="true"] [data-testid="stMarkdownContainer"] p {{ color: var(--accent) !important; }}
[data-baseweb="tab-highlight"] {{ background-color: var(--accent) !important; }}
[data-baseweb="tab-border"] {{ background-color: var(--border) !important; }}
[data-testid="stExpander"] {{ background: var(--surface) !important; border: 1px solid var(--border) !important; border-radius: var(--radius) !important; box-shadow: var(--shadow); }}
[data-testid="stExpander"] details, [data-testid="stExpander"] summary {{ background: transparent !important; color: var(--text) !important; }}
[data-testid="stExpander"] summary p {{ color: var(--text) !important; font-weight: 600; }}
[data-testid="stExpander"] summary svg {{ color: var(--muted) !important; fill: var(--muted) !important; }}
[data-testid="stForm"] {{ background: var(--card) !important; border: 1px solid var(--border) !important; border-radius: var(--radius) !important; box-shadow: var(--shadow); padding: 1.1rem 1.2rem; }}
[data-testid="stAlert"] {{ background: var(--surface2) !important; color: var(--text) !important; border: 1px solid var(--border); border-radius: 12px; }}
[data-testid="stSpinner"], [data-testid="stSpinner"] * {{ color: var(--muted) !important; background: transparent !important; }}

/* ---------- components ---------- */
[data-testid="stMarkdownContainer"] :is(.fg-card, .fg-page-title, .fg-section, .fg-empty, .fg-hero, .fg-auth-title) :is(h1, h3, h4, p) {{ padding: 0 !important; }}
.fg-page-title p, .fg-section p, .fg-card p, .fg-empty p, .fg-hero p {{ margin-bottom: 0 !important; }}
.fg-card h4, .fg-empty h4 {{ margin-bottom: .35rem !important; }}
.fg-card {{ background: var(--card); border: 1px solid var(--border); border-radius: var(--radius); padding: 1.15rem 1.3rem; box-shadow: var(--shadow); }}
.fg-card h4 {{ margin: 0 0 .35rem 0; font-size: 1rem; font-weight: 700; color: var(--text) !important; }}
.fg-card p {{ margin: 0; color: var(--muted) !important; font-size: .92rem; line-height: 1.55; }}
.fg-page-title {{ display: flex; align-items: center; gap: .8rem; margin-bottom: .9rem; }}
.fg-page-title .fg-icon-bubble {{ width: 46px; height: 46px; border-radius: 14px; background: linear-gradient(135deg, var(--accent), var(--accent2)); color: #fff; display: flex; align-items: center; justify-content: center; box-shadow: 0 8px 18px rgba(79,70,229,.30); }}
.fg-page-title h1 {{ margin: 0; font-size: 1.75rem; font-weight: 800; letter-spacing: -0.02em; color: var(--text) !important; line-height: 1.15; }}
.fg-page-title p {{ margin: .2rem 0 0 0 !important; color: var(--muted) !important; font-size: .95rem; }}
.fg-section {{ margin: 1.3rem 0 .5rem 0; }}
.fg-section h3 {{ margin: 0; font-size: 1.12rem; font-weight: 700; color: var(--text) !important; letter-spacing: -0.01em; }}
.fg-section p {{ margin: .2rem 0 0 0 !important; color: var(--muted) !important; font-size: .9rem; }}

.fg-kpi-grid {{ display: grid; gap: 1rem; width: 100%; align-items: stretch; }}
.fg-kpi-grid.cols-1 {{ grid-template-columns: minmax(0, 1fr); }}
.fg-kpi-grid.cols-2 {{ grid-template-columns: repeat(2, minmax(0, 1fr)); }}
.fg-kpi-grid.cols-3 {{ grid-template-columns: repeat(3, minmax(0, 1fr)); }}
.fg-kpi-grid.cols-4 {{ grid-template-columns: repeat(4, minmax(0, 1fr)); }}
.fg-kpi {{ background: var(--card); border: 1px solid var(--border); border-radius: var(--radius); padding: 1.05rem 1.2rem; box-shadow: var(--shadow); display: flex; gap: .95rem; align-items: center; min-height: 112px; height: 100%; box-sizing: border-box; min-width: 0; }}
.fg-kpi > div:last-child {{ min-width: 0; flex: 1 1 auto; }}
.fg-kpi-icon {{ width: 44px; height: 44px; min-width: 44px; border-radius: 13px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }}
.fg-kpi-icon.accent {{ background: var(--accent-soft); color: var(--accent); }}
.fg-kpi-icon.ok {{ background: var(--ok-soft); color: var(--ok); }}
.fg-kpi-icon.warn {{ background: var(--warn-soft); color: var(--warn); }}
.fg-kpi-icon.danger {{ background: var(--danger-soft); color: var(--danger); }}
.fg-kpi-label {{ font-size: .82rem; font-weight: 500; white-space: normal; overflow-wrap: anywhere; color: var(--muted) !important; line-height: 1.3; }}
.fg-kpi-value {{ font-size: 1.65rem; font-weight: 800; letter-spacing: -0.02em; color: var(--text) !important; line-height: 1.2; overflow-wrap: anywhere; }}
.fg-kpi-sub {{ font-size: .78rem; color: var(--muted) !important; margin-top: 2px; line-height: 1.35; overflow-wrap: anywhere; }}

.fg-badge {{ display: inline-flex; align-items: center; gap: .3rem; padding: .18rem .65rem; border-radius: 999px; font-size: .74rem; font-weight: 700; letter-spacing: .03em; white-space: nowrap; }}
.fg-badge.ok {{ background: var(--ok-soft); color: var(--ok) !important; }}
.fg-badge.warn {{ background: var(--warn-soft); color: var(--warn) !important; }}
.fg-badge.danger {{ background: var(--danger-soft); color: var(--danger) !important; }}
.fg-badge.neutral {{ background: var(--accent-soft); color: var(--accent) !important; }}

.fg-table-wrap {{ background: var(--card); border: 1px solid var(--border); border-radius: var(--radius); box-shadow: var(--shadow); overflow-x: auto; }}
.fg-table {{ width: 100%; border-collapse: collapse; font-size: .9rem; }}
.fg-table th {{ text-align: left; padding: .75rem 1rem; font-size: .74rem; text-transform: uppercase; letter-spacing: .05em; color: var(--muted) !important; background: var(--surface2); border-bottom: 1px solid var(--border); white-space: nowrap; }}
.fg-table td {{ padding: .72rem 1rem; color: var(--text) !important; border-bottom: 1px solid var(--border); white-space: nowrap; }}
.fg-table tr:last-child td {{ border-bottom: 0; }}
.fg-table tr:hover td {{ background: var(--accent-soft); }}
.fg-table .num {{ text-align: right; font-variant-numeric: tabular-nums; }}
.fg-table th.num {{ text-align: right; }}
.fg-table tr.best td {{ background: var(--accent-soft); font-weight: 600; }}

.fg-empty {{ background: var(--surface); border: 1.5px dashed var(--border); border-radius: var(--radius); padding: 2.2rem 1.5rem; text-align: center; }}
.fg-empty .fg-empty-icon {{ width: 52px; height: 52px; margin: 0 auto .7rem auto; border-radius: 16px; background: var(--accent-soft); color: var(--accent); display: flex; align-items: center; justify-content: center; }}
.fg-empty h4 {{ margin: 0 0 .3rem 0; color: var(--text) !important; font-size: 1.02rem; }}
.fg-empty p {{ margin: 0; color: var(--muted) !important; font-size: .92rem; }}

.fg-notice {{ display: flex; gap: .7rem; align-items: flex-start; padding: .8rem 1rem; border-radius: 12px; font-size: .92rem; margin: .4rem 0; border: 1px solid transparent; }}
.fg-notice.ok {{ background: var(--ok-soft); color: var(--ok) !important; border-color: var(--ok-soft); }}
.fg-notice.warn {{ background: var(--warn-soft); color: var(--warn) !important; }}
.fg-notice.danger {{ background: var(--danger-soft); color: var(--danger) !important; }}
.fg-notice.info {{ background: var(--accent-soft); color: var(--accent) !important; }}
.fg-notice div {{ color: inherit !important; }}
.fg-notice ul {{ margin: .2rem 0 0 1rem; padding: 0; }}
.fg-notice li {{ color: inherit !important; }}

.fg-result {{ border-radius: 20px; padding: 1.5rem 1.6rem; border: 1px solid var(--border); box-shadow: var(--shadow); position: relative; overflow: hidden; background: var(--surface); }}
.fg-result::before {{ content: ""; position: absolute; left: 0; top: 0; bottom: 0; width: 6px; }}
.fg-result.ok::before {{ background: var(--ok); }} .fg-result.warn::before {{ background: var(--warn); }} .fg-result.danger::before {{ background: var(--danger); }}
.fg-result.ok {{ background: linear-gradient(135deg, var(--ok-soft), var(--surface) 65%); }}
.fg-result.warn {{ background: linear-gradient(135deg, var(--warn-soft), var(--surface) 65%); }}
.fg-result.danger {{ background: linear-gradient(135deg, var(--danger-soft), var(--surface) 65%); }}
.fg-result-head {{ display: flex; align-items: center; gap: .9rem; }}
.fg-result-icon {{ width: 54px; height: 54px; min-width: 54px; border-radius: 16px; display: flex; align-items: center; justify-content: center; color: #fff; }}
.fg-result.ok .fg-result-icon {{ background: var(--ok); }} .fg-result.warn .fg-result-icon {{ background: var(--warn); }} .fg-result.danger .fg-result-icon {{ background: var(--danger); }}
.fg-result-title {{ font-size: 1.22rem; font-weight: 800; letter-spacing: -0.01em; line-height: 1.25; }}
.fg-result.ok .fg-result-title {{ color: var(--ok) !important; }} .fg-result.warn .fg-result-title {{ color: var(--warn) !important; }} .fg-result.danger .fg-result-title {{ color: var(--danger) !important; }}
.fg-result-sub {{ color: var(--muted) !important; font-size: .88rem; margin-top: 2px; }}
.fg-result-grid {{ display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: .7rem; margin-top: 1.1rem; }}
.fg-result-grid .fg-stat:nth-child(3) {{ grid-column: span 2; }}
.fg-stat {{ background: var(--surface); border: 1px solid var(--border); border-radius: 14px; padding: .7rem .9rem; }}
.fg-stat .l {{ font-size: .7rem; text-transform: uppercase; letter-spacing: .05em; color: var(--muted) !important; font-weight: 600; }}
.fg-stat .v {{ font-size: 1.25rem; font-weight: 800; color: var(--text) !important; }}
.fg-explain {{ margin-top: 1rem; font-size: .9rem; line-height: 1.55; color: var(--muted) !important; }}
.fg-meta {{ display: flex; flex-wrap: wrap; gap: .5rem 1.4rem; margin-top: .9rem; font-size: .82rem; color: var(--muted) !important; }}
.fg-meta b {{ color: var(--text) !important; }}

.fg-brand {{ display: flex; align-items: center; gap: .7rem; padding: .6rem .4rem 1rem .4rem; }}
.fg-brand .logo {{ width: 40px; height: 40px; border-radius: 12px; background: linear-gradient(135deg, var(--accent), var(--accent2)); color: #fff; display: flex; align-items: center; justify-content: center; box-shadow: 0 6px 16px rgba(79,70,229,.32); }}
.fg-brand .name {{ font-weight: 800; font-size: 1.08rem; color: var(--text) !important; letter-spacing: -0.01em; }}
.fg-brand .tag {{ font-size: .72rem; color: var(--muted) !important; letter-spacing: 0; }}
.fg-user {{ display: flex; align-items: center; gap: .7rem; padding: .7rem .8rem; border: 1px solid var(--border); border-radius: 14px; background: var(--surface2); margin: .3rem 0 .6rem 0; }}
.fg-avatar {{ width: 36px; height: 36px; min-width: 36px; border-radius: 50%; background: linear-gradient(135deg, var(--accent), var(--accent2)); color: #fff; font-weight: 700; display: flex; align-items: center; justify-content: center; font-size: .85rem; }}
.fg-user .n {{ font-weight: 700; font-size: .88rem; color: var(--text) !important; line-height: 1.2; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 150px; }}
.fg-user .e {{ font-size: .72rem; color: var(--muted) !important; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 150px; }}
.fg-nav-label {{ font-size: .68rem; font-weight: 700; letter-spacing: .08em; text-transform: uppercase; color: var(--muted) !important; padding: .4rem .5rem .3rem .5rem; }}

.fg-hero {{ background: var(--hero); border-radius: 24px; padding: 2.4rem 2.2rem; color: #fff; min-height: 470px; position: relative; overflow: hidden; box-shadow: var(--shadow); }}
.fg-hero::after {{ content: ""; position: absolute; right: -80px; bottom: -80px; width: 280px; height: 280px; border-radius: 50%; background: rgba(255,255,255,.09); }}
[data-testid="stMarkdownContainer"] .fg-hero, [data-testid="stMarkdownContainer"] .fg-hero * {{ color: #fff !important; }}
.fg-hero .logo {{ width: 52px; height: 52px; border-radius: 16px; background: rgba(255,255,255,.18); display: flex; align-items: center; justify-content: center; margin-bottom: 1.3rem; }}
.fg-hero h1 {{ font-size: 2.2rem; font-weight: 800; line-height: 1.12; letter-spacing: -0.03em; margin: 0 0 .8rem 0; }}
.fg-hero p {{ font-size: 1rem; opacity: .92; line-height: 1.6; max-width: 34ch; margin: 0 0 1.6rem 0; }}
.fg-hero .feature {{ display: flex; align-items: center; gap: .65rem; margin: .55rem 0; font-size: .95rem; font-weight: 500; position: relative; z-index: 1; }}
.fg-hero .feature span.dot {{ width: 28px; height: 28px; border-radius: 9px; background: rgba(255,255,255,.18); display: flex; align-items: center; justify-content: center; }}
.fg-auth-title {{ font-size: 1.45rem; font-weight: 800; letter-spacing: -0.02em; margin: 0 0 .2rem 0; color: var(--text) !important; }}
.fg-auth-sub {{ color: var(--muted) !important; font-size: .92rem; margin-bottom: .6rem; }}

.fg-flow {{ display: flex; flex-wrap: wrap; align-items: stretch; gap: .6rem; }}
.fg-step {{ flex: 1 1 0; background: var(--card); border: 1px solid var(--border); border-radius: 16px; padding: .95rem .8rem; text-align: center; box-shadow: var(--shadow); min-width: 108px; }}
.fg-step .n {{ width: 30px; height: 30px; margin: 0 auto .5rem auto; border-radius: 10px; background: linear-gradient(135deg, var(--accent), var(--accent2)); color: #fff !important; font-weight: 700; display: flex; align-items: center; justify-content: center; font-size: .85rem; }}
.fg-step .t {{ font-weight: 700; font-size: .88rem; color: var(--text) !important; }}
.fg-step .d {{ font-size: .76rem; color: var(--muted) !important; margin-top: .25rem; line-height: 1.4; }}
.fg-arrow {{ align-self: center; color: var(--muted) !important; font-size: 1.1rem; margin: 0 -.15rem; }}
.fg-timeline {{ position: relative; margin-left: .6rem; padding-left: 1.6rem; border-left: 2px solid var(--border); }}
.fg-tl-item {{ position: relative; margin-bottom: 1rem; }}
.fg-tl-item::before {{ content: attr(data-n); position: absolute; left: -2.65rem; top: .1rem; width: 28px; height: 28px; border-radius: 50%; background: var(--accent); color: #fff; font-size: .78rem; font-weight: 700; display: flex; align-items: center; justify-content: center; box-shadow: 0 0 0 4px var(--bg); }}
.fg-chip {{ display: inline-block; padding: .3rem .8rem; margin: .2rem .25rem .2rem 0; border-radius: 999px; background: var(--accent-soft); color: var(--accent) !important; font-weight: 600; font-size: .82rem; }}
.fg-band {{ display: flex; height: 14px; border-radius: 999px; overflow: hidden; margin: .6rem 0 .3rem 0; }}
.fg-band div {{ height: 100%; }}
@media (max-width: 900px) {{ .fg-hero {{ min-height: auto; }} }}

/* =====================================================================
   FraudGuard UI  -  landing page, login screen, header chip, polish
   ===================================================================== */
.fg-logo {{ width: 40px; height: 40px; min-width: 40px; border-radius: 12px; background: var(--grad); color: #fff; display: flex; align-items: center; justify-content: center; box-shadow: 0 6px 18px rgba(79,70,229,.34); }}
.fg-wordmark {{ font-weight: 800; font-size: 1.4rem; letter-spacing: -0.02em; color: var(--text) !important; line-height: 1.05; }}
.fg-wordmark span {{ color: var(--accent) !important; }}
.fg-wordmark-sub {{ font-size: .72rem; color: var(--muted) !important; margin-top: 2px; }}
.fg-navbar-brand {{ display: flex; align-items: center; gap: .65rem; min-height: 44px; }}
.fg-nav-links {{ display: flex; align-items: center; justify-content: center; gap: 1.7rem; min-height: 44px; flex-wrap: wrap; }}
.fg-nav-links a {{ color: var(--muted) !important; text-decoration: none !important; font-weight: 500; font-size: .92rem; padding: .3rem 0; border-bottom: 2px solid transparent; transition: color .15s, border-color .15s; }}
.fg-nav-links a:hover {{ color: var(--text) !important; border-color: var(--accent); }}
.fg-nav-links a.on {{ color: var(--text) !important; border-color: var(--accent); }}
.fg-divider-line {{ height: 1px; background: var(--border); margin: .6rem 0 1.2rem 0; }}

/* landing hero */
.fg-l-pill {{ display: inline-block; padding: .3rem .85rem; border: 1px solid var(--border); border-radius: 999px; background: var(--accent-soft); color: var(--accent) !important; font-size: .7rem; font-weight: 700; letter-spacing: .07em; }}
.fg-l-h1 {{ font-size: 3.35rem; font-weight: 800; line-height: 1.05; letter-spacing: -0.035em; margin: 1.1rem 0 1.1rem 0; color: var(--text) !important; }}
.fg-l-h1 .g, .fg-l-title .g, .fg-auth-h .g {{ background: var(--grad-text); -webkit-background-clip: text; background-clip: text; -webkit-text-fill-color: transparent; color: transparent !important; }}
.fg-l-lead {{ font-size: 1.05rem; line-height: 1.65; color: var(--muted) !important; max-width: 46ch; margin: 0 0 1.5rem 0; }}
.fg-l-btn {{ display: inline-flex; align-items: center; justify-content: center; gap: .4rem; box-sizing: border-box; width: 100%; padding: .6rem 1.1rem; min-height: 2.75rem; border-radius: 12px; font-weight: 600; font-size: 1rem; text-decoration: none !important; color: var(--text) !important; border: 1px solid var(--border); background: var(--surface); box-shadow: var(--shadow); transition: transform .12s, border-color .12s; white-space: nowrap; }}
.fg-l-btn:hover {{ border-color: var(--accent); transform: translateY(-1px); }}
.fg-l-trust {{ display: flex; flex-wrap: wrap; gap: .5rem 1.4rem; margin-top: 1.4rem; }}
.fg-l-trust span {{ display: inline-flex; align-items: center; gap: .45rem; color: var(--muted) !important; font-size: .85rem; font-weight: 500; }}
.fg-l-trust .ck {{ width: 20px; height: 20px; border-radius: 50%; background: var(--accent-soft); color: var(--accent); display: inline-flex; align-items: center; justify-content: center; }}

.fg-l-visual {{ position: relative; border-radius: 26px; overflow: hidden; background: var(--visual); border: 1px solid var(--glass-border); box-shadow: var(--shadow); }}
.fg-l-visual svg.art {{ display: block; width: 100%; height: auto; }}
.fg-l-risk {{ position: absolute; top: 6%; right: 4%; width: 32%; min-width: 150px; padding: .8rem .95rem; border-radius: 14px; background: rgba(10,15,40,.72); border: 1px solid rgba(139,151,255,.35); backdrop-filter: blur(6px); color: #E8ECF6 !important; }}
.fg-l-risk .h {{ display: flex; justify-content: space-between; align-items: center; font-size: .8rem; font-weight: 700; color: #E8ECF6 !important; }}
.fg-l-risk .h em {{ font-style: normal; font-size: .6rem; font-weight: 700; letter-spacing: .06em; text-transform: uppercase; color: #A5B4FC !important; }}
.fg-l-risk .ring {{ position: relative; width: 84px; height: 84px; margin: .5rem auto .3rem auto; }}
.fg-l-risk .ring .v {{ position: absolute; inset: 0; display: flex; flex-direction: column; align-items: center; justify-content: center; font-weight: 800; font-size: 1.05rem; color: #FFFFFF !important; line-height: 1.1; }}
.fg-l-risk .ring .v small {{ font-size: .55rem; font-weight: 600; color: #67E8F9 !important; }}
.fg-l-risk .row {{ display: flex; justify-content: space-between; align-items: center; font-size: .72rem; color: #C7D2FE !important; margin-top: .25rem; }}
.fg-l-risk .row b {{ color: #FFFFFF !important; }}
.fg-l-risk .row i {{ display: inline-block; width: 8px; height: 8px; border-radius: 50%; margin-right: .4rem; }}

.fg-l-title {{ display: flex; align-items: center; justify-content: center; gap: 1.1rem; font-size: 1.7rem; font-weight: 800; letter-spacing: -0.02em; color: var(--text) !important; margin: 2.6rem 0 1.4rem 0; }}
.fg-l-title::before, .fg-l-title::after {{ content: ""; height: 1px; width: 70px; background: linear-gradient(90deg, transparent, var(--accent)); }}
.fg-l-title::after {{ background: linear-gradient(270deg, transparent, var(--accent)); }}
.fg-l-grid {{ display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 1rem; }}
.fg-l-feat {{ background: var(--card); border: 1px solid var(--border); border-radius: var(--radius); padding: 1.25rem 1.2rem; box-shadow: var(--shadow); transition: transform .15s, border-color .15s; }}
.fg-l-feat:hover {{ transform: translateY(-3px); border-color: var(--accent); }}
.fg-l-feat .ic {{ width: 46px; height: 46px; border-radius: 50%; background: var(--accent-soft); color: var(--accent); display: flex; align-items: center; justify-content: center; margin-bottom: .9rem; }}
.fg-l-feat .t {{ font-weight: 700; font-size: 1.02rem; color: var(--text) !important; margin-bottom: .35rem; }}
.fg-l-feat .d {{ font-size: .88rem; line-height: 1.55; color: var(--muted) !important; }}
.fg-l-steps {{ display: flex; align-items: stretch; gap: .5rem; }}
.fg-l-step {{ flex: 1 1 0; position: relative; background: var(--card); border: 1px solid var(--border); border-radius: 16px; padding: 1.5rem .8rem 1rem .8rem; text-align: center; box-shadow: var(--shadow); min-width: 0; }}
.fg-l-step .n {{ position: absolute; top: -13px; left: 50%; transform: translateX(-50%); width: 26px; height: 26px; border-radius: 50%; background: var(--grad); color: #fff !important; font-size: .78rem; font-weight: 700; display: flex; align-items: center; justify-content: center; box-shadow: 0 0 0 4px var(--bg); }}
.fg-l-step.risk .n {{ background: linear-gradient(135deg, #EF4444, #F97316); }}
.fg-l-step .ic {{ width: 40px; height: 40px; margin: 0 auto .5rem auto; border-radius: 12px; background: var(--accent-soft); color: var(--accent); display: flex; align-items: center; justify-content: center; }}
.fg-l-step.risk .ic {{ background: var(--danger-soft); color: var(--danger); }}
.fg-l-step .t {{ font-weight: 700; font-size: .92rem; color: var(--text) !important; }}
.fg-l-step .d {{ font-size: .78rem; line-height: 1.45; color: var(--muted) !important; margin-top: .25rem; }}
.fg-l-arrow {{ align-self: center; color: var(--accent) !important; flex: 0 0 auto; display: flex; }}
.fg-l-about h3 {{ font-size: 1.5rem; font-weight: 800; letter-spacing: -0.02em; margin: 0 0 .6rem 0 !important; color: var(--text) !important; padding: 0 !important; }}
.fg-l-about h3 span {{ color: var(--accent) !important; }}
.fg-l-about p {{ color: var(--muted) !important; line-height: 1.65; max-width: 60ch; margin: 0 0 1rem 0; }}
.fg-l-visual.small {{ max-width: 460px; margin-left: auto; }}
.st-key-cta_banner {{ background: var(--grad); border-radius: 18px; padding: 1.3rem 1.6rem; box-shadow: 0 14px 34px rgba(79,70,229,.30); margin-top: 2rem; }}
.st-key-cta_banner .cta-t {{ font-size: 1.25rem; font-weight: 800; color: #fff !important; }}
.st-key-cta_banner .cta-s {{ font-size: .92rem; color: rgba(255,255,255,.86) !important; margin-top: 2px; }}
[data-testid="stMain"] .st-key-cta_banner .stButton button {{ background: #FFFFFF !important; color: #4338CA !important; border: 0 !important; box-shadow: 0 6px 16px rgba(0,0,0,.18) !important; }}
[data-testid="stMain"] .st-key-cta_banner .stButton button p, [data-testid="stMain"] .st-key-cta_banner .stButton button span {{ color: #4338CA !important; }}
.fg-l-footer {{ display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 1rem 2rem; margin-top: 2.2rem; padding-top: 1.3rem; border-top: 1px solid var(--border); }}
.fg-l-footer .copy {{ color: var(--muted) !important; font-size: .82rem; }}

/* compact nav buttons on the landing page */
[data-testid="stMain"] .st-key-landing_login button, [data-testid="stMain"] .st-key-landing_signup button {{ padding: .5rem 1rem !important; }}
[data-testid="stMain"] .st-key-landing_login button {{ box-shadow: none !important; background: transparent !important; }}
.st-key-landing_start button, .st-key-cta_start button, .st-key-login_form button[kind="primaryFormSubmit"],
.st-key-signup_form button[kind="primaryFormSubmit"] {{ flex-direction: row-reverse; gap: .5rem; }}

/* login screen */
.fg-auth-hero {{ min-height: 640px; padding: 1.8rem 1.8rem 1.6rem 1.8rem; border: 1px solid var(--glass-border); display: flex; flex-direction: column; }}
.fg-auth-hero::before {{ content: ""; position: absolute; inset: 0; background: radial-gradient(420px 320px at 60% 45%, rgba(99,102,241,.35), transparent 70%); pointer-events: none; }}
.fg-auth-hero > * {{ position: relative; z-index: 1; }}
.fg-auth-hero .brand {{ display: flex; align-items: center; gap: .7rem; }}
.fg-auth-hero .brand .logo {{ width: 42px; height: 42px; margin: 0; border-radius: 13px; background: rgba(255,255,255,.16); }}
.fg-auth-hero .wm {{ font-size: 1.45rem; font-weight: 800; letter-spacing: -0.02em; line-height: 1.05; }}
.fg-auth-hero .wm-s {{ font-size: .78rem; opacity: .8; }}
.fg-auth-h {{ font-size: 2.35rem; font-weight: 800; line-height: 1.1; letter-spacing: -0.03em; margin: 1.6rem 0 .7rem 0; max-width: 11ch; color: #fff !important; }}
.fg-auth-hero .fg-auth-h .g {{ background: linear-gradient(90deg, #F5D0FE, #A5F3FC); -webkit-background-clip: text; background-clip: text; -webkit-text-fill-color: transparent; color: transparent !important; }}
.fg-auth-hero p {{ max-width: 40ch; margin-bottom: 0 !important; font-size: .95rem; }}
.fg-auth-art {{ position: relative; margin: .4rem 0 .6rem 0; }}
.fg-auth-art > svg {{ display: block; width: 100%; max-width: 340px; height: auto; margin: 0 auto; }}
.fg-chip-float {{ position: absolute; display: flex; align-items: center; gap: .5rem; padding: .4rem .65rem; border-radius: 12px; background: rgba(10,15,40,.55); border: 1px solid rgba(255,255,255,.22); backdrop-filter: blur(6px); font-size: .72rem; line-height: 1.25; }}
.fg-chip-float b {{ display: block; font-weight: 600; font-size: .74rem; }}
.fg-chip-float small {{ opacity: .78; font-size: .66rem; }}
.fg-chip-float.a {{ top: 4%; left: 0; }} .fg-chip-float.b {{ top: 0; right: 0; }}
.fg-chip-float.c {{ bottom: 6%; left: 2%; }} .fg-chip-float.d {{ bottom: 2%; right: 0; }}
.fg-auth-hero .features {{ display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: .7rem; margin-top: auto; }}
.fg-auth-hero .feature {{ align-items: flex-start !important; margin: 0 !important; padding: .75rem .8rem; border-radius: 14px; background: rgba(255,255,255,.09); border: 1px solid rgba(255,255,255,.18); font-size: .8rem !important; line-height: 1.4; }}
.fg-auth-hero .feature span.dot {{ min-width: 28px; }}
.fg-auth-back-row {{ margin-bottom: .4rem; }}
[data-testid="stMain"] .st-key-auth_back button, [data-testid="stMain"] .st-key-auth_switch button {{ box-shadow: none !important; background: transparent !important; border: 0 !important; color: var(--accent) !important; padding: .3rem 0 !important; justify-content: center; }}
[data-testid="stMain"] .st-key-auth_back button {{ justify-content: flex-start; color: var(--muted) !important; }}
[data-testid="stMain"] .st-key-auth_back button:hover, [data-testid="stMain"] .st-key-auth_switch button:hover {{ transform: none !important; text-decoration: underline; }}
.fg-or {{ display: flex; align-items: center; gap: 1rem; color: var(--muted) !important; font-size: .82rem; margin: 1rem 0 .3rem 0; }}
.fg-or::before, .fg-or::after {{ content: ""; flex: 1; height: 1px; background: var(--border); }}
.fg-auth-title {{ font-size: 1.9rem !important; }}

/* header user chip */
.fg-userchip {{ display: flex; align-items: center; justify-content: flex-end; gap: .55rem; }}
.fg-userchip .fg-avatar {{ width: 34px; height: 34px; min-width: 34px; font-size: .8rem; }}
.fg-userchip .n {{ font-weight: 700; font-size: .82rem; color: var(--text) !important; line-height: 1.15; max-width: 130px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }}
.fg-userchip .r {{ font-size: .68rem; color: var(--muted) !important; }}



/* labels inside buttons / tabs must take the button's colour, not the generic markdown colour */
button [data-testid="stMarkdownContainer"], button [data-testid="stMarkdownContainer"] p,
[data-testid="stTab"] [data-testid="stMarkdownContainer"], [data-testid="stTab"] [data-testid="stMarkdownContainer"] p {{ color: inherit !important; }}
[data-testid="stMain"] .st-key-auth_switch button p {{ color: var(--accent) !important; }}
/* tabs (newer Streamlit uses react-aria markup) */
[role="tablist"] {{ background: transparent !important; gap: 4px; border-bottom: 1px solid var(--border) !important; }}
[data-testid="stTab"] {{ background: transparent !important; color: var(--muted) !important; font-weight: 600; padding: .55rem 1rem !important; }}
[data-testid="stTab"] p {{ color: inherit !important; }}
[data-testid="stTab"]:hover {{ color: var(--text) !important; }}
[data-testid="stTab"][aria-selected="true"], [data-testid="stTab"][aria-selected="true"] p {{ color: var(--accent) !important; }}
.react-aria-SelectionIndicator {{ background-color: var(--accent) !important; background: var(--accent) !important; }}
/* polish for Streamlit's own widgets in both modes */
[data-baseweb="tag"], [data-tag] {{ background: var(--accent-soft) !important; border: 1px solid var(--border) !important; border-radius: 8px !important; }}
[data-baseweb="tag"], [data-baseweb="tag"] *, [data-tag], [data-tag] * {{ color: var(--accent) !important; }}
[data-baseweb="tag"] svg, [data-tag] svg {{ fill: var(--accent) !important; }}

/* ---------- equal-height rows ---------- */
[data-testid="stHorizontalBlock"] {{ align-items: stretch !important; }}
[data-testid="stHorizontalBlock"] > [data-testid="column"] {{ min-width: 0; }}
[data-testid="stHorizontalBlock"] > [data-testid="column"] .fg-kpi {{ min-height: 112px; }}
[data-testid="stHorizontalBlock"] > [data-testid="column"] .fg-kpi > div:last-child {{ min-width: 0; }}

[data-testid="stDataFrame"], [data-testid="stTable"] {{ border: 1px solid var(--border); border-radius: var(--radius-sm); overflow: hidden; }}
[data-testid="stCheckbox"] [data-baseweb="checkbox"] > span:first-child {{ border-color: var(--border) !important; background: var(--input) !important; }}
[data-testid="stCheckbox"] [data-baseweb="checkbox"] input:checked + span, [data-testid="stCheckbox"] [aria-checked="true"] > span:first-child {{ background: var(--accent) !important; border-color: var(--accent) !important; }}
[data-testid="stSlider"] [role="slider"] {{ background: var(--accent) !important; }}
[data-testid="stSlider"] [data-testid="stTickBar"] * , [data-testid="stSliderThumbValue"] {{ color: var(--muted) !important; }}
[data-testid="stAlert"] p, [data-testid="stAlert"] li {{ color: var(--text) !important; }}
::-webkit-scrollbar {{ width: 10px; height: 10px; }}
::-webkit-scrollbar-thumb {{ background: var(--border); border-radius: 999px; }}
::-webkit-scrollbar-track {{ background: transparent; }}

/* =====================================================================
   Fraud verdicts, action line, reasons, review workflow (new)
   ===================================================================== */
.fg-verdict-banner {{ display: flex; align-items: center; gap: 1rem; padding: 1.15rem 1.3rem; border-radius: 16px; color: #fff !important; box-shadow: var(--shadow); }}
.fg-verdict-banner.ok {{ background: #047857; }} .fg-verdict-banner.warn {{ background: #B45309; }} .fg-verdict-banner.danger {{ background: #DC2626; }}
.fg-verdict-banner .vb-icon {{ width: 56px; height: 56px; min-width: 56px; border-radius: 16px; background: rgba(255,255,255,.20); display: flex; align-items: center; justify-content: center; color: #fff !important; }}
.fg-verdict-banner .vb-text {{ font-size: 1.55rem; font-weight: 800; line-height: 1.2; letter-spacing: -0.01em; color: #fff !important; }}
.fg-action-line {{ margin-top: .7rem; padding: .8rem 1.1rem; border-radius: 14px; border: 1px solid var(--border); border-left-width: 6px; background: var(--surface); }}
.fg-action-line.ok {{ border-left-color: var(--ok); }} .fg-action-line.warn {{ border-left-color: var(--warn); }} .fg-action-line.danger {{ border-left-color: var(--danger); }}
.fg-action-line .t {{ font-size: .72rem; text-transform: uppercase; letter-spacing: .06em; font-weight: 700; color: var(--muted) !important; }}
.fg-action-line .d {{ font-size: 1.08rem; font-weight: 700; color: var(--text) !important; margin-top: .15rem; line-height: 1.4; }}
.fg-reasons {{ margin-top: .7rem; padding: .85rem 1.1rem; border-radius: 14px; border: 1px solid var(--border); background: var(--surface); }}
.fg-reasons .t {{ font-weight: 700; font-size: .95rem; color: var(--text) !important; margin-bottom: .3rem; }}
.fg-reasons ul {{ margin: 0 0 0 1.1rem; padding: 0; }}
.fg-reasons li {{ color: var(--text) !important; font-size: .92rem; line-height: 1.5; margin: .2rem 0; }}
.fg-reasons .note {{ margin-top: .45rem; font-size: .78rem; color: var(--muted) !important; }}
.fg-prob {{ display: flex; align-items: center; gap: 1rem; margin-top: .7rem; padding: .8rem 1.1rem; border-radius: 14px; border: 1px solid var(--border); background: var(--surface); }}
.fg-prob .v {{ font-size: 2rem; font-weight: 800; letter-spacing: -0.02em; color: var(--text) !important; line-height: 1.1; }}
.fg-prob .l {{ font-size: .72rem; text-transform: uppercase; letter-spacing: .05em; font-weight: 600; color: var(--muted) !important; }}
.fg-prob .c {{ font-size: .9rem; color: var(--text) !important; margin-top: .2rem; line-height: 1.4; }}
.st-key-fg_result_ok, .st-key-fg_result_warn, .st-key-fg_result_danger {{ border: 2px solid var(--border); border-radius: 20px; padding: 1rem 1.1rem; }}
.st-key-fg_result_ok {{ border-color: var(--ok); background: var(--ok-soft); }}
.st-key-fg_result_warn {{ border-color: var(--warn); background: var(--warn-soft); }}
.st-key-fg_result_danger {{ border-color: var(--danger); background: var(--danger-soft); }}

.fg-verdict {{ display: inline-flex; align-items: center; gap: .35rem; font-weight: 700; }}
.fg-verdict.ok, .fg-action-word.ok {{ color: var(--ok) !important; }}
.fg-verdict.warn, .fg-action-word.warn {{ color: var(--warn) !important; }}
.fg-verdict.danger, .fg-action-word.danger {{ color: var(--danger) !important; }}
.fg-action-word {{ font-weight: 700; }}
.fg-probcell {{ display: flex; align-items: center; justify-content: flex-end; gap: .6rem; }}
.fg-probbar {{ width: 70px; height: 8px; border-radius: 999px; background: var(--border); overflow: hidden; flex-shrink: 0; }}
.fg-probbar div {{ height: 100%; border-radius: 999px; }}
.fg-probbar .ok {{ background: var(--ok); }} .fg-probbar .warn {{ background: var(--warn); }} .fg-probbar .danger {{ background: var(--danger); }}
.fg-badge.grey {{ background: var(--surface2); color: var(--muted) !important; border: 1px solid var(--border); }}
.fg-badge.blue {{ background: rgba(59,130,246,0.15); color: #3B82F6 !important; }}
.fg-table tr.tone-danger td {{ background: var(--danger-soft); }}
.fg-table tr.tone-warn td {{ background: var(--warn-soft); }}
.fg-table tr.tone-danger:hover td, .fg-table tr.tone-warn:hover td {{ filter: brightness(0.97); }}

@media (max-width: 1000px) {{
  .fg-kpi-grid.cols-4, .fg-kpi-grid.cols-3 {{ grid-template-columns: repeat(2, minmax(0, 1fr)); }}
  .fg-l-grid {{ grid-template-columns: repeat(2, minmax(0, 1fr)); }}
  .fg-l-steps {{ flex-wrap: wrap; }} .fg-l-step {{ flex: 1 1 40%; }} .fg-l-arrow {{ display: none; }}
  .fg-l-h1 {{ font-size: 2.6rem; }} .fg-l-title::before, .fg-l-title::after {{ width: 28px; }}
}}
@media (max-width: 600px) {{
  .fg-kpi-grid.cols-4, .fg-kpi-grid.cols-3, .fg-kpi-grid.cols-2 {{ grid-template-columns: 1fr; }}
  .fg-l-grid {{ grid-template-columns: 1fr; }} .fg-l-step {{ flex: 1 1 100%; }}
  .fg-auth-hero .features {{ grid-template-columns: 1fr; }} .fg-l-h1 {{ font-size: 2.2rem; }}
}}
</style>
"""
    st.markdown(css, unsafe_allow_html=True)
