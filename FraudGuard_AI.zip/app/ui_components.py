"""Reusable UI building blocks (cards, badges, tables, gauge, page header).

Every user-controlled string that is placed into HTML goes through `esc()`.
"""

from __future__ import annotations

from html import escape as esc
from typing import Sequence

import plotly.graph_objects as go
import streamlit as st

from app.config import SUSPICIOUS_FRACTION
from app.i18n import tr
from app.model_service import PredictionResult
from app.theme import palette, plotly_layout, toggle_theme, current_theme

# Lucide-style stroke icons (24x24, currentColor)
_ICONS = {
    "shield": '<path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/>',
    "check": '<path d="M20 6 9 17l-5-5"/>',
    "alert": '<path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3"/><path d="M12 9v4"/><path d="M12 17h.01"/>',
    "x-circle": '<circle cx="12" cy="12" r="10"/><path d="m15 9-6 6"/><path d="m9 9 6 6"/>',
    "database": '<ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M3 5V19A9 3 0 0 0 21 19V5"/><path d="M3 12A9 3 0 0 0 21 12"/>',
    "clock": '<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>',
    "target": '<circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/>',
    "lock": '<rect width="18" height="11" x="3" y="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
    "zap": '<polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>',
    "trending": '<polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/>',
    "search": '<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>',
    "dollar": '<line x1="12" x2="12" y1="2" y2="22"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>',
    "bar": '<line x1="12" x2="12" y1="20" y2="10"/><line x1="18" x2="18" y1="20" y2="4"/><line x1="6" x2="6" y1="20" y2="16"/>',
    "list": '<line x1="8" x2="21" y1="6" y2="6"/><line x1="8" x2="21" y1="12" y2="12"/><line x1="8" x2="21" y1="18" y2="18"/><line x1="3" x2="3.01" y1="6" y2="6"/><line x1="3" x2="3.01" y1="12" y2="12"/><line x1="3" x2="3.01" y1="18" y2="18"/>',
    "cpu": '<rect width="16" height="16" x="4" y="4" rx="2"/><rect width="6" height="6" x="9" y="9" rx="1"/><path d="M15 2v2M15 20v2M2 15h2M2 9h2M20 15h2M20 9h2M9 2v2M9 20v2"/>',
    "activity": '<path d="M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2"/>',
    "info": '<circle cx="12" cy="12" r="10"/><path d="M12 16v-4"/><path d="M12 8h.01"/>',
    "card": '<rect width="20" height="14" x="2" y="5" rx="2"/><line x1="2" x2="22" y1="10" y2="10"/>',
    "sliders": '<line x1="4" x2="4" y1="21" y2="14"/><line x1="4" x2="4" y1="10" y2="3"/><line x1="12" x2="12" y1="21" y2="12"/><line x1="12" x2="12" y1="8" y2="3"/><line x1="20" x2="20" y1="21" y2="16"/><line x1="20" x2="20" y1="12" y2="3"/><line x1="2" x2="6" y1="14" y2="14"/><line x1="10" x2="14" y1="8" y2="8"/><line x1="18" x2="22" y1="16" y2="16"/>',
    "shield-check": '<path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/><path d="m9 12 2 2 4-4"/>',
    "arrow-right": '<path d="M5 12h14"/><path d="m12 5 7 7-7 7"/>',
    "chart": '<path d="M3 3v18h18"/><path d="M18 17V9"/><path d="M13 17V5"/><path d="M8 17v-3"/>',
    "brain": '<path d="M12 5a3 3 0 1 0-5.997.125 4 4 0 0 0-2.526 5.77 4 4 0 0 0 .556 6.588A4 4 0 1 0 12 18Z"/><path d="M12 5a3 3 0 1 1 5.997.125 4 4 0 0 1 2.526 5.77 4 4 0 0 1-.556 6.588A4 4 0 1 1 12 18Z"/><path d="M15 13a4.5 4.5 0 0 1-3-4 4.5 4.5 0 0 1-3 4"/><path d="M12 18V5"/>',
    "layers": '<path d="m12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83Z"/><path d="m22 17.65-9.17 4.16a2 2 0 0 1-1.66 0L2 17.65"/><path d="m22 12.65-9.17 4.16a2 2 0 0 1-1.66 0L2 12.65"/>',
}


def icon(name: str, size: int = 22) -> str:
    return (f'<svg xmlns="http://www.w3.org/2000/svg" width="{size}" height="{size}" viewBox="0 0 24 24" '
            f'fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" '
            f'stroke-linejoin="round">{_ICONS.get(name, _ICONS["info"])}</svg>')


def brand_html(subtitle: str = "") -> str:
    """Logo + FraudGuard wordmark used on the landing, login and sidebar."""
    sub = f'<div class="fg-wordmark-sub">{esc(subtitle)}</div>' if subtitle else ""
    return (f'<div class="fg-navbar-brand"><div class="fg-logo">{icon("shield", 22)}</div>'
            f'<div><div class="fg-wordmark">Fraud<span>Guard</span></div>{sub}</div></div>')


def render(html: str) -> None:
    """Render an HTML snippet (whitespace-collapsed so Markdown never treats it as code)."""
    st.markdown(" ".join(line.strip() for line in html.splitlines() if line.strip()),
                unsafe_allow_html=True)


# ------------------------------------------------------------------ header
def page_header(title: str, subtitle: str, icon_name: str = "shield") -> None:
    """Page title + subtitle on the left, theme switch on the right."""
    left, chip, right = st.columns([4.2, 1.55, 1.25], vertical_alignment="center")
    with left:
        render(f'<div class="fg-page-title"><div class="fg-icon-bubble">{icon(icon_name, 24)}</div>'
               f'<div><h1>{esc(title)}</h1><p>{esc(subtitle)}</p></div></div>')
    with chip:
        user = st.session_state.get("user")
        if user:
            initials = "".join(part[0] for part in user["full_name"].split()[:2]).upper()
            render(f'<div class="fg-userchip"><div class="fg-avatar">{esc(initials)}</div>'
                   f'<div><div class="n">{esc(user["full_name"])}</div><div class="r">Signed in</div></div></div>')
    with right:
        theme_button("theme_button_header")


def theme_button(key: str) -> None:
    """Button that switches between Light and Dark mode."""
    is_light = current_theme() == "light"
    st.button("Dark mode" if is_light else "Light mode",
              icon=":material/dark_mode:" if is_light else ":material/light_mode:",
              key=key, on_click=toggle_theme, width="stretch")


def go_to(page: str) -> None:
    """Navigate to a page (used as a button callback)."""
    st.session_state["page"] = page


def section(title: str, subtitle: str = "") -> None:
    sub = f"<p>{esc(subtitle)}</p>" if subtitle else ""
    render(f'<div class="fg-section"><h3>{esc(title)}</h3>{sub}</div>')


# -------------------------------------------------------------------- cards
def kpi_card(label: str, value: str, sub: str = "", icon_name: str = "activity", tone: str = "accent") -> str:
    sub_html = f'<div class="fg-kpi-sub">{esc(sub)}</div>' if sub else ""
    return (f'<div class="fg-kpi"><div class="fg-kpi-icon {tone}">{icon(icon_name)}</div>'
            f'<div><div class="fg-kpi-label">{esc(label)}</div>'
            f'<div class="fg-kpi-value">{esc(value)}</div>{sub_html}</div></div>')


def kpi_row(cards: Sequence[str]) -> None:
    """Render KPI cards in a true equal-height responsive grid."""
    if not cards:
        return
    render(
        f'<div class="fg-kpi-grid cols-{min(len(cards), 4)}">'
        + "".join(cards)
        + "</div>"
    )


def card(title: str, body: str) -> None:
    render(f'<div class="fg-card"><h4>{esc(title)}</h4><p>{esc(body)}</p></div>')


def empty_state(title: str, text: str, icon_name: str = "database") -> None:
    render(f'<div class="fg-empty"><div class="fg-empty-icon">{icon(icon_name, 26)}</div>'
           f'<h4>{esc(title)}</h4><p>{esc(text)}</p></div>')


def notice(kind: str, message: str | Sequence[str]) -> None:
    """Theme-aware alert. kind: ok | warn | danger | info."""
    icons = {"ok": "check", "warn": "alert", "danger": "x-circle", "info": "info"}
    if isinstance(message, str):
        body = f"<div>{esc(message)}</div>"
    else:
        body = "<ul>" + "".join(f"<li>{esc(m)}</li>" for m in message) + "</ul>"
    render(f'<div class="fg-notice {kind}">{icon(icons[kind], 18)}{body}</div>')


# ------------------------------------------------------------------- badges
_TONE = {"NORMAL": "ok", "SUSPICIOUS": "warn", "FRAUD": "danger",
         "LOW": "ok", "MEDIUM": "warn", "HIGH": "danger"}


def badge(label: str, tone: str = "neutral") -> str:
    return f'<span class="fg-badge {tone}">{esc(label)}</span>'


def status_badge(value: str) -> str:
    return badge(value, _TONE.get(value, "neutral"))


def html_table(headers: Sequence[str], rows: Sequence[Sequence[str]],
               numeric: Sequence[int] = (), highlight_row: int | None = None,
               row_tones: Sequence[str | None] | None = None) -> None:
    """Theme-aware table. Cell values must already be HTML-safe.

    `row_tones` is optional: one tone ("danger", "warn", "ok" or None) per row,
    used to tint the whole row (works in light and dark mode).
    """
    head = "".join(f'<th class="{"num" if i in numeric else ""}">{esc(h)}</th>'
                   for i, h in enumerate(headers))
    body = ""
    for r, row in enumerate(rows):
        cells = "".join(f'<td class="{"num" if i in numeric else ""}">{cell}</td>'
                        for i, cell in enumerate(row))
        classes = []
        if r == highlight_row:
            classes.append("best")
        tone = row_tones[r] if row_tones is not None and r < len(row_tones) else None
        if tone in ("danger", "warn", "ok"):
            classes.append(f"tone-{tone}")
        body += f'<tr class="{" ".join(classes)}">{cells}</tr>'
    render(f'<div class="fg-table-wrap"><table class="fg-table"><thead><tr>{head}</tr></thead>'
           f'<tbody>{body}</tbody></table></div>')


# ----------------------------------------------------------------- results
_RESULT = {
    "NORMAL": ("ok", "check", "Transaction appears normal",
               "Based on the learned transaction patterns, this transaction looks consistent "
               "with normal activity. A low score is not a guarantee - the model can be wrong."),
    "SUSPICIOUS": ("warn", "alert", "Suspicious transaction - review recommended",
                   "The fraud probability is elevated but below the decision threshold. "
                   "Treat this as a case for manual review rather than a confirmed fraud."),
    "FRAUD": ("danger", "x-circle", "Potential fraud detected",
              "The model classified this transaction as potentially fraudulent based on the "
              "learned transaction patterns. This is a statistical prediction, not proof of "
              "fraud, and should be reviewed."),
}


def result_card(result: PredictionResult, dataset_label: str | None = None) -> None:
    tone, icon_name, title, explanation = _RESULT[result.label]
    truth = f'<span>Dataset label of this sample: <b>{esc(dataset_label)}</b></span>' if dataset_label else ""
    render(f"""
    <div class="fg-result {tone}">
      <div class="fg-result-head">
        <div class="fg-result-icon">{icon(icon_name, 28)}</div>
        <div><div class="fg-result-title">{esc(title)}</div>
        <div class="fg-result-sub">Automated analysis by {esc(result.model_name)}</div></div>
      </div>
      <div class="fg-result-grid">
        <div class="fg-stat"><div class="l">Fraud probability</div><div class="v">{result.probability * 100:.1f}%</div></div>
        <div class="fg-stat"><div class="l">Risk level</div><div class="v">{status_badge(result.risk_level)}</div></div>
        <div class="fg-stat"><div class="l">Prediction</div><div class="v">{status_badge(result.label)}</div></div>
      </div>
      <div class="fg-explain">{esc(explanation)}</div>
      <div class="fg-meta">
        <span>Model: <b>{esc(result.model_name)}</b></span>
        <span>Decision threshold: <b>{result.threshold:.2f}</b></span>
        <span>Analyzed: <b>{result.timestamp.strftime("%d %b %Y, %H:%M:%S")}</b></span>
        {truth}
      </div>
    </div>""")


def _rgba(hex_color: str, alpha: float) -> str:
    """'#RRGGBB' -> 'rgba(r,g,b,alpha)'."""
    h = hex_color.lstrip("#")
    return f"rgba({int(h[0:2], 16)},{int(h[2:4], 16)},{int(h[4:6], 16)},{alpha})"


def gauge_figure(probability: float, threshold: float, suspicious_lower: float) -> go.Figure:
    """Probability gauge with Normal / Suspicious / Fraud zones."""
    p = palette()
    value_color = p["danger"] if probability >= threshold else (
        p["warn"] if probability >= suspicious_lower else p["ok"])
    figure = go.Figure(go.Indicator(
        mode="gauge+number", value=probability * 100,
        number={"suffix": "%", "valueformat": ".1f", "font": {"size": 38, "color": p["text"]}},
        gauge={
            "axis": {"range": [0, 100], "tickcolor": p["muted"], "tickfont": {"color": p["muted"]}},
            "bar": {"color": value_color, "thickness": 0.28},
            "bgcolor": "rgba(0,0,0,0)", "borderwidth": 0,
            "steps": [
                {"range": [0, suspicious_lower * 100], "color": _rgba(p["ok"], 0.55)},
                {"range": [suspicious_lower * 100, threshold * 100], "color": _rgba(p["warn"], 0.60)},
                {"range": [threshold * 100, 100], "color": _rgba(p["danger"], 0.60)},
            ],
            "threshold": {"line": {"color": p["text"], "width": 3}, "thickness": 0.85,
                          "value": threshold * 100},
        },
    ))
    layout = plotly_layout(height=230)
    layout["margin"] = dict(l=40, r=40, t=20, b=10)
    figure.update_layout(**layout)
    return figure


def show_plotly(figure: go.Figure, key: str) -> None:
    """Render a Plotly figure with the app theme (not Streamlit's)."""
    st.plotly_chart(figure, theme=None, key=key, config={"displayModeBar": False},
                    width="stretch")


# ------------------------------------------------- verdicts, actions, reviews
# label -> (tone, icon, word key, short action key, banner key, action key, toast key, toast icon)
_VERDICT = {
    "NORMAL": ("ok", "check", "verdict_safe", "act_ok",
               "banner_normal", "action_normal", "toast_normal", "✅"),
    "SUSPICIOUS": ("warn", "alert", "verdict_suspicious", "act_verify",
                   "banner_suspicious", "action_suspicious", "toast_suspicious", "🟠"),
    "FRAUD": ("danger", "x-circle", "verdict_fraud", "act_block",
              "banner_fraud", "action_fraud", "toast_fraud", "⚠️"),
}

# review status -> (text key, badge tone)
_REVIEW = {
    "PENDING": ("review_pending", "grey"),
    "CONFIRMED_FRAUD": ("review_confirmed", "danger"),
    "FALSE_ALARM": ("review_false", "ok"),
    "APPROVED": ("review_approved", "blue"),
}


def verdict_tone(label: str) -> str:
    return _VERDICT.get(label, _VERDICT["NORMAL"])[0]


def row_tone(label: str) -> str | None:
    """Tone used to tint a table row: red / orange for flagged rows, none for safe ones."""
    return {"FRAUD": "danger", "SUSPICIOUS": "warn"}.get(label)


def verdict_word(label: str) -> str:
    return tr(_VERDICT.get(label, _VERDICT["NORMAL"])[2])


def action_word(label: str) -> str:
    return tr(_VERDICT.get(label, _VERDICT["NORMAL"])[3])


def verdict_cell(label: str) -> str:
    """Icon + plain word (Fraud / Suspicious / Safe) for tables."""
    tone, icon_name = _VERDICT.get(label, _VERDICT["NORMAL"])[:2]
    return (f'<span class="fg-verdict {tone}">{icon(icon_name, 16)}'
            f'{esc(verdict_word(label))}</span>')


def action_cell(label: str) -> str:
    tone = verdict_tone(label)
    return f'<span class="fg-action-word {tone}">{esc(action_word(label))}</span>'


def prob_bar_cell(probability: float) -> str:
    """Percentage + a small horizontal bar coloured by risk (longer = riskier)."""
    pct = max(0.0, min(100.0, float(probability) * 100))
    tone = "danger" if pct >= 50 else ("warn" if pct >= 25 else "ok")
    return (f'<div class="fg-probcell"><span>{pct:.1f}%</span>'
            f'<div class="fg-probbar"><div class="{tone}" style="width:{pct:.1f}%"></div></div></div>')


def review_badge(status: str) -> str:
    key, tone = _REVIEW.get(status, _REVIEW["PENDING"])
    return badge(tr(key), tone)


def verdict_banner(label: str) -> str:
    """Full-width banner with a large icon and large text."""
    tone, icon_name, _, _, banner_key = _VERDICT.get(label, _VERDICT["NORMAL"])[:5]
    return (f'<div class="fg-verdict-banner {tone}"><div class="vb-icon">{icon(icon_name, 40)}</div>'
            f'<div class="vb-text">{esc(tr(banner_key))}</div></div>')


def action_line(label: str) -> str:
    tone = verdict_tone(label)
    action_key = _VERDICT.get(label, _VERDICT["NORMAL"])[5]
    return (f'<div class="fg-action-line {tone}"><div class="t">{esc(tr("action_title"))}</div>'
            f'<div class="d">{esc(tr(action_key))}</div></div>')


def reasons_block(reasons: Sequence[str], show_note: bool = True) -> str:
    """'Why was this flagged?' list. Reason text is escaped."""
    items = "".join(f"<li>{esc(r)}</li>" for r in reasons)
    note = f'<div class="note">{esc(tr("reasons_note"))}</div>' if (show_note and reasons) else ""
    return (f'<div class="fg-reasons"><div class="t">{esc(tr("reasons_title"))}</div>'
            f'<ul>{items}</ul>{note}</div>')


def toast_for(label: str) -> None:
    """One toast for the analysed transaction (red / orange / green)."""
    entry = _VERDICT.get(label, _VERDICT["NORMAL"])
    st.toast(tr(entry[6]), icon=entry[7])


def result_panel(result: PredictionResult, dataset_label: str | None = None,
                 gauge_key: str = "detect_gauge") -> None:
    """New result layout: banner -> action -> reasons -> probability + gauge -> meta.

    The whole area is a keyed container so it can be tinted red / orange / green.
    """
    tone = verdict_tone(result.label)
    probability_pct = result.probability * 100
    confidence = tr("confidence", n=int(round(probability_pct)))
    truth = (f'<span>{esc(tr("meta_dataset_label"))}: <b>{esc(dataset_label)}</b></span>'
             if dataset_label else "")

    with st.container(key=f"fg_result_{tone}"):
        render(verdict_banner(result.label))
        render(action_line(result.label))
        render(reasons_block(result.reasons))
        render(f"""
        <div class="fg-prob">
          <div class="v">{probability_pct:.1f}%</div>
          <div class="r"><div class="l">{esc(tr("prob_label"))} &nbsp; {status_badge(result.risk_level)}</div>
          <div class="c">{esc(confidence)}</div></div>
        </div>""")
        show_plotly(
            gauge_figure(result.probability, result.threshold,
                         result.threshold * SUSPICIOUS_FRACTION),
            gauge_key,
        )
        render(f"""
        <div class="fg-meta">
          <span>{esc(tr("meta_model"))}: <b>{esc(result.model_name)}</b></span>
          <span>{esc(tr("meta_threshold"))}: <b>{result.threshold:.2f}</b></span>
          <span>{esc(tr("meta_time"))}: <b>{result.timestamp.strftime("%d %b %Y, %H:%M:%S")}</b></span>
          {truth}
        </div>""")
