"""Authentication: validation, secure password hashing and session handling.

Passwords are hashed with Werkzeug (PBKDF2-SHA256 with a random per-user salt);
plain-text passwords are never stored or logged.
"""

from __future__ import annotations

import re
import time

import streamlit as st
from werkzeug.security import check_password_hash, generate_password_hash

from app import database
from app.config import LOGIN_LOCK_SECONDS, MAX_LOGIN_ATTEMPTS, MIN_PASSWORD_LENGTH

_EMAIL_RE = re.compile(r"^[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}$")
_HASH_METHOD = "pbkdf2:sha256"
# Used to keep login timing similar for unknown e-mails (avoids user enumeration)
_DUMMY_HASH = generate_password_hash("not-a-real-password", method=_HASH_METHOD)


# --------------------------------------------------------------- validation
def normalize_email(email: str) -> str:
    return (email or "").strip().lower()


def validate_registration(full_name: str, email: str, password: str, confirm: str) -> list[str]:
    """Return a list of user-friendly validation errors (empty if valid)."""
    errors: list[str] = []
    if len((full_name or "").strip()) < 2:
        errors.append("Please enter your full name (at least 2 characters).")
    if len((full_name or "").strip()) > 80:
        errors.append("Full name is too long (maximum 80 characters).")
    if not _EMAIL_RE.match(normalize_email(email)):
        errors.append("Please enter a valid email address.")
    if len(password or "") < MIN_PASSWORD_LENGTH:
        errors.append(f"Password must be at least {MIN_PASSWORD_LENGTH} characters long.")
    elif not (re.search(r"[A-Za-z]", password) and re.search(r"\d", password)):
        errors.append("Password must contain at least one letter and one number.")
    if password != confirm:
        errors.append("Passwords do not match.")
    return errors


# ------------------------------------------------------------ account logic
def register_user(full_name: str, email: str, password: str, confirm: str) -> tuple[bool, list[str]]:
    """Create an account. Returns (success, messages)."""
    errors = validate_registration(full_name, email, password, confirm)
    if errors:
        return False, errors
    try:
        database.create_user(
            full_name.strip(),
            normalize_email(email),
            generate_password_hash(password, method=_HASH_METHOD),
        )
    except database.DuplicateEmailError:
        return False, ["An account with this email already exists. Try signing in."]
    except database.DatabaseError as exc:
        return False, [str(exc)]
    return True, ["Account created successfully. You can now sign in."]


def authenticate(email: str, password: str) -> tuple[dict | None, str | None]:
    """Check credentials. Returns (user, error_message)."""
    remaining = login_lock_remaining()
    if remaining > 0:
        return None, f"Too many failed attempts. Please wait {remaining} seconds."
    if not normalize_email(email) or not password:
        return None, "Please enter your email and password."

    try:
        user = database.get_user_by_email(normalize_email(email))
    except database.DatabaseError as exc:
        return None, str(exc)

    stored_hash = user["password_hash"] if user else _DUMMY_HASH
    valid = check_password_hash(stored_hash, password) and user is not None
    if not valid:
        _register_failed_attempt()
        return None, "Invalid email or password."

    st.session_state["login_attempts"] = 0
    return {"id": user["id"], "full_name": user["full_name"], "email": user["email"]}, None


# ---------------------------------------------------- throttling (per session)
def _register_failed_attempt() -> None:
    attempts = st.session_state.get("login_attempts", 0) + 1
    st.session_state["login_attempts"] = attempts
    if attempts >= MAX_LOGIN_ATTEMPTS:
        st.session_state["login_locked_until"] = time.time() + LOGIN_LOCK_SECONDS
        st.session_state["login_attempts"] = 0


def login_lock_remaining() -> int:
    until = st.session_state.get("login_locked_until", 0)
    return max(0, int(round(until - time.time())))


# ------------------------------------------------------------ session state
def current_user() -> dict | None:
    return st.session_state.get("user")


def login_session(user: dict) -> None:
    st.session_state["user"] = user
    st.session_state["page"] = "dashboard"


def logout() -> None:
    """Clear everything except the theme preference."""
    theme = st.session_state.get("theme", "light")
    st.session_state.clear()
    st.session_state["theme"] = theme
