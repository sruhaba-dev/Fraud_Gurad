"""SQLite persistence for user accounts and prediction history.

Only parameterised queries are used. Passwords are never stored here in plain
text - callers pass an already-hashed password (see auth.py).
"""

from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from typing import Iterator

import pandas as pd

from app.config import DB_PATH, NOTE_MAX_LENGTH, REVIEW_STATUSES


class DatabaseError(Exception):
    """Raised for any database problem; the message is safe to show to users."""


class DuplicateEmailError(DatabaseError):
    """Raised when registering an e-mail address that already exists."""


SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    full_name     TEXT NOT NULL,
    email         TEXT NOT NULL UNIQUE COLLATE NOCASE,
    password_hash TEXT NOT NULL,
    created_at    TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS predictions (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    amount      REAL NOT NULL,
    prediction  TEXT NOT NULL CHECK (prediction IN ('NORMAL', 'SUSPICIOUS', 'FRAUD')),
    probability REAL NOT NULL CHECK (probability BETWEEN 0 AND 1),
    risk_level  TEXT NOT NULL CHECK (risk_level IN ('LOW', 'MEDIUM', 'HIGH')),
    model_name  TEXT NOT NULL,
    threshold   REAL,
    created_at  TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_predictions_user_created
    ON predictions (user_id, created_at DESC);
"""


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


@contextmanager
def _connect() -> Iterator[sqlite3.Connection]:
    """Open a connection with foreign keys enabled; commit or roll back."""
    try:
        DB_PATH.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(DB_PATH, timeout=10)
    except (sqlite3.Error, OSError) as exc:
        raise DatabaseError("The database is currently unavailable.") from exc
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    try:
        yield conn
        conn.commit()
    except sqlite3.IntegrityError:
        conn.rollback()
        raise
    except sqlite3.Error as exc:
        conn.rollback()
        raise DatabaseError("A database error occurred. Please try again.") from exc
    finally:
        conn.close()


# Columns added after the first release. SQLite cannot add a CHECK constraint
# with ALTER TABLE, so the allowed review values are validated in Python.
_NEW_PREDICTION_COLUMNS = {
    "reasons": "TEXT DEFAULT '[]'",
    "review_status": "TEXT NOT NULL DEFAULT 'PENDING'",
    "note": "TEXT",
}


def _migrate_predictions(conn: sqlite3.Connection) -> None:
    """Add the new prediction columns to an older database (existing rows are kept)."""
    existing = {row["name"] for row in conn.execute("PRAGMA table_info(predictions)")}
    for column, definition in _NEW_PREDICTION_COLUMNS.items():
        if column not in existing:
            conn.execute(f"ALTER TABLE predictions ADD COLUMN {column} {definition}")


def init_db() -> None:
    """Create the tables if they do not exist yet and migrate older databases."""
    with _connect() as conn:
        conn.executescript(SCHEMA)
        _migrate_predictions(conn)


# ------------------------------------------------------------------ users
def create_user(full_name: str, email: str, password_hash: str) -> int:
    """Insert a user and return the new id. Raises DuplicateEmailError."""
    try:
        with _connect() as conn:
            cursor = conn.execute(
                "INSERT INTO users (full_name, email, password_hash, created_at) "
                "VALUES (?, ?, ?, ?)",
                (full_name, email, password_hash, _utc_now()),
            )
            return int(cursor.lastrowid)
    except sqlite3.IntegrityError as exc:
        raise DuplicateEmailError("An account with this email already exists.") from exc


def get_user_by_email(email: str) -> dict | None:
    """Return the user row (including password hash) or None."""
    with _connect() as conn:
        row = conn.execute(
            "SELECT id, full_name, email, password_hash, created_at "
            "FROM users WHERE email = ?", (email,),
        ).fetchone()
    return dict(row) if row else None


# ------------------------------------------------------------ predictions
def add_prediction(
    user_id: int, amount: float, prediction: str, probability: float,
    risk_level: str, model_name: str, threshold: float,
    reasons: list[str] | None = None,
) -> int:
    """Store one prediction for a user and return its id."""
    reasons_json = json.dumps(list(reasons or []), ensure_ascii=False)
    with _connect() as conn:
        cursor = conn.execute(
            "INSERT INTO predictions (user_id, amount, prediction, probability, "
            "risk_level, model_name, threshold, created_at, reasons) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (user_id, float(amount), prediction, float(probability), risk_level,
             model_name, float(threshold), _utc_now(), reasons_json),
        )
        return int(cursor.lastrowid)


_PREDICTION_COLUMNS = [
    "id", "amount", "prediction", "probability", "risk_level",
    "model_name", "threshold", "created_at",
    "reasons", "review_status", "note",
]


def _parse_reasons(raw) -> list[str]:
    """Turn the stored JSON text back into a list of strings."""
    try:
        value = json.loads(raw) if raw else []
    except (TypeError, ValueError):
        return []
    return [str(item) for item in value] if isinstance(value, list) else []


def get_predictions(user_id: int, limit: int | None = None) -> pd.DataFrame:
    """Return ONLY this user's predictions, newest first."""
    query = (
        "SELECT id, amount, prediction, probability, risk_level, model_name, "
        "threshold, created_at, reasons, review_status, note "
        "FROM predictions WHERE user_id = ? "
        "ORDER BY created_at DESC, id DESC"
    )
    params: tuple = (user_id,)
    if limit is not None:
        query += " LIMIT ?"
        params = (user_id, int(limit))
    with _connect() as conn:
        rows = conn.execute(query, params).fetchall()
    frame = pd.DataFrame([dict(r) for r in rows], columns=_PREDICTION_COLUMNS)
    if not frame.empty:
        # Stored in UTC; shown in the viewer's local time zone
        frame["created_at"] = (
            pd.to_datetime(frame["created_at"], utc=True).dt.tz_convert(
                datetime.now().astimezone().tzinfo
            )
        )
        frame["reasons"] = frame["reasons"].map(_parse_reasons)
        frame["review_status"] = frame["review_status"].fillna("PENDING")
        frame["note"] = frame["note"].fillna("")
    return frame


def update_review(user_id: int, prediction_id: int, review_status: str,
                  note: str = "") -> bool:
    """Save the review decision for ONE of this user's predictions.

    Only rows that belong to `user_id` are touched. Returns True when a row
    was updated, False when the prediction does not exist for this user.
    """
    if review_status not in REVIEW_STATUSES:
        raise DatabaseError("Invalid review status.")
    note = (note or "").strip()
    if len(note) > NOTE_MAX_LENGTH:
        raise DatabaseError(f"The note can have at most {NOTE_MAX_LENGTH} characters.")
    with _connect() as conn:
        cursor = conn.execute(
            "UPDATE predictions SET review_status = ?, note = ? "
            "WHERE id = ? AND user_id = ?",
            (review_status, note, int(prediction_id), user_id),
        )
        return cursor.rowcount > 0


def count_unreviewed(user_id: int) -> int:
    """Number of FRAUD / SUSPICIOUS predictions that are still PENDING."""
    with _connect() as conn:
        row = conn.execute(
            "SELECT COUNT(*) AS n FROM predictions WHERE user_id = ? "
            "AND prediction IN ('FRAUD', 'SUSPICIOUS') AND review_status = 'PENDING'",
            (user_id,),
        ).fetchone()
    return int(row["n"])


def count_predictions(user_id: int) -> int:
    with _connect() as conn:
        row = conn.execute(
            "SELECT COUNT(*) AS n FROM predictions WHERE user_id = ?", (user_id,)
        ).fetchone()
    return int(row["n"])


def clear_predictions(user_id: int) -> int:
    """Delete only this user's predictions; returns the number removed."""
    with _connect() as conn:
        cursor = conn.execute("DELETE FROM predictions WHERE user_id = ?", (user_id,))
        return int(cursor.rowcount)
