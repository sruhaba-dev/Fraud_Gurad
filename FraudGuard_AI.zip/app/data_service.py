"""Dataset and report data services for FraudGuard UI."""

from __future__ import annotations

import numpy as np
import pandas as pd
import streamlit as st

from app.config import (
    COMPARISON_CSV,
    BASELINE_COMPARISON_CSV,
    DATA_PATH,
    DATASET_LOCATIONS,
    FEATURE_COLUMNS,
    TUNED_REPORT_NAME,
)


# --------------------------------------------------------------------------
# Metrics
# --------------------------------------------------------------------------

METRIC_COLUMNS = [
    "Precision",
    "Recall",
    "F1-Score",
    "PR-AUC",
    "ROC-AUC",
    "Accuracy",
]

COUNT_COLUMNS = [
    "TN",
    "FP",
    "FN",
    "TP",
]


# --------------------------------------------------------------------------
# Dataset analysis settings
# --------------------------------------------------------------------------

N_AMOUNT_BINS = 40
SAMPLE_POOL_NORMAL = 300


# --------------------------------------------------------------------------
# Dataset bundle
# --------------------------------------------------------------------------

@st.cache_data(
    show_spinner="Analyzing the dataset (first load only)..."
)
def _build_bundle(mtime: float) -> dict:
    """Load the NEW dataset and calculate UI aggregates."""

    df = pd.read_csv(DATA_PATH)

    required_columns = [
        "TransactionID",
        "TransactionDate",
        "Amount",
        "MerchantID",
        "TransactionType",
        "Location",
        "IsFraud",
    ]

    missing = [
        column
        for column in required_columns
        if column not in df.columns
    ]

    if missing:
        raise ValueError(
            f"Dataset is missing required columns: {missing}"
        )

    # ----------------------------------------------------------------------
    # Basic counts
    # ----------------------------------------------------------------------

    n_total = int(len(df))

    n_fraud = int(
        (df["IsFraud"] == 1).sum()
    )

    n_normal = int(
        (df["IsFraud"] == 0).sum()
    )

    fraud_rate_pct = (
        n_fraud / n_total * 100
        if n_total
        else 0.0
    )

    # ----------------------------------------------------------------------
    # Amount analysis
    # ----------------------------------------------------------------------

    amount = df["Amount"].astype(float)

    log_amount = np.log1p(
        amount.to_numpy()
    )

    max_log_amount = (
        float(log_amount.max())
        if len(log_amount)
        else 1.0
    )

    edges = np.linspace(
        0,
        max_log_amount,
        N_AMOUNT_BINS + 1,
    )

    normal_counts, _ = np.histogram(
        log_amount[
            df["IsFraud"].to_numpy() == 0
        ],
        bins=edges,
    )

    fraud_counts, _ = np.histogram(
        log_amount[
            df["IsFraud"].to_numpy() == 1
        ],
        bins=edges,
    )

    # ----------------------------------------------------------------------
    # Amount statistics
    # ----------------------------------------------------------------------

    amount_stats = (
        df.groupby("IsFraud")["Amount"]
        .agg(
            [
                "count",
                "mean",
                "median",
                "std",
                "min",
                "max",
            ]
        )
        .rename(
            index={
                0: "Normal",
                1: "Fraud",
            }
        )
    )

    overall = amount.agg(
        [
            "min",
            "max",
            "mean",
            "median",
        ]
    )

    # ----------------------------------------------------------------------
    # Transaction type analysis
    # ----------------------------------------------------------------------

    transaction_type = (
        df.groupby("TransactionType")["IsFraud"]
        .agg(
            total="count",
            fraud="sum",
        )
    )

    transaction_type["fraud_rate_pct"] = (
        transaction_type["fraud"]
        / transaction_type["total"]
        * 100
    )

    # ----------------------------------------------------------------------
    # Location analysis
    # ----------------------------------------------------------------------

    location = (
        df.groupby("Location")["IsFraud"]
        .agg(
            total="count",
            fraud="sum",
        )
    )

    location["fraud_rate_pct"] = (
        location["fraud"]
        / location["total"]
        * 100
    )

    # ----------------------------------------------------------------------
    # Transaction hour analysis
    # ----------------------------------------------------------------------

    dates = pd.to_datetime(
        df["TransactionDate"],
        errors="coerce",
    )

    transaction_hour = dates.dt.hour

    hourly = df.assign(
        TransactionHour=transaction_hour
    ).groupby(
        "TransactionHour"
    )["IsFraud"].agg(
        total="count",
        fraud="sum",
    )

    hourly["fraud_rate_pct"] = (
        hourly["fraud"]
        / hourly["total"]
        * 100
    )

    # ----------------------------------------------------------------------
    # Numeric correlation
    # ----------------------------------------------------------------------

    numeric_df = pd.DataFrame(
        {
            "Amount": df["Amount"],
            "MerchantID": df["MerchantID"],
            "IsFraud": df["IsFraud"],
        }
    )

    corr = numeric_df.corr(
        numeric_only=True
    )

    # ----------------------------------------------------------------------
    # Sample transactions
    # ----------------------------------------------------------------------

    samples = {
        "fraud": pd.DataFrame(),
        "normal": pd.DataFrame(),
    }

    try:
        from sklearn.model_selection import train_test_split

        X = df.drop(
            "IsFraud",
            axis=1,
        )

        y = df["IsFraud"]

        _, X_test, _, y_test = train_test_split(
            X,
            y,
            test_size=0.2,
            random_state=42,
            stratify=y,
        )

        fraud_samples = X_test.loc[
            y_test == 1
        ]

        normal_samples = X_test.loc[
            y_test == 0
        ]

        samples["fraud"] = (
            fraud_samples
            .head(SAMPLE_POOL_NORMAL)
            .reset_index(drop=True)
        )

        samples["normal"] = (
            normal_samples
            .sample(
                min(
                    SAMPLE_POOL_NORMAL,
                    len(normal_samples),
                ),
                random_state=42,
            )
            .reset_index(drop=True)
        )

    except Exception:
        pass

    # ----------------------------------------------------------------------
    # Return complete bundle
    # ----------------------------------------------------------------------

    return {
        "n_total": n_total,
        "n_fraud": n_fraud,
        "n_normal": n_normal,
        "fraud_rate_pct": fraud_rate_pct,
        "n_columns": int(df.shape[1]),

        "amount_edges": edges,

        "amount_normal_pct": (
            normal_counts
            / max(normal_counts.sum(), 1)
            * 100
        ),

        "amount_fraud_pct": (
            fraud_counts
            / max(fraud_counts.sum(), 1)
            * 100
        ),

        "amount_stats": amount_stats,
        "amount_overall": overall,

        "transaction_type": transaction_type,
        "location": location,
        "hourly": hourly,

        "time_max_seconds": 0.0,

        "corr": corr,

        "samples": samples,
    }


def dataset_bundle() -> dict | None:
    """Return dataset aggregates or None if unavailable."""

    if not DATA_PATH.exists():
        return None

    try:
        return _build_bundle(
            DATA_PATH.stat().st_mtime
        )
    except Exception:
        return None


# --------------------------------------------------------------------------
# Model comparison reports
# --------------------------------------------------------------------------

@st.cache_data(show_spinner=False)
def _read_comparison(
    path_str: str,
    mtime: float,
) -> pd.DataFrame | None:

    frame = pd.read_csv(path_str)

    required = {
        "Model",
        *METRIC_COLUMNS,
        *COUNT_COLUMNS,
    }

    if not required.issubset(
        frame.columns
    ):
        return None

    return frame.set_index("Model")


def comparison_table() -> pd.DataFrame | None:
    """
    Read the tuned model comparison report.

    Falls back to the baseline comparison report if the
    improvement report is unavailable.
    """

    if COMPARISON_CSV.exists():

        try:
            table = _read_comparison(
                str(COMPARISON_CSV),
                COMPARISON_CSV.stat().st_mtime,
            )

            if table is not None:
                return table

        except Exception:
            pass

    if BASELINE_COMPARISON_CSV.exists():

        try:
            return _read_comparison(
                str(BASELINE_COMPARISON_CSV),
                BASELINE_COMPARISON_CSV.stat().st_mtime,
            )

        except Exception:
            pass

    return None


# --------------------------------------------------------------------------
# Threshold information
# --------------------------------------------------------------------------

def threshold_table() -> pd.DataFrame | None:
    """
    Threshold analysis is optional.

    The current model-improvement pipeline may not generate
    threshold_analysis.csv, so the UI should not fail if it
    is unavailable.
    """

    return None


def train_selected_threshold() -> float | None:
    """
    Return a selected threshold if one exists.

    The current model-improvement report does not require a
    separate threshold_analysis.csv, so return None when no
    dedicated threshold report is available.
    """

    return None


# --------------------------------------------------------------------------
# Locations (taken from the dataset, so the form always matches the models)
# --------------------------------------------------------------------------

@st.cache_data(show_spinner=False)
def _read_locations(mtime: float) -> list[str]:
    df = pd.read_csv(DATA_PATH, usecols=["Location"])
    values = df["Location"].dropna().astype(str).str.strip()
    return sorted({value for value in values if value})


def location_options() -> list[str]:
    """Cities found in the dataset (falls back to the built-in dataset list)."""

    try:
        locations = _read_locations(DATA_PATH.stat().st_mtime)
    except Exception:
        locations = []

    return locations or list(DATASET_LOCATIONS)


# --------------------------------------------------------------------------
# Look a transaction up in the dataset ("Check in dataset")
# --------------------------------------------------------------------------

@st.cache_data(show_spinner=False)
def _read_transactions(mtime: float) -> pd.DataFrame:
    df = pd.read_csv(
        DATA_PATH,
        usecols=[
            "TransactionID",
            "TransactionDate",
            "Amount",
            "MerchantID",
            "TransactionType",
            "Location",
            "IsFraud",
        ],
    )
    df["TransactionType"] = df["TransactionType"].astype(str).str.strip().str.lower()
    df["Location"] = df["Location"].astype(str).str.strip()
    return df


def find_in_dataset(values) -> dict | None:
    """Look a transaction up in the dataset and explain the result.

    status:
      FRAUD       - same Amount, MerchantID, Type and Location found, all fraud
      NOT FRAUD   - found, all marked normal
      MIXED       - found several times, some fraud and some normal
      SUSPICIOUS  - not found, but the same MerchantID (or MerchantID + Amount)
                    has a fraud record in the dataset
      NOT FOUND   - nothing in the dataset relates to this transaction

    Returns None if the dataset cannot be read.
    """

    try:
        df = _read_transactions(DATA_PATH.stat().st_mtime)

        amount = float(values["Amount"])
        merchant = int(values["MerchantID"])
        kind = str(values["TransactionType"]).strip().lower()
        city = str(values["Location"]).strip()

        same_amount = (df["Amount"] - amount).abs() < 0.005
        same_merchant = df["MerchantID"] == merchant
        is_fraud = df["IsFraud"] == 1

        exact = df[
            same_amount
            & same_merchant
            & (df["TransactionType"] == kind)
            & (df["Location"] == city)
        ]

        merchant_rows = df[same_merchant]
        merchant_fraud = merchant_rows[merchant_rows["IsFraud"] == 1]
        merchant_amount_fraud = df[same_merchant & same_amount & is_fraud]
    except Exception:
        return None

    n = int(len(exact))
    n_fraud = int((exact["IsFraud"] == 1).sum())

    reference = None

    if n > 0:
        if n_fraud == n:
            status = "FRAUD"
        elif n_fraud == 0:
            status = "NOT FRAUD"
        else:
            status = "MIXED"

        # prefer a fraud record as the reference when there is a mix
        ordered = exact.sort_values("IsFraud", ascending=False)
        reference = ordered.iloc[0].to_dict()
    elif len(merchant_fraud) > 0:
        status = "SUSPICIOUS"
        source = (
            merchant_amount_fraud
            if len(merchant_amount_fraud) > 0
            else merchant_fraud
        )
        reference = source.iloc[0].to_dict()
    else:
        status = "NOT FOUND"

    return {
        "status": status,
        "n": n,
        "n_fraud": n_fraud,
        "records": exact.head(3).to_dict("records"),
        "merchant_total": int(len(merchant_rows)),
        "merchant_fraud": int(len(merchant_fraud)),
        "merchant_fraud_records": merchant_fraud.head(3).to_dict("records"),
        "merchant_amount_fraud": int(len(merchant_amount_fraud)),
        "reference": reference,
    }


# --------------------------------------------------------------------------
# Statistics of NORMAL transactions (used to explain a flagged transaction)
# --------------------------------------------------------------------------

_PROFILE_NUMERIC = [
    "TransactionHour",
    "TransactionDay",
    "TransactionMonth",
    "TransactionDayOfWeek",
]


@st.cache_data(show_spinner=False)
def _build_normal_profile(mtime: float) -> dict:
    """Mean / std of numeric features and value shares of categorical ones,
    computed on NORMAL transactions only."""

    df = pd.read_csv(
        DATA_PATH,
        usecols=["TransactionDate", "TransactionType", "Location", "IsFraud"],
    )

    normal = df.loc[df["IsFraud"] == 0].copy()
    dates = pd.to_datetime(normal["TransactionDate"], errors="coerce")

    derived = pd.DataFrame(
        {
            "TransactionHour": dates.dt.hour,
            "TransactionDay": dates.dt.day,
            "TransactionMonth": dates.dt.month,
            "TransactionDayOfWeek": dates.dt.dayofweek,
        }
    )

    numeric = {}

    for column in _PROFILE_NUMERIC:
        series = derived[column].dropna().astype(float)

        if len(series) > 1:
            numeric[column] = (
                float(series.mean()),
                float(series.std()),
            )

    categorical = {}

    for column in ["TransactionType", "Location"]:
        shares = (
            normal[column]
            .astype(str)
            .str.strip()
            .str.lower()
            .value_counts(normalize=True)
        )
        categorical[column] = {
            str(key): float(value) for key, value in shares.items()
        }

    return {
        "numeric": numeric,
        "categorical": categorical,
    }


def normal_profile() -> dict | None:
    """Return the statistics of NORMAL transactions, or None if unavailable.

    The Amount statistics (mean / median / std) come from dataset_bundle();
    everything else is calculated once from the dataset and cached.
    """

    bundle = dataset_bundle()

    if not bundle or not DATA_PATH.exists():
        return None

    try:
        profile = dict(_build_normal_profile(DATA_PATH.stat().st_mtime))
        stats = bundle["amount_stats"].loc["Normal"]

        profile["amount"] = {
            "mean": float(stats["mean"]),
            "median": float(stats["median"]),
            "std": float(stats["std"]),
        }

        return profile

    except Exception:
        return None
