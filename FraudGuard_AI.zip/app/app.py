"""
FraudGuard AI - Streamlit entry point.

Run from the project root:
    streamlit run app/app.py
"""

from __future__ import annotations

import sys
from pathlib import Path

# `streamlit run app/app.py` puts the app/ folder itself on sys.path, where the file
# app.py would shadow the `app` package. Remove it and put the project root first so
# that `import app` (package) and `import src` (ML code) resolve correctly.
_APP_DIR = Path(__file__).resolve().parent
_ROOT = _APP_DIR.parent
sys.path[:] = [p for p in sys.path if Path(p or ".").resolve() != _APP_DIR]
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

import streamlit as st

st.set_page_config(page_title="FraudGuard AI", page_icon="\U0001F6E1\uFE0F", layout="wide",
                   initial_sidebar_state="expanded")

from app import auth, database
from app.config import APP_NAME, DEFAULT_LANGUAGE, LANGUAGES, NAV_ITEMS
from app.i18n import tr
from app.theme import inject_theme
from app.ui_components import esc, go_to, icon, notice, render, theme_button
from app.views.landing import render_landing
from app.views.about import render_about
from app.views.analytics import render_analytics
from app.views.auth_view import render_auth
from app.views.comparison import render_comparison
from app.views.dashboard import render_dashboard
from app.views.detection import render_detection
from app.views.history import render_history
from app.views.how_it_works import render_how_it_works


@st.cache_resource(show_spinner=False)
def _init_database() -> bool:
    database.init_db()
    return True


def _sidebar(user: dict) -> None:
    with st.sidebar:
        render(f'<div class="fg-brand"><div class="logo">{icon("shield", 22)}</div>'
               f'<div><div class="name">{APP_NAME}</div><div class="tag">AI-Powered Fraud Detection</div></div></div>')
        render('<div class="fg-nav-label">Menu</div>')
        current = st.session_state.get("page", "dashboard")
        for key, (label, material_icon) in NAV_ITEMS.items():
            st.button(label, icon=material_icon, key=f"nav_{key}", width="stretch",
                      type="primary" if key == current else "secondary",
                      on_click=go_to, args=(key,))

        st.divider()
        initials = "".join(part[0] for part in user["full_name"].split()[:2]).upper()
        render(f'<div class="fg-user"><div class="fg-avatar">{esc(initials)}</div>'
               f'<div><div class="n">{esc(user["full_name"])}</div><div class="e">{esc(user["email"])}</div></div></div>')
        theme_button("theme_button_sidebar")
        st.session_state.setdefault("lang", DEFAULT_LANGUAGE)
        st.selectbox(tr("language"), list(LANGUAGES), key="lang",
                     format_func=lambda code: LANGUAGES[code])
        st.button("Logout", icon=":material/logout:", key="logout", width="stretch",
                  on_click=auth.logout)


def main() -> None:
    st.session_state.setdefault("theme", "light")
    inject_theme()

    try:
        _init_database()
    except database.DatabaseError as exc:
        notice("danger", str(exc))
        st.stop()

    user = auth.current_user()
    if user is None:
        if st.session_state.get("auth_view", "landing") == "landing":
            render_landing()
        else:
            render_auth()
        return

    st.session_state.setdefault("page", "dashboard")
    _sidebar(user)

    page = st.session_state["page"]
    if page == "dashboard":
        render_dashboard(user)
    elif page == "detect":
        render_detection(user)
    elif page == "history":
        render_history(user)
    elif page == "analytics":
        render_analytics()
    elif page == "models":
        render_comparison()
    elif page == "how":
        render_how_it_works()
    else:
        render_about()


main()
