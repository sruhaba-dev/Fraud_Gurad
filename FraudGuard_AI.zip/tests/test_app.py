"""Automated checks for the FraudGuard AI web application.

Run from the project root (venv active):
    pip install pytest
    pytest tests -q
"""

from pathlib import Path

import numpy as np
import pytest
from streamlit.testing.v1 import AppTest

from app import auth, database, model_service
from app.config import FEATURE_COLUMNS, MODEL_REGISTRY, NAV_ITEMS

ENTRY = str(Path(__file__).resolve().parents[1] / "app" / "app.py")
PASSWORD = "Passw0rd123"


def new_app() -> AppTest:
    """Start the app directly on the login screen (the public landing page is tested separately)."""
    at = AppTest.from_file(ENTRY, default_timeout=180)
    at.session_state["auth_view"] = "login"
    return at.run()


def register(name="Ali Raza", email="ali@example.com", password=PASSWORD):
    ok, messages = auth.register_user(name, email, password, password)
    assert ok, messages
    return database.get_user_by_email(email)


def sign_in(at: AppTest, email="ali@example.com", password=PASSWORD) -> AppTest:
    at.text_input(key="login_email").input(email)
    at.text_input(key="login_password").input(password)
    next(b for b in at.button if b.label == "Sign In").click()
    return at.run()


def markdown_text(at: AppTest) -> str:
    return " ".join(m.value for m in at.markdown)


# ------------------------------------------------------------------ startup
def test_app_starts_on_landing_page():
    at = AppTest.from_file(ENTRY, default_timeout=180).run()
    assert not at.exception
    assert any(b.label == "Login" for b in at.button)
    assert any(b.label == "Sign Up" for b in at.button)


def test_login_screen_has_sign_in_and_create_account_tabs():
    at = new_app()
    assert not at.exception
    assert [t.label for t in at.tabs] == ["Sign In", "Create Account"]


# ------------------------------------------------------------ registration
@pytest.mark.parametrize("name,email,password,confirm,fragment", [
    ("A", "a@example.com", PASSWORD, PASSWORD, "full name"),
    ("Ali Raza", "not-an-email", PASSWORD, PASSWORD, "valid email"),
    ("Ali Raza", "a@example.com", "short1", "short1", "at least 8"),
    ("Ali Raza", "a@example.com", "onlyletters", "onlyletters", "letter and one number"),
    ("Ali Raza", "a@example.com", PASSWORD, "Different123", "do not match"),
])
def test_registration_validation(name, email, password, confirm, fragment):
    ok, messages = auth.register_user(name, email, password, confirm)
    assert not ok and any(fragment in m for m in messages)


def test_registration_success_and_duplicate_email():
    assert auth.register_user("Ali Raza", "ali@example.com", PASSWORD, PASSWORD)[0]
    ok, messages = auth.register_user("Other", "ALI@example.com", PASSWORD, PASSWORD)
    assert not ok and "already exists" in messages[0]


def test_password_is_hashed_not_plaintext():
    user = register()
    stored = user["password_hash"]
    assert PASSWORD not in stored and stored.startswith("pbkdf2:")


# ------------------------------------------------------------------- login
def test_login_with_wrong_password_shows_error():
    register()
    at = sign_in(new_app(), password="WrongPass123")
    assert "Invalid email or password" in markdown_text(at)
    assert "user" not in at.session_state or at.session_state["user"] is None


def test_login_dashboard_and_logout():
    register()
    at = sign_in(new_app())
    assert not at.exception
    assert at.session_state["user"]["email"] == "ali@example.com"
    assert "Welcome back, Ali" in markdown_text(at)
    next(b for b in at.button if b.label == "Logout").click()
    at.run()
    assert "user" not in at.session_state or at.session_state["user"] is None
    assert any(b.label == "Login" for b in at.button)


def test_login_lockout_after_repeated_failures():
    register()
    at = new_app()
    for _ in range(5):
        at = sign_in(at, password="WrongPass123")
    assert "Too many failed attempts" in markdown_text(sign_in(at, password=PASSWORD))


# ------------------------------------------------------------ all the pages
@pytest.mark.parametrize("page", list(NAV_ITEMS))
def test_every_page_renders_without_errors(page):
    register()
    at = sign_in(new_app())
    at.session_state["page"] = page
    at.run()
    assert not at.exception, [e.value for e in at.exception]


def test_theme_switch_changes_the_whole_stylesheet():
    at = AppTest.from_file(ENTRY, default_timeout=180).run()
    light_css = markdown_text(at)
    at.button(key="theme_button_landing").click()
    at.run()
    assert at.session_state["theme"] == "dark"
    dark_css = markdown_text(at)
    assert "--bg: #F3F5FA" in light_css and "--bg: #0A0F1F" in dark_css


# ----------------------------------------------------- model + preprocessing
def available():
    return model_service.available_models()


@pytest.mark.skipif(not model_service.available_models(), reason="no trained models found")
def test_all_saved_models_and_scaler_load():
    assert model_service.load_scaler() is not None
    for spec in available():
        assert hasattr(model_service.load_model(spec), "predict_proba")


def test_feature_order_is_enforced():
    values = {c: 0.0 for c in FEATURE_COLUMNS}
    frame = model_service.build_feature_frame(values)
    assert list(frame.columns) == FEATURE_COLUMNS
    assert FEATURE_COLUMNS[0] == "Time" and FEATURE_COLUMNS[-1] == "Amount" and len(FEATURE_COLUMNS) == 30
    reordered = dict(reversed(list(values.items())))  # order of the dict must not matter
    assert list(model_service.build_feature_frame(reordered).columns) == FEATURE_COLUMNS


@pytest.mark.parametrize("mutation,fragment", [
    ({"Amount": -5.0}, "negative"),
    ({"V3": float("nan")}, "finite"),
    ({"V7": "abc"}, "number"),
])
def test_invalid_inputs_are_rejected(mutation, fragment):
    values = {c: 0.0 for c in FEATURE_COLUMNS}
    values.update(mutation)
    with pytest.raises(model_service.ModelServiceError, match=fragment):
        model_service.build_feature_frame(values)


def test_missing_feature_is_rejected():
    values = {c: 0.0 for c in FEATURE_COLUMNS}
    del values["V10"]
    with pytest.raises(model_service.ModelServiceError):
        model_service.build_feature_frame(values)


def test_preprocessing_only_transforms_and_never_fits():
    class TransformOnlyScaler:
        mean_ = np.array([0.0, 0.0])

        def transform(self, frame):
            assert list(frame.columns) == ["Time", "Amount"]
            return frame.to_numpy() * 2

        def fit(self, *args, **kwargs):  # must never be called
            raise AssertionError("scaler must not be fitted in the app")

    frame = model_service.build_feature_frame({**{c: 1.0 for c in FEATURE_COLUMNS}})
    scaled = model_service.preprocess(frame, TransformOnlyScaler())
    assert scaled.at[0, "Time"] == 2.0 and scaled.at[0, "Amount"] == 2.0 and scaled.at[0, "V1"] == 1.0
    assert list(scaled.columns) == FEATURE_COLUMNS


@pytest.mark.parametrize("probability,label,risk", [
    (0.02, "NORMAL", "LOW"), (0.30, "SUSPICIOUS", "MEDIUM"),
    (0.50, "FRAUD", "HIGH"), (0.99, "FRAUD", "HIGH"),
])
def test_risk_classification(probability, label, risk):
    assert model_service.classify(probability, 0.5) == (label, risk)


@pytest.mark.skipif(not model_service.available_models(), reason="no trained models found")
@pytest.mark.parametrize("key", list(MODEL_REGISTRY))
def test_prediction_returns_valid_result(key):
    spec = MODEL_REGISTRY[key]
    if not spec.file.exists():
        pytest.skip("model file missing")
    result = model_service.predict(spec, {c: 0.0 for c in FEATURE_COLUMNS})
    assert 0.0 <= result.probability <= 1.0
    assert result.label in {"NORMAL", "SUSPICIOUS", "FRAUD"}
    assert result.model_name == spec.report_name


# --------------------------------------------------------- history isolation
def test_prediction_history_is_private_per_user():
    alice, bob = register("Alice A", "alice@example.com"), register("Bob B", "bob@example.com")
    database.add_prediction(alice["id"], 10.0, "FRAUD", 0.9, "HIGH", "m", 0.5)
    database.add_prediction(bob["id"], 20.0, "NORMAL", 0.01, "LOW", "m", 0.5)
    assert len(database.get_predictions(alice["id"])) == 1
    assert database.get_predictions(alice["id"]).iloc[0]["amount"] == 10.0
    assert database.clear_predictions(alice["id"]) == 1
    assert len(database.get_predictions(alice["id"])) == 0
    assert len(database.get_predictions(bob["id"])) == 1  # untouched


def test_detection_page_saves_prediction_to_history():
    if not model_service.available_models():
        pytest.skip("no trained models found")
    user = register()
    at = sign_in(new_app())
    at.session_state["page"] = "detect"
    at.run()
    next(b for b in at.button if b.label == "Analyze transaction").click()
    at.run()
    assert not at.exception
    assert len(database.get_predictions(user["id"])) == 1
    assert at.session_state["last_result"]["result"].label in {"NORMAL", "SUSPICIOUS", "FRAUD"}


# =====================================================================
# Verdicts, reasons and review workflow
# =====================================================================
import sqlite3

import pandas as pd

from app import data_service
from app.config import UI_TEXT
from app.i18n import tr
from app.model_service import PredictionResult
from app.views import history as history_view

OLD_SCHEMA = """
CREATE TABLE users (
    id INTEGER PRIMARY KEY AUTOINCREMENT, full_name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE COLLATE NOCASE, password_hash TEXT NOT NULL,
    created_at TEXT NOT NULL
);
CREATE TABLE predictions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    amount REAL NOT NULL,
    prediction TEXT NOT NULL CHECK (prediction IN ('NORMAL', 'SUSPICIOUS', 'FRAUD')),
    probability REAL NOT NULL CHECK (probability BETWEEN 0 AND 1),
    risk_level TEXT NOT NULL CHECK (risk_level IN ('LOW', 'MEDIUM', 'HIGH')),
    model_name TEXT NOT NULL, threshold REAL, created_at TEXT NOT NULL
);
"""

FRAUD_SAMPLE = {"Amount": 4900.0, "TransactionType": "refund", "Location": "San Jose"}
NORMAL_SAMPLE = {"Amount": 2500.0, "TransactionType": "purchase", "Location": "Dallas"}


def _spec():
    return MODEL_REGISTRY["knn"]


@pytest.mark.parametrize("probability,threshold,label,risk", [
    (0.02, 0.5, "NORMAL", "LOW"), (0.30, 0.5, "SUSPICIOUS", "MEDIUM"),
    (0.50, 0.5, "FRAUD", "HIGH"), (0.20, 0.4, "SUSPICIOUS", "MEDIUM"),
    (0.19, 0.4, "NORMAL", "LOW"),
])
def test_classify_is_unchanged(probability, threshold, label, risk):
    assert model_service.classify(probability, threshold) == (label, risk)


@pytest.mark.skipif(data_service.normal_profile() is None, reason="dataset not found")
@pytest.mark.parametrize("label", ["FRAUD", "SUSPICIOUS"])
def test_explain_returns_three_reasons_for_flagged_transactions(label):
    reasons = model_service.explain(FRAUD_SAMPLE, _spec(), label=label, lang="en")
    assert len(reasons) == 3
    assert all(isinstance(r, str) and r for r in reasons)
    assert any("Amount" in r for r in reasons)


@pytest.mark.skipif(data_service.normal_profile() is None, reason="dataset not found")
def test_explain_works_for_roman_urdu_and_models_without_importance():
    reasons = model_service.explain(FRAUD_SAMPLE, MODEL_REGISTRY["knn"], label="FRAUD", lang="ur")
    assert len(reasons) == 3


def test_explain_normal_sample_says_no_unusual_patterns():
    reasons = model_service.explain(NORMAL_SAMPLE, _spec(), label="NORMAL", lang="en")
    assert reasons == [tr("no_unusual", "en")] == ["No unusual patterns found."]


def test_prediction_result_has_empty_reasons_by_default():
    from datetime import datetime
    result = PredictionResult(0.1, "NORMAL", "LOW", 0.5, "m", datetime.now())
    assert result.reasons == []


def test_ui_text_has_the_same_keys_in_both_languages():
    assert set(UI_TEXT["en"]) == set(UI_TEXT["ur"])
    assert tr("banner_fraud", "ur") == "FRAUD: Is transaction ko BLOCK karein"


# ---------------------------------------------------------------- database
def test_migration_adds_new_columns_and_keeps_old_rows(tmp_path, monkeypatch):
    old_db = tmp_path / "old.db"
    conn = sqlite3.connect(old_db)
    conn.executescript(OLD_SCHEMA)
    conn.execute("INSERT INTO users (full_name, email, password_hash, created_at) "
                 "VALUES ('Old User', 'old@example.com', 'x', '2024-01-01T00:00:00+00:00')")
    conn.execute("INSERT INTO predictions (user_id, amount, prediction, probability, risk_level, "
                 "model_name, threshold, created_at) VALUES (1, 99.5, 'FRAUD', 0.9, 'HIGH', 'm', 0.5, "
                 "'2024-01-01T00:00:00+00:00')")
    conn.commit()
    conn.close()

    monkeypatch.setattr(database, "DB_PATH", old_db)
    database.init_db()
    database.init_db()  # running it twice must be safe

    conn = sqlite3.connect(old_db)
    columns = {row[1] for row in conn.execute("PRAGMA table_info(predictions)")}
    conn.close()
    assert {"reasons", "review_status", "note"} <= columns

    frame = database.get_predictions(1)
    assert len(frame) == 1 and frame.iloc[0]["amount"] == 99.5
    assert frame.iloc[0]["review_status"] == "PENDING"
    assert frame.iloc[0]["reasons"] == []
    assert database.count_unreviewed(1) == 1


def test_reasons_are_saved_and_read_back():
    user = register()
    database.add_prediction(user["id"], 10.0, "FRAUD", 0.9, "HIGH", "m", 0.5,
                            reasons=["Amount is high", "Location is new"])
    database.add_prediction(user["id"], 11.0, "NORMAL", 0.01, "LOW", "m", 0.5)  # old call style
    frame = database.get_predictions(user["id"])
    by_amount = {r.amount: r.reasons for r in frame.itertuples()}
    assert by_amount[10.0] == ["Amount is high", "Location is new"]
    assert by_amount[11.0] == []


def test_update_review_changes_only_the_owners_row():
    alice, bob = register("Alice A", "alice@example.com"), register("Bob B", "bob@example.com")
    alice_id = database.add_prediction(alice["id"], 10.0, "FRAUD", 0.9, "HIGH", "m", 0.5)
    bob_id = database.add_prediction(bob["id"], 20.0, "FRAUD", 0.9, "HIGH", "m", 0.5)

    assert database.update_review(alice["id"], alice_id, "CONFIRMED_FRAUD", "checked") is True
    # Alice must not be able to touch Bob's row
    assert database.update_review(alice["id"], bob_id, "FALSE_ALARM", "hacked") is False

    alice_row = database.get_predictions(alice["id"]).iloc[0]
    bob_row = database.get_predictions(bob["id"]).iloc[0]
    assert alice_row["review_status"] == "CONFIRMED_FRAUD" and alice_row["note"] == "checked"
    assert bob_row["review_status"] == "PENDING" and bob_row["note"] == ""


def test_update_review_validates_status_and_note_length():
    user = register()
    pid = database.add_prediction(user["id"], 10.0, "FRAUD", 0.9, "HIGH", "m", 0.5)
    with pytest.raises(database.DatabaseError):
        database.update_review(user["id"], pid, "NOT_A_STATUS", "")
    with pytest.raises(database.DatabaseError):
        database.update_review(user["id"], pid, "APPROVED", "x" * 301)
    assert database.update_review(user["id"], pid, "APPROVED", "x" * 300) is True


def test_count_unreviewed_counts_only_pending_flagged_rows():
    user = register()
    fraud = database.add_prediction(user["id"], 1.0, "FRAUD", 0.9, "HIGH", "m", 0.5)
    database.add_prediction(user["id"], 2.0, "SUSPICIOUS", 0.3, "MEDIUM", "m", 0.5)
    database.add_prediction(user["id"], 3.0, "NORMAL", 0.01, "LOW", "m", 0.5)
    assert database.count_unreviewed(user["id"]) == 2
    database.update_review(user["id"], fraud, "FALSE_ALARM", "")
    assert database.count_unreviewed(user["id"]) == 1
    other = register("Bob B", "bob@example.com")
    assert database.count_unreviewed(other["id"]) == 0


# ------------------------------------------------------------ history page
def _history_frame():
    user = register()
    ids = {
        "fraud_pending": database.add_prediction(user["id"], 900.0, "FRAUD", 0.9, "HIGH", "m", 0.5),
        "fraud_done": database.add_prediction(user["id"], 800.0, "FRAUD", 0.8, "HIGH", "m", 0.5),
        "fraud_false": database.add_prediction(user["id"], 700.0, "FRAUD", 0.7, "HIGH", "m", 0.5),
        "susp_pending": database.add_prediction(user["id"], 50.0, "SUSPICIOUS", 0.3, "MEDIUM", "m", 0.5),
        "normal": database.add_prediction(user["id"], 5.0, "NORMAL", 0.01, "LOW", "m", 0.5),
    }
    database.update_review(user["id"], ids["fraud_done"], "CONFIRMED_FRAUD", "")
    database.update_review(user["id"], ids["fraud_false"], "FALSE_ALARM", "")
    return database.get_predictions(user["id"]), ids


def test_history_quick_filters_return_the_right_rows():
    frame, ids = _history_frame()
    pick = lambda quick: set(history_view.apply_quick_filter(frame, quick)["id"])
    assert pick("all") == set(ids.values())
    assert pick("needs_review") == {ids["fraud_pending"], ids["susp_pending"]}
    assert pick("fraud") == {ids["fraud_pending"], ids["fraud_done"], ids["fraud_false"]}
    assert pick("suspicious") == {ids["susp_pending"]}
    assert pick("safe") == {ids["normal"]}


def test_history_sorting_and_kpis():
    frame, ids = _history_frame()
    risk = history_view.apply_sort(frame, "risk")
    assert risk.iloc[0]["id"] == ids["fraud_pending"]
    amount = history_view.apply_sort(frame, "amount")
    assert list(amount["amount"]) == sorted(frame["amount"], reverse=True)
    # fraud rows that are not a false alarm: 900 + 800
    assert history_view.fraud_amount_blocked(frame) == 1700.0
    assert int(history_view.needs_review_mask(frame).sum()) == 2


def test_history_csv_export_has_the_new_columns():
    user = register()
    database.add_prediction(user["id"], 10.0, "FRAUD", 0.9, "HIGH", "m", 0.5, reasons=["a", "b"])
    pid = int(database.get_predictions(user["id"]).iloc[0]["id"])
    database.update_review(user["id"], pid, "CONFIRMED_FRAUD", "=HYPERLINK(1)")
    export = history_view.export_frame(database.get_predictions(user["id"]))
    row = export.iloc[0]
    assert {"verdict", "action", "reasons", "review_status", "note"} <= set(export.columns)
    assert row["verdict"] == "Fraud" and row["action"] == "Block"
    assert row["reasons"] == "a; b" and row["review_status"] == "CONFIRMED_FRAUD"
    assert row["note"].startswith("'=")  # spreadsheet formulas are neutralised


def test_history_and_dashboard_pages_render_with_flagged_rows():
    user = register()
    database.add_prediction(user["id"], 500.0, "FRAUD", 0.9, "HIGH", "m", 0.5,
                            reasons=["Amount is 2.0x higher than the average normal transaction."])
    database.add_prediction(user["id"], 20.0, "NORMAL", 0.01, "LOW", "m", 0.5)
    at = sign_in(new_app())
    for page in ("history", "dashboard"):
        at.session_state["page"] = page
        at.run()
        assert not at.exception, [e.value for e in at.exception]
    assert "waiting for review" in markdown_text(at)
